# ZORAVELLE

Free, animated, personalised greeting pages that you share with a link. The creator picks an occasion, adds a few details and photos, and publishes. The recipient opens the link: no account, no app, no payment.

Stack: Next.js 16 (App Router), React 19, TypeScript, Tailwind CSS v4, Motion, Lucide, Zod, Supabase (Postgres + private Storage), deployed on Vercel.

> **What has and has not been verified.** The logic, security rules, database schema and browser behaviour are covered by automated tests (see [Tests](#tests)), run against type stubs, an in-memory store and a local Postgres 16. These have **not** been run: `next build` on a machine with the real dependencies, a real Supabase project, the real Gemini / Anthropic / OpenAI APIs, the Google fonts, and real Android Chrome / iOS Safari devices. Treat the first deploy as the real test and follow the smoke test in [DEPLOY.md](DEPLOY.md).

## Quick start (local)

```bash
npm install
cp .env.example .env.local     # optional: with nothing set, the app runs in demo mode
npm run dev                    # http://localhost:3000
```

Demo mode = the in-memory store (data is lost on restart and is not shared between serverless instances) and the offline template writer. It is for trying the app only. Publishing for real needs Supabase: see [DEPLOY.md](DEPLOY.md) and [supabase/README.md](supabase/README.md).

Requires Node 20.9 or newer.

## Features

**Creating**
- Occasion library (25 occasions, one entry each in `src/lib/occasions/registry.ts`). Titles read "Happy Birthday", "Eid Mubarak", "Merry Christmas" and so on.
- Details → message and photos → style → preview → publish.
- **Write with AI**: idea, tone, length, Generate, Regenerate, Copy, Insert. It only ever adds to the creator's own text. Any AI failure, missing key or exhausted quota falls back to a built-in template, and the panel says which one wrote the draft. Limit 30 per IP per hour.
- **Photos**: up to 6 per greeting, shrunk in the browser before upload, re-encoded to WebP on the server (this removes location and camera data), per-photo progress, Cancel, Try again, Replace. A failed upload shows the real reason.
- **Saved drafts**: the flow is saved in the browser (`localStorage`, key `zoravelle:draft:v1:<occasion>`). After a refresh or closed tab a banner offers Continue or Start fresh. Drafts last 7 days and are cleared on publish. The draft holds its private edit token, so anyone using that browser profile can continue it.
- **Customise the look**: the look recipients see first (Calm, Cinematic, Expensive; they can still switch), the falling effect and its amount, and the photo layout (Polaroids, Grid, Filmstrip, Spotlight). All are fixed lists validated by the schema; greetings made before these options look exactly as before.

**Publishing: the Moment Delivery System.** Two options, one greeting experience:
1. **Publish Immediately**: the link opens the greeting straight away.
2. **Lock Greeting Until a Time & Date**: the link exists at once, but the content stays on the server until the unlock moment. Date picker, time selector, time-zone selector (default India time), countdown preview and recipient preview; past times and times more than a year away are refused.

Both options render through the same `ExperienceRenderer`, so a locked greeting shows exactly the same design, animations, photos, message and interactions the moment it unlocks. The only difference is when the recipient gets access.

- The lock is enforced on the server (`getViewState` in the store) **and** in the database (the row-level-security read policy in migration 0003). Before unlock, the page HTML, the status API, the page metadata and the shortcut manifest contain no message, photos, names or occasion.
- The unlock time is stored in UTC with the creator's time zone kept only for display. The recipient's device clock is never trusted: the countdown uses the server's clock offset, re-syncs every minute and on focus, and asks the server again at zero before revealing.
- A page left open unlocks by itself with a cinematic reveal; opening the link after unlock shows the greeting at once; going offline mid-countdown keeps counting and re-checks when the connection returns.
- The creator can change the time or open the greeting now from the manage page before it unlocks.
- **Add the Timer to My Screen**: a button on the countdown adds a per-greeting home-screen shortcut (a web app icon, `display: standalone`) that opens that greeting's countdown. Chrome and Edge on Android show the browser's own install prompt; iPhone Safari and other browsers get exact step-by-step instructions. It is a shortcut, **not** a native phone widget, and the page says so. The shortcut manifest is generic (no names, text or occasion), and the service worker (`public/sw.js`) caches a greeting page only while it is still locked and deletes it the moment it opens.

**Recipient experience**
- Occasion scenes, motifs and designed background pictures (six occasions have full pictures per look), parallax, ink-reveal headlines and falling effects. A viewer-side Calm / Cinematic / Expensive control; `prefers-reduced-motion` is respected.
- **Background music**: one soft piano track (`public/audio/romantic-piano.mp3`, about 1.9 MB) plays across the whole site, from the first page until the visitor leaves (homepage, create flow, countdown, greeting). The player lives in the root layout (`src/components/site/SiteMusic.tsx`), so it keeps playing between pages and resumes from the same position after a reload. Browsers block sound until the visitor touches the page, so it tries to start on load and otherwise starts with the first tap or key press. A button at the bottom left turns it off and on and "off" is remembered on that device. It pauses while the tab is hidden, and if the file can't play the button disappears. **Make sure you hold the licence to use this track on a public site.** To change it, replace the file or edit `MUSIC_SRC` in `SiteMusic.tsx`.

**Safety**
- No accounts. Each draft has a secret edit token (only its SHA-256 hash is stored) that authorises editing, publishing, photo upload, rescheduling and deletion. The manage link is `/manage#<id>.<token>`; the token is in the URL fragment, so it is never sent to the server in a page request.
- `/admin` moderation (hide, unhide, dismiss reports, delete), reporting form on every greeting, rate limits, daily purge job.

## Architecture rules

1. AI returns JSON only. `src/lib/experience/schema.ts` (Zod) is the single contract.
2. A trusted renderer maps config enums to pre-built components. No AI-generated code is ever executed.
3. New occasion = one entry in `src/lib/occasions/registry.ts`.
4. AI providers implement `AIProvider` (`src/lib/ai/types.ts`); the mock/template provider is the default.
5. Secrets are server-only. Only `NEXT_PUBLIC_*` values reach the browser.
6. Locked content is never produced until the server says the unlock time has passed.

## Project structure

```
src/app/(site)/       marketing pages, create flow, manage page, about, privacy
src/app/(bare)/       full-screen pages: /w/<slug> (greeting or countdown), /admin, /preview
src/app/api/          health, photos, report, cron/purge, greeting/<slug>/status
src/components/       create/, experience/ (the renderer), greeting/ (countdown), home/, site/, ui/
src/lib/              ai/, store/ (memory + Supabase), schedule/, experience/ (schema), security/, client/
public/               sw.js, offline.html, icons/, looks/ (background pictures), audio/
supabase/migrations/  0001_init, 0002_reports_and_limits, 0003_moment_delivery
supabase/tests/       SQL tests (run on a local Postgres)
tests/                TypeScript tests
```

## Environment variables

See `.env.example` for the full annotated list. Everything is optional; with none set the app runs in demo mode.

| Variable | Purpose |
| --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Your final public URL, no trailing slash. Used for share links and metadata |
| `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Supabase project (public; limited by row-level security) |
| `SUPABASE_SERVICE_ROLE_KEY` | Server only. Bypasses row-level security. Never prefix with `NEXT_PUBLIC_` |
| `AI_PROVIDER` | `mock` (default, offline template), `gemini`, `anthropic` or `openai` |
| `GEMINI_API_KEY`, `GEMINI_MODEL` | Google Gemini (free tier available). Default model `gemini-2.5-flash` is unverified, so set one your key can use |
| `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`, `OPENAI_API_KEY`, `OPENAI_MODEL` | Optional alternatives. Defaults are unverified |
| `AI_GENERATIONS_PER_HOUR`, `AI_DAILY_GENERATION_CAP` | Quotas for real AI (defaults 5 and 500) |
| `ADMIN_TOKEN` | Password for `/admin` (24+ random characters). Empty switches `/admin` off |
| `CRON_SECRET` | Secret for the daily purge job (16+ characters). Empty disables the job |
| `RUN_SUPABASE_CONTRACT` | Test only: `1` runs the store contract against a **development** Supabase project |

On the free tier of Gemini, Google may use what you send to improve its products. The app tells users not to put private details in the AI box, and `/privacy` says so.

## Database and storage

Three migrations in `supabase/migrations/`, run in order. See [supabase/README.md](supabase/README.md).

- Viewers read published greetings through row-level security with the anon key; the policy also enforces the unlock time. Every write goes through the server with the service-role key.
- Photos are validated, re-encoded to WebP, stored in a private bucket and shown through short-lived signed URLs.
- `/api/health` reports whether the database is connected and which migrations are missing, without exposing any key.

## Moderation, limits and headers

- `/admin`: HMAC-signed, HttpOnly, SameSite=Strict cookie scoped to `/admin`, valid 8 hours; sign-in limited to 5 per 15 minutes per IP; every action re-checks the session.
- Reporting never hides a greeting by itself, so it can't be used to take down someone else's greeting.
- `/api/cron/purge` removes expired greetings and drafts older than 7 days (200 per run). `vercel.json` runs it daily at 03:17 UTC.
- Rate limits are counted in Postgres when Supabase is configured (so they hold across instances) and in memory otherwise.
- `/preview` returns 404 in production. CSP, HSTS, X-Frame-Options DENY, nosniff, referrer and permissions policies are set in `next.config.ts`; `/w`, `/manage` and `/admin` send `noindex`. The CSP still allows inline scripts (Next's bootstrap); per-request nonces are a later hardening step.

## Design system

White `#FFFFFF`, black `#111111`, deep red / crimson `#B51224` (dark `#780D1B`), champagne gold `#B8934A`. **No purple.** Site headings use Cormorant Garamond, body text uses Inter, and the greeting scenes use their own font pairs (Dancing Script, Playfair Display, Cinzel, Nunito). Tokens live in `src/app/globals.css`.

## Tests

`npm run test:all` runs everything below. None of it needs a network or a database.

| Command | Covers |
| --- | --- |
| `npm run test:unit` | tokens, image pipeline |
| `npm run test:store` | store contract (memory store; add `RUN_SUPABASE_CONTRACT=1` for a development Supabase project) |
| `npm run test:flow` | draft → upload → generate → edit → publish → view → manage → delete, and rate limits, through the real actions |
| `npm run test:admin` | admin session signing, report and purge endpoints |
| `npm run test:delivery` | locking, unlocking, rescheduling, time zones, clock tampering, no leaks, same greeting in both modes |
| `npm run test:upload` | photo error messages and the no-database case |
| `npm run test:write` | Write with AI: Gemini request shape, fallbacks, cleaning, limits |
| `npm run test:stage7` | drafts, photo layouts, look customisation |
| `npm run typecheck`, `npm run typecheck:tests` | TypeScript (app, and app + tests) |

The SQL tests in `supabase/tests/` (policies, grants, the unlock rule, rate limits) are run with `psql`; see `supabase/README.md`.

## Known limits

- Greetings never expire unless you pass `expiresAt` to `createDraft`.
- A lost manage link cannot be recovered.
- iPhone browsers ignore the music fade-in (volume is read-only there).
- The lock needs migration 0003; `/api/health` tells you if it is missing.
- The countdown shortcut is a web-app icon, never a native widget.
