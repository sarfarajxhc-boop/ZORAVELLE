import type { NextConfig } from "next";

const isDev = process.env.NODE_ENV !== "production";

/**
 * Content-Security-Policy.
 * - 'unsafe-inline' scripts are needed for Next's own bootstrap scripts unless every page uses
 *   per-request nonces (which forces dynamic rendering). That's a known trade-off; the other
 *   directives still block foreign scripts' network access, framing, plugins and form hijacking.
 * - Photos are inline data: URLs in demo mode and Supabase signed URLs in production.
 * - 'unsafe-eval' only in development (React's dev tooling).
 */
const supabaseHost = (() => {
  try {
    return process.env.NEXT_PUBLIC_SUPABASE_URL ? new URL(process.env.NEXT_PUBLIC_SUPABASE_URL).origin : "";
  } catch {
    return "";
  }
})();

const csp = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ""}`,
  "style-src 'self' 'unsafe-inline'",
  `img-src 'self' data: blob: ${supabaseHost}`.trim(),
  "font-src 'self' data:",
  "media-src 'self'",
  `connect-src 'self'${isDev ? " ws: wss:" : ""}`,
  "worker-src 'self'",
  "manifest-src 'self'",
  "object-src 'none'",
  "base-uri 'self'",
  "form-action 'self'",
  "frame-ancestors 'none'",
  ...(isDev ? [] : ["upgrade-insecure-requests"]),
].join("; ");

const nextConfig: NextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  async headers() {
    const noindex = [{ key: "X-Robots-Tag", value: "noindex, nofollow" }];
    return [
      // Private by link: greetings, manage links and admin stay out of search engines.
      { source: "/w/:path*", headers: [...noindex, { key: "Cache-Control", value: "no-store" }] },
      // The service worker must always be re-checked so a fix reaches phones quickly.
      { source: "/sw.js", headers: [{ key: "Cache-Control", value: "no-cache, max-age=0, must-revalidate" }, { key: "Content-Type", value: "text/javascript; charset=utf-8" }] },
      { source: "/api/greeting/:path*", headers: [{ key: "Cache-Control", value: "no-store" }] },
      { source: "/manage", headers: noindex },
      { source: "/admin", headers: [...noindex, { key: "Cache-Control", value: "no-store" }] },
      {
        source: "/(.*)",
        headers: [
          { key: "Content-Security-Policy", value: csp },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=()" },
          { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains" },
        ],
      },
    ];
  },
};

export default nextConfig;
