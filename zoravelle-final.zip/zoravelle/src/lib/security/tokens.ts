import { createHash, randomBytes, timingSafeEqual } from "node:crypto";

const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

export const SLUG_LENGTH = 10;
export const SLUG_RE = /^[0-9A-Za-z]{10}$/;
export const TOKEN_RE = /^[A-Za-z0-9_-]{43}$/;
export const HASH_RE = /^[0-9a-f]{64}$/;

/**
 * Public share slug: 10 random base62 characters (about 59 bits).
 * Bytes >= 248 are discarded (248 = 62 * 4) so every character is equally likely.
 */
export function generateSlug(): string {
  let out = "";
  while (out.length < SLUG_LENGTH) {
    for (const byte of randomBytes(16)) {
      if (byte < 248 && out.length < SLUG_LENGTH) out += ALPHABET.charAt(byte % 62);
    }
  }
  return out;
}

/**
 * The creator's secret for editing, publishing and deleting. 256 random bits.
 * Shown to the creator once; only its SHA-256 hash is stored. A fast hash is
 * appropriate here because the token is random, not a human-chosen password.
 */
export function generateEditToken(): string {
  return randomBytes(32).toString("base64url");
}

export function hashToken(token: string): string {
  return createHash("sha256").update(token, "utf8").digest("hex");
}

/** Constant-time check of a presented token against a stored hash. Never throws. */
export function tokenMatchesHash(token: unknown, hash: unknown): boolean {
  if (typeof token !== "string" || typeof hash !== "string") return false;
  if (!TOKEN_RE.test(token) || !HASH_RE.test(hash)) return false;
  return timingSafeEqual(Buffer.from(hashToken(token), "hex"), Buffer.from(hash, "hex"));
}
