/** Hosting platforms cap request bodies (Vercel: about 4.5 MB), so shrink before uploading. */
export const CLIENT_MAX_BYTES = 4 * 1024 * 1024;
const MAX_EDGE = 1600;

const OK_TYPES = /^image\/(jpeg|png|webp)$/;

/**
 * Downscale and re-encode a photo in the browser before upload. This also
 * handles phone formats the server doesn't accept directly (for example HEIC on
 * Safari) and applies EXIF rotation. The server still validates and re-encodes
 * everything again: this step is for size and convenience, never for safety.
 */
export async function prepareImage(file: File): Promise<File> {
  try {
    const bitmap = await createImageBitmap(file, { imageOrientation: "from-image" });
    const scale = Math.min(1, MAX_EDGE / Math.max(bitmap.width, bitmap.height));
    const w = Math.max(1, Math.round(bitmap.width * scale));
    const h = Math.max(1, Math.round(bitmap.height * scale));

    const canvas = document.createElement("canvas");
    canvas.width = w;
    canvas.height = h;
    const ctx = canvas.getContext("2d");
    if (!ctx) throw new Error("no canvas");
    ctx.fillStyle = "#ffffff"; // JPEG has no transparency
    ctx.fillRect(0, 0, w, h);
    ctx.drawImage(bitmap, 0, 0, w, h);
    bitmap.close();

    const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.86));
    if (!blob) throw new Error("encode failed");
    if (blob.size > CLIENT_MAX_BYTES) throw new TooLarge();
    return new File([blob], "photo.jpg", { type: "image/jpeg" });
  } catch (e) {
    if (e instanceof TooLarge) throw new Error("That photo is too large. Choose a smaller one.");
    // Couldn't process it in the browser: send the original if it is acceptable as is.
    if (OK_TYPES.test(file.type) && file.size <= CLIENT_MAX_BYTES) return file;
    throw new Error("We couldn't read that photo. Try a JPEG or PNG.");
  }
}

class TooLarge extends Error {}
