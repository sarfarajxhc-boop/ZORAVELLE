import { ExperienceConfigSchema, type ExperienceConfig } from "@/lib/experience/schema";

/**
 * The greeting being made, kept in this browser so a refresh, a closed tab or a phone call doesn't lose it.
 * It holds the draft's edit token (like the "my greetings" list), so anyone using this browser profile can
 * continue the draft. Every call is wrapped: storage can be blocked (private mode, policies).
 */
const PREFIX = "zoravelle:draft:v1:";
const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000;

export type SavedDraft = {
  savedAt: number;
  step: number;
  form: Record<string, string>;
  draft: { id: string; token: string } | null;
  config: ExperienceConfig | null;
  meta: { provider: string; usedFallback: boolean } | null;
};

const str = (v: unknown): v is string => typeof v === "string";

export function parseDraft(raw: unknown, now = Date.now()): SavedDraft | null {
  if (typeof raw !== "object" || raw === null) return null;
  const o = raw as Record<string, unknown>;
  if (o["v"] !== 1 || typeof o["savedAt"] !== "number" || now - o["savedAt"] > MAX_AGE_MS || o["savedAt"] > now + 60_000) return null;
  const f = o["form"];
  if (typeof f !== "object" || f === null) return null;
  const form: Record<string, string> = {};
  for (const [k, v] of Object.entries(f)) if (str(v)) form[k] = v.slice(0, 1500);
  const d = o["draft"];
  const draft =
    typeof d === "object" && d !== null && str((d as Record<string, unknown>)["id"]) && str((d as Record<string, unknown>)["token"])
      ? { id: (d as { id: string }).id, token: (d as { token: string }).token }
      : null;
  const cfg = ExperienceConfigSchema.safeParse(o["config"]);
  const m = o["meta"] as Record<string, unknown> | null;
  const meta = m && str(m["provider"]) && typeof m["usedFallback"] === "boolean" ? { provider: m["provider"], usedFallback: m["usedFallback"] } : null;
  const step = typeof o["step"] === "number" && o["step"] >= 0 && o["step"] <= 2 ? Math.floor(o["step"]) : 0;
  return { savedAt: o["savedAt"], step, form, draft, config: cfg.success && meta ? cfg.data : null, meta: cfg.success ? meta : null };
}

export function loadDraft(occasion: string): SavedDraft | null {
  try {
    const raw = localStorage.getItem(PREFIX + occasion);
    return raw ? parseDraft(JSON.parse(raw)) : null;
  } catch {
    return null;
  }
}

export function saveDraft(occasion: string, d: Omit<SavedDraft, "savedAt">): boolean {
  try {
    localStorage.setItem(PREFIX + occasion, JSON.stringify({ v: 1, savedAt: Date.now(), ...d }));
    return true;
  } catch {
    return false;
  }
}

export function clearDraft(occasion: string): void {
  try {
    localStorage.removeItem(PREFIX + occasion);
  } catch {
    /* nothing to clear */
  }
}

/** True when there is something worth offering to resume. */
export const isWorthResuming = (d: SavedDraft): boolean =>
  Boolean(d.config || d.draft || Object.values(d.form).some((v) => v.trim()));
