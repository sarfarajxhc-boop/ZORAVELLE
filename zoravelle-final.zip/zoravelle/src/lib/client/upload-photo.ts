/** Browser-side photo upload with real progress, cancellation and a clear message for every failure. */

export type UploadCredentials = { id: string; token: string };
export type UploadResult = { assetId: string; url: string | null };
type ServerReply = { assetId?: string; url?: string | null; error?: string };

export class UploadError extends Error {
  constructor(
    message: string,
    public readonly status: number,
    /** The draft is gone: the whole flow has to restart, retrying won't help. */
    public readonly sessionExpired = false,
    /** Trying the same photo again may work. */
    public readonly retryable = true,
  ) {
    super(message);
    this.name = "UploadError";
  }
}

/** What to tell a person for an HTTP status (0 = the request never got an answer). */
export function describeFailure(status: number, serverMessage?: string): { message: string; sessionExpired: boolean; retryable: boolean } {
  if (status === 0) return { message: "No internet connection. Check it, then try again.", sessionExpired: false, retryable: true };
  if (status === 403) return { message: "Your session expired. Go back and start the greeting again.", sessionExpired: true, retryable: false };
  if (status === 413) return { message: "That photo is too large. Choose a smaller one.", sessionExpired: false, retryable: false };
  if (status === 429) return { message: "You've uploaded a lot of photos. Wait a few minutes and try again.", sessionExpired: false, retryable: true };
  if (status === 409) return { message: serverMessage || "You've reached the photo limit.", sessionExpired: false, retryable: false };
  if (status === 400 || status === 415) return { message: serverMessage || "We couldn't read that photo. Try a JPEG or PNG.", sessionExpired: false, retryable: false };
  if (status === 503 && serverMessage && /Supabase/.test(serverMessage)) return { message: serverMessage, sessionExpired: false, retryable: false };
  if (status === 503 || status === 502 || status === 504) return { message: "The service is busy right now. Try again in a moment.", sessionExpired: false, retryable: true };
  return { message: "Something went wrong on our side. Try again.", sessionExpired: false, retryable: true };
}

export function uploadPhoto(
  creds: UploadCredentials,
  file: Blob,
  onProgress: (percent: number) => void,
  signal?: AbortSignal,
): Promise<UploadResult> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    const form = new FormData();
    form.set("id", creds.id);
    form.set("file", file, "photo.jpg");

    xhr.open("POST", "/api/photos");
    xhr.setRequestHeader("x-edit-token", creds.token);
    xhr.timeout = 120_000;
    xhr.responseType = "text";

    xhr.upload.onprogress = (e) => { if (e.lengthComputable) onProgress(Math.round((e.loaded / e.total) * 100)); };
    xhr.onload = () => {
      let body: ServerReply | null = null;
      try { body = JSON.parse(xhr.responseText) as ServerReply; } catch { /* a platform error page, not our JSON */ }
      if (xhr.status >= 200 && xhr.status < 300 && body?.assetId) {
        onProgress(100);
        return resolve({ assetId: body.assetId, url: body.url ?? null });
      }
      const f = describeFailure(xhr.status, body?.error);
      reject(new UploadError(f.message, xhr.status, f.sessionExpired, f.retryable));
    };
    xhr.onerror = () => { const f = describeFailure(0); reject(new UploadError(f.message, 0, false, true)); };
    xhr.ontimeout = () => reject(new UploadError("The upload took too long. Check your connection and try again.", 0, false, true));
    xhr.onabort = () => reject(new DOMException("Upload cancelled", "AbortError"));

    if (signal) {
      if (signal.aborted) return reject(new DOMException("Upload cancelled", "AbortError"));
      signal.addEventListener("abort", () => xhr.abort(), { once: true });
    }
    xhr.send(form);
  });
}

/** One automatic retry for a dropped connection, a timeout or a busy server; never for a refusal. */
export async function uploadPhotoWithRetry(
  creds: UploadCredentials,
  file: Blob,
  onProgress: (percent: number) => void,
  signal?: AbortSignal,
): Promise<UploadResult> {
  try {
    return await uploadPhoto(creds, file, onProgress, signal);
  } catch (e) {
    if (e instanceof UploadError && e.retryable && !signal?.aborted && (e.status === 0 || e.status >= 500)) {
      onProgress(0);
      await new Promise((r) => setTimeout(r, 1200));
      return uploadPhoto(creds, file, onProgress, signal);
    }
    throw e;
  }
}
