/**
 * Greetings created in this browser, so the creator can find and delete them
 * later. Stored in localStorage: it never leaves the device, but it does hold
 * edit tokens, so anyone using this browser profile can manage these greetings.
 * Every call is wrapped because storage can be blocked (private mode, policies).
 */
const KEY = "zoravelle:greetings:v1";
const MAX_SAVED = 20;

export type SavedGreeting = {
  id: string;
  token: string;
  slug: string;
  label: string;
  createdAt: string;
};

function isSaved(v: unknown): v is SavedGreeting {
  if (typeof v !== "object" || v === null) return false;
  const o = v as Record<string, unknown>;
  return ["id", "token", "slug", "label", "createdAt"].every((k) => typeof o[k] === "string");
}

export function loadSaved(): SavedGreeting[] {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return [];
    const parsed: unknown = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter(isSaved).slice(0, MAX_SAVED) : [];
  } catch {
    return [];
  }
}

export function saveGreeting(g: SavedGreeting): void {
  try {
    const list = [g, ...loadSaved().filter((x) => x.id !== g.id)].slice(0, MAX_SAVED);
    localStorage.setItem(KEY, JSON.stringify(list));
  } catch {
    // storage unavailable: the manage link on the success screen still works
  }
}

export function forgetGreeting(id: string): void {
  try {
    localStorage.setItem(KEY, JSON.stringify(loadSaved().filter((x) => x.id !== id)));
  } catch {
    // ignore
  }
}
