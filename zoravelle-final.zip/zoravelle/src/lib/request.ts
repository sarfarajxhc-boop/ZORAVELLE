type HeaderReader = { get(name: string): string | null };

/**
 * Best-effort client IP. Only trustworthy behind a proxy that sets these headers
 * itself (Vercel does). Without one, a caller could spoof it to dodge limits.
 */
export function ipFromHeaders(h: HeaderReader): string {
  const raw = h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || "unknown";
  return raw.slice(0, 64);
}

/** Same, for server actions (reads the incoming request headers). */
export async function clientIp(): Promise<string> {
  try {
    const { headers } = await import("next/headers");
    return ipFromHeaders(await headers());
  } catch {
    return "unknown";
  }
}
