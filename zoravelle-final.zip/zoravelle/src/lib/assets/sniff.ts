export type SniffedType = "jpeg" | "png" | "webp";

/**
 * Identify an image by its leading bytes. The browser-supplied MIME type and
 * file extension are never trusted. SVG and GIF are deliberately not accepted:
 * SVG can carry script, and animated GIFs are heavy for a mobile greeting.
 */
export function sniffImageType(buf: Uint8Array): SniffedType | null {
  if (buf.length >= 3 && buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpeg";
  if (
    buf.length >= 8 &&
    buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47 &&
    buf[4] === 0x0d && buf[5] === 0x0a && buf[6] === 0x1a && buf[7] === 0x0a
  ) return "png";
  if (
    buf.length >= 12 &&
    buf[0] === 0x52 && buf[1] === 0x49 && buf[2] === 0x46 && buf[3] === 0x46 &&   // "RIFF"
    buf[8] === 0x57 && buf[9] === 0x45 && buf[10] === 0x42 && buf[11] === 0x50    // "WEBP"
  ) return "webp";
  return null;
}
