import sharp from "sharp";
import { sniffImageType } from "./sniff";

export const MAX_UPLOAD_BYTES = 5 * 1024 * 1024;
export const MAX_DIMENSION = 1600;
/** Decoded-pixel ceiling. Stops "decompression bomb" files that are tiny on the wire but huge in memory. */
export const MAX_INPUT_PIXELS = 40_000_000;

export type ImageErrorCode = "empty" | "too_large" | "unsupported_type" | "corrupt";

export class ImageError extends Error {
  constructor(public readonly code: ImageErrorCode, message: string) {
    super(message);
    this.name = "ImageError";
  }
}

export type ProcessedImage = {
  data: Buffer;
  mime: "image/webp";
  width: number;
  height: number;
  byteSize: number;
};

/**
 * Validate and re-encode an uploaded photo. The output is always a fresh WebP
 * built from decoded pixels, so:
 *  - EXIF (including GPS location) and every other metadata block is dropped
 *  - anything appended to or hidden inside the original file is discarded
 *  - orientation is applied, then the flag is removed
 *  - size is capped at 1600px on the long edge
 * Messages are written for the person uploading, in plain language.
 */
export async function processImage(input: Uint8Array): Promise<ProcessedImage> {
  if (input.length === 0) throw new ImageError("empty", "That file is empty.");
  if (input.length > MAX_UPLOAD_BYTES) {
    throw new ImageError("too_large", "That photo is larger than 5 MB. Choose a smaller one.");
  }
  if (!sniffImageType(input)) {
    throw new ImageError("unsupported_type", "Use a JPEG, PNG or WebP photo.");
  }

  try {
    const { data, info } = await sharp(input, { limitInputPixels: MAX_INPUT_PIXELS, failOn: "error" })
      .rotate()
      .resize({ width: MAX_DIMENSION, height: MAX_DIMENSION, fit: "inside", withoutEnlargement: true })
      .webp({ quality: 82 })
      .toBuffer({ resolveWithObject: true });

    return { data, mime: "image/webp", width: info.width, height: info.height, byteSize: data.length };
  } catch (e) {
    const msg = e instanceof Error ? e.message : "";
    if (/pixel limit/i.test(msg)) {
      throw new ImageError("too_large", "That photo has too many pixels. Choose a smaller one.");
    }
    throw new ImageError("corrupt", "We couldn't read that photo. Try a different one.");
  }
}
