import type { ExperienceConfig } from "@/lib/experience/schema";

type Scene = ExperienceConfig["blocks"][number] extends infer B
  ? B extends { scene: infer S } ? S : never
  : never;

export type OccasionDef = {
  id: string;               // URL slug: /create/[id]
  label: string;
  title: string;            // the greeting phrase shown to people: "Happy Birthday", "Eid Mubarak"
  category: "personal" | "romance" | "festival" | "milestone" | "daily" | "family";
  icon: string;             // lucide-react icon name, resolved in the UI layer
  blurb: string;
  scene: Scene;             // default hero scene
  ambient: ExperienceConfig["ambient"]["effect"];
  background: ExperienceConfig["theme"]["background"];
  fontPair: ExperienceConfig["theme"]["fontPair"];
  palette: ExperienceConfig["theme"]["palette"];
  interaction: { kind: "tapToBegin" | "blowCandles" | "openGift" | "lightDiyas" | "unwrapLetter" | "countdown" | "tapToReveal" | "holdToCharge"; prompt: string };
  popular?: boolean;
};

const p = (background: string, surface: string, text: string, accent: string, accentSoft: string) =>
  ({ background, surface, text, accent, accentSoft });

/**
 * Adding an occasion = adding one entry here. No other code changes needed:
 * routes, the picker, the AI prompt, and the mock provider all read this list.
 */
export const OCCASIONS: readonly OccasionDef[] = [
  { id: "birthday", label: "Birthday", title: "Happy Birthday", category: "personal", icon: "Cake", blurb: "Candles, confetti and a surprise reveal.", scene: "cake", ambient: "confetti", background: "softGradient", fontPair: "playfulRounded", palette: p("#fff7ed", "#ffffff", "#431407", "#ea580c", "#fed7aa"), interaction: { kind: "blowCandles", prompt: "Tap to blow out the candles" }, popular: true },
  { id: "anniversary", label: "Anniversary", title: "Happy Anniversary", category: "romance", icon: "Heart", blurb: "A love letter and shared memories.", scene: "loveLetter", ambient: "floatingHearts", background: "bokeh", fontPair: "romanticScript", palette: p("#2a0a14", "#3b1220", "#ffe4e6", "#fb7185", "#881337"), interaction: { kind: "unwrapLetter", prompt: "Open your letter" }, popular: true },
  { id: "wedding", popular: true, label: "Wedding", title: "Happy Wedding", category: "milestone", icon: "Gem", blurb: "Elegant congratulations for the big day.", scene: "bloom", ambient: "petals", background: "paperTexture", fontPair: "elegantSerif", palette: p("#faf7f2", "#ffffff", "#292524", "#a16207", "#fef3c7"), interaction: { kind: "tapToReveal", prompt: "Tap to reveal" } },
  { id: "engagement", label: "Engagement", title: "Happy Engagement", category: "romance", icon: "Sparkles", blurb: "Celebrate the yes.", scene: "hearts", ambient: "sparkles", background: "softGradient", fontPair: "romanticScript", palette: p("#fbf6f1", "#ffffff", "#3a0a10", "#b51224", "#f1d4d7"), interaction: { kind: "tapToReveal", prompt: "Tap to reveal" } },
  { id: "love", label: "Love & Romance", title: "With All My Love", category: "romance", icon: "HeartHandshake", blurb: "Say what words alone can't.", scene: "hearts", ambient: "floatingHearts", background: "bokeh", fontPair: "romanticScript", palette: p("#2a0a14", "#3b1220", "#ffe4e6", "#f43f5e", "#9f1239"), interaction: { kind: "unwrapLetter", prompt: "Open your letter" }, popular: true },
  { id: "valentines-day", label: "Valentine's Day", title: "Happy Valentine's Day", category: "romance", icon: "Heart", blurb: "A sweet surprise for your valentine.", scene: "hearts", ambient: "floatingHearts", background: "softGradient", fontPair: "romanticScript", palette: p("#fff1f2", "#ffffff", "#4c0519", "#e11d48", "#fecdd3"), interaction: { kind: "openGift", prompt: "Open your gift" } },
  { id: "friendship", label: "Friendship", title: "Happy Friendship Day", category: "personal", icon: "Users", blurb: "For the people who show up.", scene: "polaroids", ambient: "sparkles", background: "softGradient", fontPair: "modernSans", palette: p("#f0f9ff", "#ffffff", "#0c4a6e", "#0284c7", "#bae6fd"), interaction: { kind: "tapToReveal", prompt: "Tap to reveal" } },
  { id: "eid", label: "Eid", title: "Eid Mubarak", category: "festival", icon: "MoonStar", blurb: "Crescent, lanterns and warm wishes.", scene: "crescentLanterns", ambient: "lanterns", background: "geometricIslamic", fontPair: "elegantSerif", palette: p("#052e2b", "#0b3d38", "#ecfdf5", "#fbbf24", "#115e59"), interaction: { kind: "tapToBegin", prompt: "Tap to begin" }, popular: true },
  { id: "ramadan", label: "Ramadan", title: "Ramadan Mubarak", category: "festival", icon: "Moon", blurb: "A peaceful Ramadan Mubarak.", scene: "crescentLanterns", ambient: "stars", background: "nightSky", fontPair: "elegantSerif", palette: p("#0b1220", "#111a2e", "#e2e8f0", "#fbbf24", "#1e3a5f"), interaction: { kind: "tapToBegin", prompt: "Tap to begin" } },
  { id: "diwali", label: "Diwali", title: "Happy Diwali", category: "festival", icon: "Flame", blurb: "Light the diyas, light up the night.", scene: "diyas", ambient: "sparkles", background: "nightSky", fontPair: "classicDisplay", palette: p("#1c0a00", "#2b1405", "#fff7ed", "#f59e0b", "#7c2d12"), interaction: { kind: "lightDiyas", prompt: "Tap each diya to light it" }, popular: true },
  { id: "holi", label: "Holi", title: "Happy Holi", category: "festival", icon: "Palette", blurb: "Bursts of colour and joy.", scene: "colorBurst", ambient: "colorPowder", background: "softGradient", fontPair: "playfulRounded", palette: p("#fffbeb", "#ffffff", "#431407", "#ea580c", "#fde68a"), interaction: { kind: "tapToReveal", prompt: "Tap to splash the colours" } },
  { id: "christmas", label: "Christmas", title: "Merry Christmas", category: "festival", icon: "TreePine", blurb: "Snowfall, lights and a gift to open.", scene: "christmasTree", ambient: "snow", background: "nightSky", fontPair: "classicDisplay", palette: p("#0a1f17", "#10301f", "#f0fdf4", "#ef4444", "#14532d"), interaction: { kind: "openGift", prompt: "Open your gift" }, popular: true },
  { id: "new-year", label: "New Year", title: "Happy New Year", category: "festival", icon: "PartyPopper", blurb: "Countdown, fireworks, fresh start.", scene: "fireworks", ambient: "fireworks", background: "nightSky", fontPair: "modernSans", palette: p("#0b0b1a", "#14142b", "#f8fafc", "#facc15", "#312e81"), interaction: { kind: "countdown", prompt: "Tap to start the countdown" }, popular: true },
  { id: "congratulations", label: "Congratulations", title: "Congratulations", category: "milestone", icon: "Trophy", blurb: "Celebrate a big win.", scene: "confettiPop", ambient: "confetti", background: "softGradient", fontPair: "modernSans", palette: p("#fefce8", "#ffffff", "#422006", "#ca8a04", "#fef08a"), interaction: { kind: "holdToCharge", prompt: "Press and hold to celebrate" } },
  { id: "graduation", label: "Graduation", title: "Happy Graduation", category: "milestone", icon: "GraduationCap", blurb: "A milestone worth celebrating.", scene: "confettiPop", ambient: "confetti", background: "paperTexture", fontPair: "classicDisplay", palette: p("#eff6ff", "#ffffff", "#172554", "#2563eb", "#bfdbfe"), interaction: { kind: "tapToReveal", prompt: "Tap to reveal" } },
  { id: "thank-you", label: "Thank You", title: "Thank You", category: "personal", icon: "HandHeart", blurb: "Gratitude, beautifully said.", scene: "bloom", ambient: "petals", background: "softGradient", fontPair: "elegantSerif", palette: p("#f0fdf4", "#ffffff", "#14532d", "#16a34a", "#bbf7d0"), interaction: { kind: "tapToReveal", prompt: "Tap to open" } },
  { id: "good-morning", label: "Good Morning", title: "Good Morning", category: "daily", icon: "Sunrise", blurb: "Start someone's day with a smile.", scene: "sunrise", ambient: "sparkles", background: "sunrise", fontPair: "playfulRounded", palette: p("#fff7ed", "#ffffff", "#7c2d12", "#f97316", "#fed7aa"), interaction: { kind: "tapToBegin", prompt: "Tap to start the day" } },
  { id: "good-night", label: "Good Night", title: "Good Night", category: "daily", icon: "MoonStar", blurb: "Sweet dreams under the stars.", scene: "nightSky", ambient: "stars", background: "nightSky", fontPair: "romanticScript", palette: p("#0b1020", "#131a33", "#e0e7ff", "#a5b4fc", "#1e1b4b"), interaction: { kind: "tapToBegin", prompt: "Tap to begin" } },
  { id: "get-well-soon", label: "Get Well Soon", title: "Get Well Soon", category: "personal", icon: "HeartPulse", blurb: "Warmth for a speedy recovery.", scene: "bloom", ambient: "petals", background: "softGradient", fontPair: "modernSans", palette: p("#f0fdfa", "#ffffff", "#134e4a", "#0d9488", "#99f6e4"), interaction: { kind: "tapToReveal", prompt: "Tap to open" } },
  { id: "farewell", label: "Farewell", title: "Farewell", category: "milestone", icon: "Plane", blurb: "Until we meet again.", scene: "polaroids", ambient: "fireflies", background: "sunrise", fontPair: "elegantSerif", palette: p("#fffbeb", "#ffffff", "#451a03", "#d97706", "#fde68a"), interaction: { kind: "unwrapLetter", prompt: "Open your letter" } },
  { id: "mothers-day", label: "Mother's Day", title: "Happy Mother's Day", category: "family", icon: "Flower2", blurb: "For the one who did everything.", scene: "bloom", ambient: "petals", background: "softGradient", fontPair: "romanticScript", palette: p("#fff7f5", "#ffffff", "#4a0e17", "#c2394b", "#f6d5d9"), interaction: { kind: "tapToReveal", prompt: "Tap to open" } },
  { id: "fathers-day", label: "Father's Day", title: "Happy Father's Day", category: "family", icon: "Medal", blurb: "Thanks, Dad.", scene: "cardOpen", ambient: "sparkles", background: "paperTexture", fontPair: "classicDisplay", palette: p("#f8fafc", "#ffffff", "#0f172a", "#1d4ed8", "#bfdbfe"), interaction: { kind: "tapToReveal", prompt: "Tap to open" } },
  { id: "baby-shower", label: "Baby Shower", title: "Happy Baby Shower", category: "family", icon: "Baby", blurb: "Soft, sweet and full of balloons.", scene: "balloons", ambient: "sparkles", background: "softGradient", fontPair: "playfulRounded", palette: p("#f0f9ff", "#ffffff", "#0c4a6e", "#38bdf8", "#e0f2fe"), interaction: { kind: "openGift", prompt: "Open the gift" } },
  { id: "festival", label: "Festival Greetings", title: "Festival Greetings", category: "festival", icon: "Sparkle", blurb: "Any festival, any tradition.", scene: "colorBurst", ambient: "lanterns", background: "bokeh", fontPair: "classicDisplay", palette: p("#140d05", "#1f150a", "#fdf6e7", "#e0b25a", "#4a3512"), interaction: { kind: "tapToBegin", prompt: "Tap to begin" } },
  { id: "custom", label: "Custom Occasion", title: "Custom Occasion", category: "personal", icon: "Wand2", blurb: "Your moment, your rules.", scene: "cardOpen", ambient: "sparkles", background: "aurora", fontPair: "modernSans", palette: p("#111111", "#1c1c1c", "#f5f5f5", "#d4af6a", "#3a2f18"), interaction: { kind: "tapToReveal", prompt: "Tap to reveal" } },
] as const;

const BY_ID = new Map(OCCASIONS.map((o) => [o.id, o]));

export const getOccasion = (id: string): OccasionDef | undefined => BY_ID.get(id);
export const popularOccasions = () => OCCASIONS.filter((o) => o.popular);
