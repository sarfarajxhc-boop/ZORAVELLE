const HOST_RE = /^[A-Za-z0-9.-]+(:\d{1,5})?$/;

/**
 * Public base URL used to build share links.
 * In production set NEXT_PUBLIC_SITE_URL: it is the only value that cannot be
 * influenced by a request. Without it we fall back to the request's own host.
 */
export async function getSiteUrl(): Promise<string> {
  const explicit = process.env.NEXT_PUBLIC_SITE_URL;
  if (explicit) return explicit.replace(/\/+$/, "");
  try {
    const { headers } = await import("next/headers");
    const h = await headers();
    const host = h.get("x-forwarded-host") ?? h.get("host");
    const proto = h.get("x-forwarded-proto") === "https" ? "https" : "http";
    if (host && HOST_RE.test(host)) return `${proto}://${host}`;
  } catch {
    // not inside a request
  }
  return "http://localhost:3000";
}
