import { z } from "zod";
import { extractJson } from "../json";
import { postJson } from "../http";
import { buildPrompt } from "../prompt";
import type { AIProvider, ProviderOptions } from "../types";

const ResponseSchema = z.object({
  content: z.array(z.object({ type: z.string(), text: z.string().optional() })),
});

// Model id is configurable (ANTHROPIC_MODEL). This default has NOT been verified against the live API.
const DEFAULT_MODEL = "claude-haiku-5-5";

export function createAnthropicProvider(opts: ProviderOptions): AIProvider {
  const model = opts.model || DEFAULT_MODEL;
  return {
    name: "anthropic",
    async generate(input) {
      const { system, user } = buildPrompt(input);
      const data = await postJson(
        "https://api.anthropic.com/v1/messages",
        { "x-api-key": opts.apiKey, "anthropic-version": "2023-06-01" },
        { model, max_tokens: 2000, system, messages: [{ role: "user", content: user }] },
        opts.fetchImpl,
        opts.timeoutMs,
      );
      const parsed = ResponseSchema.parse(data);
      const text = parsed.content.find((b) => b.type === "text")?.text;
      if (!text) throw new Error("Anthropic response had no text block");
      return extractJson(text);
    },
    async complete(system, user) {
      const data = await postJson(
        "https://api.anthropic.com/v1/messages",
        { "x-api-key": opts.apiKey, "anthropic-version": "2023-06-01" },
        { model, max_tokens: 800, system, messages: [{ role: "user", content: user }] },
        opts.fetchImpl,
        opts.timeoutMs,
      );
      const text = ResponseSchema.parse(data).content.find((b) => b.type === "text")?.text;
      if (!text) throw new Error("Anthropic response had no text block");
      return text;
    },
  };
}
