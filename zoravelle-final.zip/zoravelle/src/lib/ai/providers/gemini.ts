import { z } from "zod";
import { extractJson } from "../json";
import { postJson } from "../http";
import { buildPrompt } from "../prompt";
import type { AIProvider, ProviderOptions } from "../types";

const ResponseSchema = z.object({
  candidates: z
    .array(z.object({ content: z.object({ parts: z.array(z.object({ text: z.string().optional() })).optional() }).optional() }))
    .min(1),
});

/**
 * Google Gemini (the free tier of Google AI Studio works). The model is set with GEMINI_MODEL, so a
 * model that is retired or renamed is a config change, not a code change. This default has NOT been
 * verified against the live API from this build.
 * The key goes in the x-goog-api-key header, never in the URL, so it can't end up in a log line.
 */
const DEFAULT_MODEL = "gemini-2.5-flash";

export function createGeminiProvider(opts: ProviderOptions): AIProvider {
  const model = (opts.model || DEFAULT_MODEL).replace(/[^A-Za-z0-9._-]/g, "");
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`;
  const call = async (system: string, user: string, generationConfig: Record<string, unknown>) => {
    const data = await postJson(
      url,
      { "x-goog-api-key": opts.apiKey },
      {
        systemInstruction: { parts: [{ text: system }] },
        contents: [{ role: "user", parts: [{ text: user }] }],
        generationConfig,
      },
      opts.fetchImpl,
      opts.timeoutMs,
    );
    const text = ResponseSchema.parse(data).candidates[0]?.content?.parts?.map((p) => p.text ?? "").join("");
    if (!text) throw new Error("Gemini response was empty");
    return text;
  };
  return {
    name: "gemini",
    async generate(input) {
      const { system, user } = buildPrompt(input);
      return extractJson(await call(system, user, { responseMimeType: "application/json", temperature: 0.8 }));
    },
    async complete(system, user) {
      return call(system, user, { temperature: 0.9, maxOutputTokens: 700 });
    },
  };
}
