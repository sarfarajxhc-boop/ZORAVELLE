import { z } from "zod";
import { extractJson } from "../json";
import { postJson } from "../http";
import { buildPrompt } from "../prompt";
import type { AIProvider, ProviderOptions } from "../types";

const ResponseSchema = z.object({
  choices: z.array(z.object({ message: z.object({ content: z.string().nullable() }) })).min(1),
});

// Model id is configurable (OPENAI_MODEL). This default has NOT been verified against the live API.
const DEFAULT_MODEL = "gpt-4o-mini";

export function createOpenAIProvider(opts: ProviderOptions): AIProvider {
  const model = opts.model || DEFAULT_MODEL;
  return {
    name: "openai",
    async generate(input) {
      const { system, user } = buildPrompt(input);
      const data = await postJson(
        "https://api.openai.com/v1/chat/completions",
        { authorization: `Bearer ${opts.apiKey}` },
        {
          model,
          response_format: { type: "json_object" },
          messages: [
            { role: "system", content: system },
            { role: "user", content: user },
          ],
        },
        opts.fetchImpl,
        opts.timeoutMs,
      );
      const content = ResponseSchema.parse(data).choices[0]?.message.content;
      if (!content) throw new Error("OpenAI response was empty");
      return extractJson(content);
    },
    async complete(system, user) {
      const data = await postJson(
        "https://api.openai.com/v1/chat/completions",
        { authorization: `Bearer ${opts.apiKey}` },
        { model, messages: [{ role: "system", content: system }, { role: "user", content: user }] },
        opts.fetchImpl,
        opts.timeoutMs,
      );
      const content = ResponseSchema.parse(data).choices[0]?.message.content;
      if (!content) throw new Error("OpenAI response was empty");
      return content;
    },
  };
}
