import type { ExperienceConfig } from "@/lib/experience/schema";
import { getOccasion } from "@/lib/occasions/registry";
import { isDark } from "@/lib/experience/contrast";
import type { AIProvider } from "../types";

type Theme = ExperienceConfig["theme"];

const STYLES: Record<string, Pick<Theme, "background" | "fontPair">> = {
  "Soft and warm": { background: "softGradient", fontPair: "romanticScript" },
  "Bold and bright": { background: "aurora", fontPair: "modernSans" },
  Elegant: { background: "paperTexture", fontPair: "elegantSerif" },
  Playful: { background: "bokeh", fontPair: "playfulRounded" },
};

/** accent + accentSoft tuned for light and dark backgrounds. Text colours are never touched. */
const COLOURS: Record<string, { light: [string, string]; dark: [string, string] }> = {
  Gold: { light: ["#b45309", "#fde68a"], dark: ["#fbbf24", "#78350f"] },
  Crimson: { light: ["#b51224", "#f1d4d7"], dark: ["#e24455", "#5a0a14"] },
  Blue: { light: ["#1d4ed8", "#bfdbfe"], dark: ["#60a5fa", "#1e3a8a"] },
  Green: { light: ["#15803d", "#bbf7d0"], dark: ["#4ade80", "#14532d"] },
  Black: { light: ["#111111", "#e4e4e4"], dark: ["#d4af6a", "#2a2a2a"] },
  Sunset: { light: ["#ea580c", "#fed7aa"], dark: ["#fb923c", "#7c2d12"] },
};

/** Deterministic offline provider. Used with no API key, and as the fallback. */
export const mockProvider: AIProvider = {
  name: "mock",
  async generate(input) {
    const o = getOccasion(input.occasion) ?? getOccasion("custom")!;
    const label = input.customOccasionLabel ?? o.label;
    const title = input.customOccasionLabel ?? o.title;

    const style = input.themeHint ? STYLES[input.themeHint] : undefined;
    const colour = input.colorHint ? COLOURS[input.colorHint] : undefined;
    const [accent, accentSoft] = colour
      ? colour[isDark(o.palette.background) ? "dark" : "light"]
      : [o.palette.accent, o.palette.accentSoft];

    const config: ExperienceConfig = {
      version: 1,
      occasion: o.id,
      theme: {
        name: `${label} theme`,
        palette: { ...o.palette, accent, accentSoft },
        fontPair: style?.fontPair ?? o.fontPair,
        background: style?.background ?? o.background,
      },
      ambient: { effect: o.ambient, intensity: 3 },
      blocks: [
        {
          type: "hero",
          scene: o.scene,
          headline: `${title}, ${input.recipientName}!`,
          subheadline: `A little something from ${input.senderName}`,
        },
        { type: "interaction", kind: o.interaction.kind, prompt: o.interaction.prompt },
        {
          type: "message",
          body: input.message || `Wishing you a wonderful ${label.toLowerCase()}, ${input.recipientName}.`,
          signoff: `With love, ${input.senderName}`,
        },
        {
          type: "surprise",
          buttonLabel: "One more thing",
          scene: "confettiPop",
          text: `Thank you for being you, ${input.recipientName}.`,
        },
      ],
    };
    return config;
  },
};
