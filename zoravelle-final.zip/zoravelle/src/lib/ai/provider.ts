import { CreatorInput, ExperienceConfig, ExperienceConfigSchema } from "@/lib/experience/schema";
import { getOccasion } from "@/lib/occasions/registry";
import { finalizeConfig } from "./finalize";
import { mockProvider } from "./providers/mock";
import { createAnthropicProvider } from "./providers/anthropic";
import { createOpenAIProvider } from "./providers/openai";
import { createGeminiProvider } from "./providers/gemini";
import type { AIProvider } from "./types";

export type { AIProvider } from "./types";
export { mockProvider } from "./providers/mock";

/** Extra providers registered at runtime (e.g. an image or text service added later). */
const custom: Record<string, AIProvider> = {};
export function registerProvider(p: AIProvider) {
  custom[p.name] = p;
}

/**
 * Maps AI_PROVIDER to an implementation. Returns null when the chosen provider
 * is not configured (missing API key), so the caller can fall back visibly.
 * API keys are read here, server-side only, and never leave this module.
 */
export function resolveProvider(name: string): AIProvider | null {
  if (name === "mock") return mockProvider;
  const registered = custom[name];
  if (registered) return registered;
  if (name === "anthropic") {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    return apiKey ? createAnthropicProvider({ apiKey, model: process.env.ANTHROPIC_MODEL }) : null;
  }
  if (name === "openai") {
    const apiKey = process.env.OPENAI_API_KEY;
    return apiKey ? createOpenAIProvider({ apiKey, model: process.env.OPENAI_MODEL }) : null;
  }
  if (name === "gemini") {
    const apiKey = process.env.GEMINI_API_KEY;
    return apiKey ? createGeminiProvider({ apiKey, model: process.env.GEMINI_MODEL }) : null;
  }
  return null;
}

export type GenerationResult =
  | { ok: true; config: ExperienceConfig; provider: string; usedFallback: boolean }
  | { ok: false; error: string };

const ATTEMPTS = 2;

/** Log only short, non-user-derived reasons. Never log prompts, inputs or response bodies. */
const warn = (provider: string, attempt: number, reason: string) =>
  console.warn(`[ai] ${provider} attempt ${attempt} failed: ${reason}`);

/**
 * Validate, retry once, then fall back to the offline template. The returned
 * config is always schema-valid and finalized. `override` lets tests inject a provider.
 */
export async function generateExperience(
  input: CreatorInput,
  providerName = "mock",
  override?: AIProvider,
): Promise<GenerationResult> {
  const occasion = getOccasion(input.occasion) ?? getOccasion("custom")!;
  const provider = override ?? resolveProvider(providerName);

  if (provider && provider.name !== "mock") {
    for (let attempt = 1; attempt <= ATTEMPTS; attempt++) {
      try {
        const raw = await provider.generate(input);
        const parsed = ExperienceConfigSchema.safeParse(raw);
        if (!parsed.success) {
          const why = parsed.error.issues.slice(0, 3).map((i) => `${i.path.join(".")}:${i.code}`).join(", ");
          warn(provider.name, attempt, `schema ${why}`);
          continue;
        }
        const config = finalizeConfig(parsed.data, input, occasion);
        return { ok: true, config, provider: provider.name, usedFallback: false };
      } catch (e) {
        warn(provider.name, attempt, e instanceof Error ? e.message.slice(0, 80) : "unknown error");
      }
    }
  } else if (!provider) {
    console.warn(`[ai] provider "${providerName}" is not configured; using the offline template`);
  }

  try {
    const parsed = ExperienceConfigSchema.safeParse(await mockProvider.generate(input));
    if (parsed.success) {
      return {
        ok: true,
        config: finalizeConfig(parsed.data, input, occasion),
        provider: "mock",
        // Fallback means "you asked for real AI and didn't get it".
        usedFallback: providerName !== "mock" || (provider !== null && provider.name !== "mock"),
      };
    }
  } catch {
    // fall through
  }
  return { ok: false, error: "Could not generate a valid experience." };
}
