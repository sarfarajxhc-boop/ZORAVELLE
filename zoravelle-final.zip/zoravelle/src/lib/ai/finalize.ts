import type { Block, CreatorInput, ExperienceConfig } from "@/lib/experience/schema";
import type { OccasionDef } from "@/lib/occasions/registry";
import { contrastRatio } from "@/lib/experience/contrast";

const MAX_BLOCKS = 8;

/**
 * Runs AFTER schema validation. Enforces rules a model cannot be trusted with:
 * - the occasion is the one the creator chose
 * - the creator's own message is shown exactly as written
 * - a gallery can only reference assets this creator actually supplied
 * - text stays readable (WCAG AA), otherwise the occasion's own palette is used
 * Throws if the structure is unusable, which triggers a retry or the fallback.
 */
export function finalizeConfig(
  config: ExperienceConfig,
  input: CreatorInput,
  occasion: OccasionDef,
): ExperienceConfig {
  let blocks: Block[] = [...config.blocks];

  const heroAt = blocks.findIndex((b) => b.type === "hero");
  if (heroAt < 0) throw new Error("Missing hero block");
  if (heroAt > 0) blocks.unshift(...blocks.splice(heroAt, 1));

  const messageAt = blocks.findIndex((b) => b.type === "message");
  if (messageAt < 0) throw new Error("Missing message block");
  const userMessage = input.message?.trim();
  const msg = blocks[messageAt];
  if (userMessage && msg?.type === "message") blocks[messageAt] = { ...msg, body: userMessage };

  const owned = new Set(input.assetIds);
  const kept: Block[] = [];
  let hasGallery = false;
  for (const b of blocks) {
    if (b.type !== "gallery") { kept.push(b); continue; }
    const ids = b.assetIds.filter((id) => owned.has(id));
    if (ids.length > 0 && !hasGallery) {
      kept.push({ ...b, assetIds: ids });
      hasGallery = true;
    }
  }
  blocks = kept;
  if (!hasGallery && input.assetIds.length > 0) {
    const at = blocks.findIndex((b) => b.type === "message");
    blocks.splice(at + 1, 0, { type: "gallery", assetIds: input.assetIds.slice(0, 6) });
  }
  if (blocks.length > MAX_BLOCKS) blocks.length = MAX_BLOCKS;

  const p = config.theme.palette;
  const readable = contrastRatio(p.text, p.background) >= 4.5 && contrastRatio(p.text, p.surface) >= 4.5;
  const theme = readable ? config.theme : { ...config.theme, palette: occasion.palette };

  return { ...config, version: 1, occasion: input.occasion, theme, blocks };
}
