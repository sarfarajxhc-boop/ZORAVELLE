import type { CreatorInput } from "@/lib/experience/schema";

/**
 * A provider returns UNTRUSTED data (`unknown`). Nothing it returns reaches the
 * app until generateExperience() has validated and finalized it.
 */
export interface AIProvider {
  readonly name: string;
  generate(input: CreatorInput): Promise<unknown>;
  /** Plain-text completion, used by "Write with AI". Optional: a provider without it uses the template. */
  complete?(system: string, user: string): Promise<string>;
}

export type ProviderOptions = {
  apiKey: string;
  model?: string;
  /** Injectable for tests. Defaults to global fetch. */
  fetchImpl?: typeof fetch;
  timeoutMs?: number;
};
