import "server-only";
import { createHmac, timingSafeEqual } from "node:crypto";
import { env } from "@/lib/env";

export const ADMIN_COOKIE = "wc_admin";
export const SESSION_SECONDS = 8 * 60 * 60;
const MIN_TOKEN_LENGTH = 24;

/** Admin is off unless ADMIN_TOKEN is set to a long random value. */
export const adminEnabled = (): boolean => (env.ADMIN_TOKEN?.length ?? 0) >= MIN_TOKEN_LENGTH;

const sign = (payload: string): string =>
  createHmac("sha256", env.ADMIN_TOKEN ?? "").update(`admin-session:${payload}`).digest("base64url");

export function safeEqual(a: string, b: string): boolean {
  const ha = createHmac("sha256", "cmp").update(a).digest();
  const hb = createHmac("sha256", "cmp").update(b).digest();
  return timingSafeEqual(ha, hb);
}

export function passwordMatches(candidate: unknown): boolean {
  return adminEnabled() && typeof candidate === "string" && safeEqual(candidate, env.ADMIN_TOKEN ?? "");
}

/** Cookie value: "<expiry-epoch-seconds>.<signature>". Changing ADMIN_TOKEN signs everyone out. */
export function createSessionValue(now = Date.now()): string {
  const exp = String(Math.floor(now / 1000) + SESSION_SECONDS);
  return `${exp}.${sign(exp)}`;
}

export function verifySessionValue(value: string | undefined | null, now = Date.now()): boolean {
  if (!adminEnabled() || !value) return false;
  const [exp, sig, ...rest] = value.split(".");
  if (!exp || !sig || rest.length > 0 || !/^\d{1,12}$/.test(exp)) return false;
  if (Number(exp) * 1000 <= now) return false;
  return safeEqual(sig, sign(exp));
}

/** For server components and actions. */
export async function isAdmin(): Promise<boolean> {
  const { cookies } = await import("next/headers");
  return verifySessionValue((await cookies()).get(ADMIN_COOKIE)?.value);
}
