/**
 * Time helpers for the Moment Delivery System. Shared by browser and server.
 * Instants are always UTC (ISO strings / Date). A time zone is kept only to show the time the way
 * the creator picked it. No library: everything uses Intl.
 */

/** A lock must be at least this far ahead, and at most this far ahead. */
export const MIN_LEAD_MS = 60_000;
export const MAX_LEAD_MS = 366 * 24 * 3600_000;
export const DEFAULT_TIMEZONE = "Asia/Kolkata";

export const COMMON_ZONES: ReadonlyArray<{ id: string; label: string }> = [
  { id: "Asia/Kolkata", label: "India (IST)" },
  { id: "Asia/Dhaka", label: "Bangladesh" },
  { id: "Asia/Karachi", label: "Pakistan" },
  { id: "Asia/Dubai", label: "Dubai (GST)" },
  { id: "Asia/Riyadh", label: "Saudi Arabia" },
  { id: "Asia/Singapore", label: "Singapore" },
  { id: "Asia/Tokyo", label: "Japan" },
  { id: "Europe/London", label: "London" },
  { id: "Europe/Paris", label: "Paris / Berlin" },
  { id: "America/New_York", label: "New York" },
  { id: "America/Chicago", label: "Chicago" },
  { id: "America/Los_Angeles", label: "Los Angeles" },
  { id: "Australia/Sydney", label: "Sydney" },
  { id: "UTC", label: "UTC" },
];

export function isValidTimeZone(tz: unknown): tz is string {
  if (typeof tz !== "string" || tz.length < 1 || tz.length > 64) return false;
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: tz });
    return true;
  } catch {
    return false;
  }
}

/** Wall-clock parts of an instant, as seen in `tz`. */
export function partsInZone(ms: number, tz: string) {
  const f = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz, hourCycle: "h23",
    year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit",
  });
  const o: Record<string, number> = {};
  for (const p of f.formatToParts(new Date(ms))) if (p.type !== "literal") o[p.type] = Number(p.value);
  return { year: o.year ?? 0, month: o.month ?? 0, day: o.day ?? 0, hour: o.hour ?? 0, minute: o.minute ?? 0, second: o.second ?? 0 };
}

/** Offset (ms) of `tz` from UTC at the given instant. */
function zoneOffsetMs(ms: number, tz: string): number {
  const p = partsInZone(ms, tz);
  return Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(ms / 1000) * 1000;
}

/**
 * The UTC instant at which the wall clock in `tz` reads the given date and time.
 * Returns null when that wall time does not exist in that zone (a spring-forward gap).
 * An ambiguous time (autumn repeat) resolves to the first occurrence.
 */
export function zonedWallToUtc(
  date: string, // YYYY-MM-DD
  time: string, // HH:mm
  tz: string,
): Date | null {
  const d = /^(\d{4})-(\d{2})-(\d{2})$/.exec(date);
  const t = /^(\d{2}):(\d{2})$/.exec(time);
  if (!d || !t || !isValidTimeZone(tz)) return null;
  const [y, mo, da, h, mi] = [d[1], d[2], d[3], t[1], t[2]].map(Number) as [number, number, number, number, number];
  if (mo < 1 || mo > 12 || da < 1 || da > 31 || h > 23 || mi > 59) return null;
  const asUtc = Date.UTC(y, mo - 1, da, h, mi);
  let guess = asUtc - zoneOffsetMs(asUtc, tz);
  guess = asUtc - zoneOffsetMs(guess, tz); // second pass settles offset changes near the guess
  const back = partsInZone(guess, tz);
  if (back.year !== y || back.month !== mo || back.day !== da || back.hour !== h || back.minute !== mi) return null;
  return new Date(guess);
}

export type UnlockProblem = "invalid" | "past" | "tooSoon" | "tooFar";

/** The single rule both the browser and the server apply. */
export function checkUnlock(unlockAt: Date, now: Date): UnlockProblem | null {
  const t = unlockAt.getTime();
  if (!Number.isFinite(t)) return "invalid";
  if (t <= now.getTime()) return "past";
  if (t - now.getTime() < MIN_LEAD_MS) return "tooSoon";
  if (t - now.getTime() > MAX_LEAD_MS) return "tooFar";
  return null;
}

export const UNLOCK_PROBLEM_TEXT: Record<UnlockProblem, string> = {
  invalid: "That date and time isn't valid.",
  past: "That time has already passed. Pick a time in the future.",
  tooSoon: "Pick a time at least a minute from now.",
  tooFar: "Pick a time within the next year.",
};

export function formatInZone(ms: number, tz: string | undefined, opts?: Intl.DateTimeFormatOptions): string {
  return new Intl.DateTimeFormat(undefined, {
    timeZone: tz && isValidTimeZone(tz) ? tz : undefined,
    weekday: "short", day: "numeric", month: "long", year: "numeric",
    hour: "numeric", minute: "2-digit", timeZoneName: "short",
    ...opts,
  }).format(new Date(ms));
}

export function splitRemaining(ms: number) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return {
    days: Math.floor(total / 86400),
    hours: Math.floor((total % 86400) / 3600),
    minutes: Math.floor((total % 3600) / 60),
    seconds: total % 60,
  };
}

/** Today's date (YYYY-MM-DD) as seen in `tz`, for date-picker minimums. */
export function todayInZone(tz: string, now = new Date()): string {
  const p = partsInZone(now.getTime(), tz);
  return `${String(p.year).padStart(4, "0")}-${String(p.month).padStart(2, "0")}-${String(p.day).padStart(2, "0")}`;
}
