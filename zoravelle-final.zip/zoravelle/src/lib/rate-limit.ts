/**
 * Sliding-window limiter, in memory.
 * LIMITATION: state lives in one server instance. On serverless hosting each
 * instance counts separately, so this is a best-effort brake, not a guarantee.
 * With Supabase configured, src/lib/limiter.ts counts in the database instead (migration 0002), so
 * limits hold across instances; this in-memory limiter is the fallback.
 */
const hits = new Map<string, number[]>();
const PRUNE_AT = 5000;

export type LimitResult = { ok: true } | { ok: false; retryAfterSec: number };

export function checkRateLimit(key: string, limit: number, windowMs: number, now = Date.now()): LimitResult {
  const recent = (hits.get(key) ?? []).filter((t) => now - t < windowMs);
  if (recent.length >= limit) {
    const oldest = recent[0] ?? now;
    return { ok: false, retryAfterSec: Math.max(1, Math.ceil((oldest + windowMs - now) / 1000)) };
  }
  recent.push(now);
  hits.set(key, recent);

  if (hits.size > PRUNE_AT) {
    for (const [k, v] of hits) {
      if (v.every((t) => now - t >= windowMs)) hits.delete(k);
    }
  }
  return { ok: true };
}

/** Test helper. */
export function resetRateLimits() {
  hits.clear();
}
