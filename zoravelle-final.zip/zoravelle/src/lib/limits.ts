export const HOUR = 60 * 60 * 1000;

/**
 * Per-IP abuse limits for actions that create database rows or use CPU.
 * (AI generation has its own, configurable quota in env.ts.)
 * Counted in Postgres when Supabase is configured (so the limit holds across server instances), and in
 * memory otherwise. If the database call fails, the request falls back to the local counter.
 */
export const LIMITS = {
  draft: { max: 10, windowMs: HOUR },
  upload: { max: 40, windowMs: HOUR },
  publish: { max: 20, windowMs: HOUR },
  write: { max: 30, windowMs: HOUR },
  edit: { max: 60, windowMs: HOUR },
  manage: { max: 60, windowMs: HOUR },
} as const;

export type LimitKind = keyof typeof LIMITS;
