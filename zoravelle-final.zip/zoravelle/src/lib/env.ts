import { z } from "zod";

/**
 * Environment parsing. Everything is optional so the app boots in demo mode
 * with zero configuration. Server-only values must never be imported from
 * client components.
 */
const schema = z.object({
  // A malformed URL must never take the whole site down, so bad values fall back instead of throwing.
  NEXT_PUBLIC_SITE_URL: z.string().url().default("http://localhost:3000").catch("http://localhost:3000"),
  NEXT_PUBLIC_SUPABASE_URL: z.string().url().optional().or(z.literal("").transform(() => undefined)).catch(undefined),
  NEXT_PUBLIC_SUPABASE_ANON_KEY: z.string().optional().or(z.literal("").transform(() => undefined)),
  // Checked for length where used. A too-short value disables the feature instead of crashing the app.
  ADMIN_TOKEN: z.string().optional(),
  CRON_SECRET: z.string().optional(),
  AI_PROVIDER: z.string().default("mock"),
  AI_GENERATIONS_PER_HOUR: z.coerce.number().int().positive().default(5),
  AI_DAILY_GENERATION_CAP: z.coerce.number().int().positive().default(500),
});

const parsed = schema.parse({
  NEXT_PUBLIC_SITE_URL: process.env.NEXT_PUBLIC_SITE_URL || undefined,
  NEXT_PUBLIC_SUPABASE_URL: process.env.NEXT_PUBLIC_SUPABASE_URL,
  NEXT_PUBLIC_SUPABASE_ANON_KEY: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  ADMIN_TOKEN: process.env.ADMIN_TOKEN,
  CRON_SECRET: process.env.CRON_SECRET,
  AI_PROVIDER: process.env.AI_PROVIDER || undefined,
  AI_GENERATIONS_PER_HOUR: process.env.AI_GENERATIONS_PER_HOUR || undefined,
  AI_DAILY_GENERATION_CAP: process.env.AI_DAILY_GENERATION_CAP || undefined,
});

export const env = parsed;

export const hasSupabase = Boolean(env.NEXT_PUBLIC_SUPABASE_URL && env.NEXT_PUBLIC_SUPABASE_ANON_KEY);

/** True when the app is running without a database or a real AI provider. */
export const isDemoMode = !hasSupabase || env.AI_PROVIDER === "mock";
