import "server-only";
import { getAdminClient } from "./supabase-clients";
import { createSupabaseStore } from "./supabase";
import { createMemoryStore } from "./memory";
import type { ExperienceStore } from "./types";

export * from "./types";

const g = globalThis as unknown as { __zoravelleStore?: ExperienceStore };

/**
 * Supabase when SUPABASE_SERVICE_ROLE_KEY and the project URL are set;
 * otherwise an in-memory demo store (lost on restart, not shared across instances).
 */
export function getStore(): ExperienceStore {
  if (g.__zoravelleStore) return g.__zoravelleStore;
  const admin = getAdminClient();
  if (admin) {
    g.__zoravelleStore = createSupabaseStore(admin);
  } else {
    console.warn("[store] Supabase is not configured: using the in-memory demo store (data is lost on restart).");
    g.__zoravelleStore = createMemoryStore();
  }
  return g.__zoravelleStore;
}

/** True when greetings survive restarts and open on any server instance. */
export const isPersistentStore = (): boolean => getStore().kind === "supabase";
