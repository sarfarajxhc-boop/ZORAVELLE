import { ExperienceConfigSchema, type ExperienceConfig } from "@/lib/experience/schema";
import { SLUG_RE } from "@/lib/security/tokens";
import { sniffImageType } from "@/lib/assets/sniff";
import { checkUnlock, isValidTimeZone, UNLOCK_PROBLEM_TEXT } from "@/lib/schedule/time";
import { REPORT_REASONS, StoreError, type DraftInput, type ReportReason, type Schedule } from "./types";

export const BUCKET = "experience-assets";
export const MAX_ASSETS_PER_EXPERIENCE = 6;
export const MAX_ASSET_BYTES = 5 * 1024 * 1024;
export const DRAFT_TTL_DAYS = 7;
export const DEFAULT_SIGNED_URL_TTL_SEC = 3600;

const OCCASION_RE = /^[a-z0-9-]{2,40}$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

export const isUuid = (v: unknown): v is string => typeof v === "string" && UUID_RE.test(v);
export const isSlug = (v: unknown): v is string => typeof v === "string" && SLUG_RE.test(v);

/** Server-side rule for a lock. Never trusts the browser clock or the browser's checks. */
export function assertSchedule(schedule: Schedule | undefined, now: Date, expiresAt: Date | null): void {
  if (!schedule) return;
  if (!(schedule.unlockAt instanceof Date) || !isValidTimeZone(schedule.timezone)) {
    throw new StoreError("invalid", "That unlock time isn't valid.");
  }
  const problem = checkUnlock(schedule.unlockAt, now);
  if (problem) throw new StoreError("invalid", UNLOCK_PROBLEM_TEXT[problem]);
  if (expiresAt && schedule.unlockAt >= expiresAt) {
    throw new StoreError("invalid", "That time is after this greeting expires. Pick an earlier time.");
  }
}

const name = (v: unknown) => typeof v === "string" && v.trim().length >= 1 && v.length <= 60;

/** Mirrors the database CHECK constraints so the demo store behaves like the real one. */
export function assertDraftInput(i: DraftInput): void {
  if (!OCCASION_RE.test(i.occasion)) throw new StoreError("invalid", "Unknown occasion.");
  if (!name(i.recipientName)) throw new StoreError("invalid", "Recipient name must be 1 to 60 characters.");
  if (!name(i.senderName)) throw new StoreError("invalid", "Sender name must be 1 to 60 characters.");
}

/**
 * Validate a config at the storage boundary and make sure every gallery photo
 * belongs to this experience. Returns the parsed (stripped, typed) config.
 */
export function parseConfigForExperience(
  raw: unknown,
  occasion: string,
  ownedAssetIds: ReadonlySet<string>,
): ExperienceConfig {
  const parsed = ExperienceConfigSchema.safeParse(raw);
  if (!parsed.success) throw new StoreError("invalid", "That greeting configuration isn't valid.");
  const config = parsed.data;
  if (config.occasion !== occasion) throw new StoreError("invalid", "The occasion can't be changed.");
  for (const block of config.blocks) {
    if (block.type === "gallery" && block.assetIds.some((id) => !ownedAssetIds.has(id))) {
      throw new StoreError("invalid", "The gallery uses a photo that isn't part of this greeting.");
    }
  }
  return config;
}

/** Validates a recipient or sender name and returns it trimmed. */
export function assertPersonName(v: string, label: string): string {
  if (!name(v)) throw new StoreError("invalid", `${label} must be 1 to 60 characters.`);
  return v.trim();
}

export function assertMessage(message: string | null | undefined): string | null {
  if (message == null) return null;
  if (message.length > 1200) throw new StoreError("invalid", "The message is too long.");
  return message;
}

/** Final gate before bytes are stored: must be non-empty, within size, and a WebP produced by processImage(). */
export function assertStorableImage(data: Uint8Array): void {
  if (data.length === 0 || data.length > MAX_ASSET_BYTES || sniffImageType(data) !== "webp") {
    throw new StoreError("invalid", "That image can't be stored.");
  }
}

/** Parse a stored config defensively on read. Corrupt rows are treated as "not found". */
export function readConfig(raw: unknown): ExperienceConfig | null {
  const parsed = ExperienceConfigSchema.safeParse(raw);
  return parsed.success ? parsed.data : null;
}

export const MAX_REPORT_DETAILS = 500;

/** Headline text of a stored config, for admin lists. */
export function headlineOf(config: ExperienceConfig | null): string | null {
  const h = config?.blocks.find((b) => b.type === "hero");
  return h?.type === "hero" ? h.headline : null;
}

export function assertReport(reason: unknown, details: unknown): { reason: ReportReason; details: string | null } {
  if (typeof reason !== "string" || !(REPORT_REASONS as readonly string[]).includes(reason)) {
    throw new StoreError("invalid", "Choose a reason for the report.");
  }
  if (details != null && (typeof details !== "string" || details.length > MAX_REPORT_DETAILS)) {
    throw new StoreError("invalid", `Details can be up to ${MAX_REPORT_DETAILS} characters.`);
  }
  const d = typeof details === "string" ? details.trim() : "";
  return { reason: reason as ReportReason, details: d || null };
}
