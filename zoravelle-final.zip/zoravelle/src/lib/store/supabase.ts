import "server-only";
import { randomUUID } from "node:crypto";
import type { SupabaseClient } from "@supabase/supabase-js";
import { generateEditToken, generateSlug, hashToken, tokenMatchesHash } from "@/lib/security/tokens";
import {
  BUCKET, DEFAULT_SIGNED_URL_TTL_SEC, DRAFT_TTL_DAYS, MAX_ASSETS_PER_EXPERIENCE,
  assertDraftInput, assertMessage, assertPersonName, assertSchedule, assertReport, assertStorableImage, headlineOf, isSlug, isUuid, parseConfigForExperience, readConfig,
} from "./shared";
import {
  StoreError, type AdminExperience, type AdminReport, type ExperienceStore, type OwnedExperience, type PublishedExperience, type ReportReason, type ViewState,
} from "./types";
import { getAdminClient, getAnonClient } from "./supabase-clients";

type Row = Record<string, unknown>;
type DbError = { code?: string; message?: string } | null;

const DAY_MS = 86_400_000;
const PURGE_BATCH = 200;

/** Log a short code only, never row contents, then surface a retryable error. */
function unavailable(what: string, err: DbError): never {
  console.warn(`[store] ${what} failed: ${err?.code ?? "unknown"}`);
  throw new StoreError("unavailable", "Something went wrong saving your greeting. Please try again.");
}

const str = (v: unknown): string | null => (typeof v === "string" ? v : null);

/**
 * Supabase-backed store.
 * NOT YET RUN against a real project: it is written to the supabase-js API and
 * checked only by the SQL tests (schema, policies) and by the shared contract
 * test, which you can point at a development project with `npm run test:store`.
 */
export function createSupabaseStore(admin: SupabaseClient = requireAdmin()): ExperienceStore {
  async function authorize(id: string, token: string): Promise<Row> {
    const forbidden = new StoreError("forbidden", "That edit link doesn't match this greeting.");
    if (!isUuid(id)) throw forbidden;
    const { data, error } = await admin
      .from("experiences")
      .select("id, slug, occasion, edit_token_hash, configuration, published, recipient_name, sender_name, created_at, expires_at, unlock_at, unlock_timezone")
      .eq("id", id)
      .maybeSingle();
    if (error) unavailable("authorize", error);
    if (!data || !tokenMatchesHash(token, data.edit_token_hash)) throw forbidden;
    return data as Row;
  }

  async function assetPaths(experienceIds: string[]): Promise<string[]> {
    if (experienceIds.length === 0) return [];
    const { data, error } = await admin.from("assets").select("file_path").in("experience_id", experienceIds);
    if (error) unavailable("list assets", error);
    const rows = (data ?? []) as Row[];
    return rows.map((r) => str(r.file_path)).filter((p): p is string => p !== null);
  }

  async function removeFiles(paths: string[]) {
    for (let i = 0; i < paths.length; i += 100) {
      const { error } = await admin.storage.from(BUCKET).remove(paths.slice(i, i + 100));
      if (error) console.warn("[store] storage remove failed");
    }
  }

  return {
    kind: "supabase",

    async createDraft(input, opts) {
      assertDraftInput(input);
      for (let attempt = 0; attempt < 5; attempt++) {
        const slug = generateSlug();
        const editToken = generateEditToken();
        const { data, error } = await admin
          .from("experiences")
          .insert({
            slug,
            occasion: input.occasion,
            recipient_name: input.recipientName.trim(),
            sender_name: input.senderName.trim(),
            edit_token_hash: hashToken(editToken),
            expires_at: opts?.expiresAt ? opts.expiresAt.toISOString() : null,
          })
          .select("id")
          .single();
        if (error?.code === "23505") continue; // slug collision: pick another
        if (error || !data) unavailable("create draft", error);
        return { id: String(data.id), slug, editToken };
      }
      throw new StoreError("unavailable", "Couldn't allocate a share link. Please try again.");
    },

    async saveConfiguration(id, token, config, meta) {
      const rec = await authorize(id, token);
      const { data: owned, error: e1 } = await admin.from("assets").select("id").eq("experience_id", id);
      if (e1) unavailable("list assets", e1);
      const ownedIds = new Set<string>(((owned ?? []) as Row[]).map((r) => String(r.id)));
      const parsed = parseConfigForExperience(config, String(rec.occasion), ownedIds);
      const message = assertMessage(meta?.message);
      const patch: Row = { configuration: parsed, message, theme: parsed.theme.name };
      if (meta?.recipientName !== undefined) patch.recipient_name = assertPersonName(meta.recipientName, "Recipient name");
      if (meta?.senderName !== undefined) patch.sender_name = assertPersonName(meta.senderName, "Sender name");
      const { error } = await admin.from("experiences").update(patch).eq("id", id);
      if (error) unavailable("save configuration", error);
    },

    async getOwned(id, token): Promise<OwnedExperience> {
      const rec = await authorize(id, token);
      const { data, error } = await admin.from("assets").select("id").eq("experience_id", id);
      if (error) unavailable("list assets", error);
      return {
        id: String(rec.id), slug: String(rec.slug), occasion: String(rec.occasion),
        recipientName: String(rec.recipient_name), senderName: String(rec.sender_name),
        published: rec.published === true, hasConfiguration: readConfig(rec.configuration) !== null,
        assetIds: ((data ?? []) as Row[]).map((r) => String(r.id)),
        createdAt: String(rec.created_at), expiresAt: str(rec.expires_at),
        unlockAt: str(rec.unlock_at), unlockTimezone: str(rec.unlock_timezone),
      };
    },

    async addAsset(id, token, image) {
      await authorize(id, token);
      assertStorableImage(image.data);
      const assetId = randomUUID();
      const filePath = `${id}/${assetId}.webp`;

      // Row first: the database trigger enforces the per-greeting photo limit.
      const { error: insErr } = await admin.from("assets").insert({
        id: assetId, experience_id: id, file_path: filePath, mime_type: "image/webp", byte_size: image.data.length,
      });
      if (insErr?.code === "23514") {
        throw new StoreError("limit", `You can add up to ${MAX_ASSETS_PER_EXPERIENCE} photos.`);
      }
      if (insErr) unavailable("insert asset", insErr);

      const { error: upErr } = await admin.storage
        .from(BUCKET)
        .upload(filePath, image.data, { contentType: "image/webp", upsert: false });
      if (upErr) {
        await admin.from("assets").delete().eq("id", assetId); // don't leave a row without a file
        unavailable("upload asset", { message: upErr.message });
      }
      return { id: assetId, byteSize: image.data.length };
    },

    async removeAsset(id, token, assetId) {
      await authorize(id, token);
      if (!isUuid(assetId)) return;
      const { data, error } = await admin
        .from("assets").select("file_path").eq("id", assetId).eq("experience_id", id).maybeSingle();
      if (error) unavailable("find asset", error);
      const path = str(data?.file_path);
      if (!path) return;
      await removeFiles([path]);
      const { error: delErr } = await admin.from("assets").delete().eq("id", assetId).eq("experience_id", id);
      if (delErr) unavailable("delete asset", delErr);
    },

    async publish(id, token, schedule) {
      const rec = await authorize(id, token);
      if (!readConfig(rec.configuration)) {
        throw new StoreError("invalid", "Generate your greeting before publishing.");
      }
      const exp = str(rec.expires_at);
      assertSchedule(schedule, new Date(), exp ? new Date(exp) : null);
      const { data: current, error: e1 } = await admin.from("experiences").select("published_at").eq("id", id).single();
      if (e1) unavailable("read publish state", e1);
      const { error } = await admin
        .from("experiences")
        .update({
          published: true,
          published_at: str(current?.published_at) ?? new Date().toISOString(),
          unlock_at: schedule ? schedule.unlockAt.toISOString() : null,
          unlock_timezone: schedule ? schedule.timezone : null,
        })
        .eq("id", id);
      if (error) unavailable("publish", error);
      return {
        slug: String(rec.slug),
        unlockAt: schedule ? schedule.unlockAt.toISOString() : null,
        unlockTimezone: schedule ? schedule.timezone : null,
      };
    },

    async setSchedule(id, token, schedule) {
      const rec = await authorize(id, token);
      const now = new Date();
      if (rec.published !== true) throw new StoreError("invalid", "Publish the greeting first.");
      const current = str(rec.unlock_at);
      if (!current || new Date(current) <= now) {
        throw new StoreError("invalid", "This greeting is already open, so it can't be locked again.");
      }
      const exp = str(rec.expires_at);
      assertSchedule(schedule, now, exp ? new Date(exp) : null);
      const patch = {
        unlock_at: schedule ? schedule.unlockAt.toISOString() : null,
        unlock_timezone: schedule ? schedule.timezone : null,
      };
      // Guarded in SQL as well, so a greeting that opens between the read and the write can't be re-locked.
      const { data, error } = await admin
        .from("experiences").update(patch).eq("id", id).gt("unlock_at", now.toISOString()).select("id");
      if (error) unavailable("set schedule", error);
      if (!data || data.length === 0) {
        throw new StoreError("invalid", "This greeting is already open, so it can't be locked again.");
      }
      return { unlockAt: patch.unlock_at, unlockTimezone: patch.unlock_timezone };
    },

    async deleteExperience(id, token) {
      await authorize(id, token);
      await removeFiles(await assetPaths([id]));
      const { error } = await admin.from("experiences").delete().eq("id", id); // cascades to assets, generations
      if (error) unavailable("delete experience", error);
    },

    async getPublishedBySlug(slug): Promise<PublishedExperience | null> {
      if (!isSlug(slug)) return null;
      const cols = "id, slug, occasion, recipient_name, sender_name, configuration, published_at, expires_at";
      const anon = getAnonClient();

      let row: Row | null;
      if (anon) {
        // Row Level Security decides visibility: published, not hidden, not expired.
        // (published / hidden_at aren't granted to this role, so we can't filter on them here.)
        const { data, error } = await anon.from("experiences").select(cols).eq("slug", slug).maybeSingle();
        if (error) unavailable("public read", error);
        row = (data as Row | null) ?? null;
      } else {
        const { data, error } = await admin
          .from("experiences").select(`${cols}, unlock_at`).eq("slug", slug).eq("published", true).is("hidden_at", null).maybeSingle();
        if (error) unavailable("public read", error);
        row = (data as Row | null) ?? null;
        const exp = str(row?.expires_at);
        if (row && exp && new Date(exp) <= new Date()) row = null;
        // Without the anon client there is no RLS in this path, so the lock is applied here too.
        const unlock = str(row?.unlock_at);
        if (row && unlock && new Date(unlock) > new Date()) row = null;
      }
      if (!row) return null;

      const configuration = readConfig(row.configuration);
      if (!configuration) return null;
      return {
        id: String(row.id), slug: String(row.slug), occasion: String(row.occasion),
        recipientName: String(row.recipient_name), senderName: String(row.sender_name), configuration,
        publishedAt: str(row.published_at), expiresAt: str(row.expires_at),
      };
    },

    async getViewState(slug): Promise<ViewState> {
      if (!isSlug(slug)) return { kind: "missing" };
      // Lock facts come from the server-only client; the CONTENT still comes through the RLS-guarded path.
      const { data, error } = await admin
        .from("experiences")
        .select("occasion, unlock_at, unlock_timezone, expires_at")
        .eq("slug", slug).eq("published", true).is("hidden_at", null).maybeSingle();
      if (error) unavailable("view state", error);
      const exp = str(data?.expires_at);
      const now = new Date();
      if (!data || (exp && new Date(exp) <= now)) return { kind: "missing" };
      const unlock = str(data.unlock_at);
      const locked = (): ViewState => ({
        kind: "locked", occasion: String(data.occasion), unlockAt: String(unlock),
        unlockTimezone: str(data.unlock_timezone) ?? "UTC", serverNow: now.toISOString(),
      });
      if (unlock && new Date(unlock) > now) return locked();
      const published = await this.getPublishedBySlug(slug);
      // The database clock can run a moment behind this server's: if its policy still refuses the
      // row, it is simply not open yet.
      if (!published) return unlock ? locked() : { kind: "missing" };
      return { kind: "open", published };
    },

    async getAssetUrls(experienceId, assetIds, ttlSec = DEFAULT_SIGNED_URL_TTL_SEC) {
      const ids = assetIds.filter(isUuid).slice(0, MAX_ASSETS_PER_EXPERIENCE);
      if (!isUuid(experienceId) || ids.length === 0) return {};
      const { data, error } = await admin
        .from("assets").select("id, file_path").eq("experience_id", experienceId).in("id", ids);
      if (error) unavailable("list assets", error);
      const idByPath = new Map<string, string>();
      for (const r of (data ?? []) as Row[]) idByPath.set(String(r.file_path), String(r.id));
      if (idByPath.size === 0) return {};

      const { data: signed, error: sErr } = await admin.storage
        .from(BUCKET).createSignedUrls([...idByPath.keys()], ttlSec);
      if (sErr) unavailable("sign urls", sErr);
      const out: Record<string, string> = {};
      for (const s of (signed ?? []) as Row[]) {
        const aid = idByPath.get(String(s.path));
        const url = str(s.signedUrl);
        if (aid && url && !s.error) out[aid] = url;
      }
      return out;
    },

    async recordGeneration(id, g) {
      try {
        if (!isUuid(id)) return;
        await admin.from("generations").insert({
          experience_id: id, provider: g.provider.slice(0, 40), status: g.status, duration_ms: g.durationMs ?? null,
        });
      } catch {
        // analytics must never break creation
      }
    },

    async addReport(slug, reason, details) {
      const r = assertReport(reason, details);
      if (!isSlug(slug)) throw new StoreError("not_found", "That greeting isn't available.");
      const { data, error } = await admin
        .from("experiences").select("id, expires_at, unlock_at").eq("slug", slug).eq("published", true).is("hidden_at", null).maybeSingle();
      if (error) unavailable("find report target", error);
      const exp = str(data?.expires_at);
      const unlock = str(data?.unlock_at);
      // A locked greeting has no visible content to report yet.
      if (!data || (exp && new Date(exp) <= new Date()) || (unlock && new Date(unlock) > new Date())) {
        throw new StoreError("not_found", "That greeting isn't available.");
      }
      const { error: insErr } = await admin.from("reports").insert({ experience_id: data.id, reason: r.reason, details: r.details });
      if (insErr) unavailable("add report", insErr);
    },

    async hitRateLimit(key, limit, windowSec) {
      const { data, error } = await admin.rpc("rate_limit_hit", {
        p_key: key.slice(0, 120), p_limit: limit, p_window_seconds: windowSec,
      });
      if (error) unavailable("rate limit", error);
      const row = (Array.isArray(data) ? data[0] : data) as { ok?: boolean; retry_after_sec?: number } | undefined;
      if (!row) unavailable("rate limit", null);
      return row.ok ? { ok: true } : { ok: false, retryAfterSec: Math.max(1, Number(row.retry_after_sec ?? 60)) };
    },

    async listForAdmin({ limit = 100 } = {}): Promise<AdminExperience[]> {
      const { data, error } = await admin
        .from("experiences")
        .select("id, slug, occasion, recipient_name, sender_name, message, configuration, published, hidden_at, hidden_reason, created_at")
        .order("created_at", { ascending: false })
        .limit(Math.min(Math.max(limit, 1), 500));
      if (error) unavailable("admin list", error);
      const rows = (data ?? []) as Row[];
      const ids = rows.map((r) => String(r.id));
      const counts = new Map<string, number>();
      if (ids.length > 0) {
        const { data: rep, error: repErr } = await admin.from("reports").select("experience_id").in("experience_id", ids).is("resolved_at", null);
        if (repErr) unavailable("admin report counts", repErr);
        for (const r of (rep ?? []) as Row[]) counts.set(String(r.experience_id), (counts.get(String(r.experience_id)) ?? 0) + 1);
      }
      return rows.map((r) => ({
        id: String(r.id), slug: String(r.slug), occasion: String(r.occasion),
        recipientName: String(r.recipient_name), senderName: String(r.sender_name),
        headline: headlineOf(readConfig(r.configuration)), message: str(r.message),
        published: r.published === true, hidden: r.hidden_at != null, hiddenReason: str(r.hidden_reason),
        createdAt: String(r.created_at), openReports: counts.get(String(r.id)) ?? 0,
      }));
    },

    async listReports({ includeResolved = false, limit = 100 } = {}): Promise<AdminReport[]> {
      let q = admin
        .from("reports")
        .select("id, experience_id, reason, details, created_at, resolved_at, experiences(slug)")
        .order("created_at", { ascending: false })
        .limit(Math.min(Math.max(limit, 1), 500));
      if (!includeResolved) q = q.is("resolved_at", null);
      const { data, error } = await q;
      if (error) unavailable("list reports", error);
      return ((data ?? []) as unknown as Array<Row & { experiences: { slug?: string } | { slug?: string }[] | null }>).map((r) => {
        const e = Array.isArray(r.experiences) ? r.experiences[0] : r.experiences;
        return {
          id: String(r.id), experienceId: String(r.experience_id), slug: String(e?.slug ?? ""),
          reason: String(r.reason) as ReportReason, details: str(r.details),
          createdAt: String(r.created_at), resolved: r.resolved_at != null,
        };
      });
    },

    async resolveReports(experienceId) {
      if (!isUuid(experienceId)) return;
      const { error } = await admin
        .from("reports").update({ resolved_at: new Date().toISOString() }).eq("experience_id", experienceId).is("resolved_at", null);
      if (error) unavailable("resolve reports", error);
    },

    async adminDelete(id) {
      if (!isUuid(id)) throw new StoreError("not_found", "No such greeting.");
      const { data, error } = await admin.from("experiences").select("id").eq("id", id).maybeSingle();
      if (error) unavailable("find for delete", error);
      if (!data) throw new StoreError("not_found", "No such greeting.");
      await removeFiles(await assetPaths([id]));
      const { error: delErr } = await admin.from("experiences").delete().eq("id", id);
      if (delErr) unavailable("admin delete", delErr);
    },

    async setHidden(id, hidden, reason) {
      const { data, error } = await admin
        .from("experiences")
        .update({ hidden_at: hidden ? new Date().toISOString() : null, hidden_reason: hidden ? (reason ?? null) : null })
        .eq("id", id)
        .select("id");
      if (error) unavailable("set hidden", error);
      if (!data || data.length === 0) throw new StoreError("not_found", "No such greeting.");
    },

    async purgeExpired(now = new Date()) {
      const staleIso = new Date(now.getTime() - DRAFT_TTL_DAYS * DAY_MS).toISOString();
      const { data, error } = await admin
        .from("experiences")
        .select("id")
        .or(`expires_at.lte.${now.toISOString()},and(published.eq.false,created_at.lt.${staleIso})`)
        .limit(PURGE_BATCH);
      if (error) unavailable("find expired", error);
      const ids = ((data ?? []) as Row[]).map((r) => String(r.id));
      await admin.rpc("purge_rate_limit_hits"); // best effort housekeeping
      if (ids.length === 0) return 0;
      await removeFiles(await assetPaths(ids));
      const { error: delErr } = await admin.from("experiences").delete().in("id", ids);
      if (delErr) unavailable("purge", delErr);
      return ids.length;
    },
  };
}

function requireAdmin(): SupabaseClient {
  const c = getAdminClient();
  if (!c) throw new StoreError("unavailable", "Supabase is not configured.");
  return c;
}
