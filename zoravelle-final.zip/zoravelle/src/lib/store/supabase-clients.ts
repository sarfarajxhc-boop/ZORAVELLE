import "server-only";
import { createClient, type SupabaseClient } from "@supabase/supabase-js";

const OPTS = { auth: { persistSession: false, autoRefreshToken: false } } as const;

let admin: SupabaseClient | null = null;
let anon: SupabaseClient | null = null;

/**
 * Service-role client. Bypasses Row Level Security, so it is used only for
 * writes and storage after the app has validated input and checked the edit
 * token. The key never leaves the server (no NEXT_PUBLIC_ prefix, server-only import).
 */
export function getAdminClient(): SupabaseClient | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) return null;
  admin ??= createClient(url, key, OPTS);
  return admin;
}

/** Anon client for the public read path, so Row Level Security does the filtering. */
export function getAnonClient(): SupabaseClient | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return null;
  anon ??= createClient(url, key, OPTS);
  return anon;
}
