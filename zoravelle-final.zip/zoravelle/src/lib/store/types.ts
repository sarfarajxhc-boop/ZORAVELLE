import type { ExperienceConfig } from "@/lib/experience/schema";

/**
 * invalid     the input breaks a rule (bad config, nothing to publish, bad image)
 * forbidden   the edit token is missing, wrong, or the experience does not exist
 *             (deliberately the same answer, so ids cannot be probed)
 * limit       a quota was hit (for example, 6 photos per greeting)
 * not_found   used by admin operations that address an id directly
 * unavailable the database or storage failed; safe to retry
 */
export type StoreErrorCode = "invalid" | "forbidden" | "limit" | "not_found" | "unavailable";

export class StoreError extends Error {
  constructor(public readonly code: StoreErrorCode, message: string) {
    super(message);
    this.name = "StoreError";
  }
}

export type DraftInput = { occasion: string; recipientName: string; senderName: string };
export type Draft = { id: string; slug: string; editToken: string };

export type AssetRecord = { id: string; byteSize: number };

/** What the creator (token holder) can see about their own greeting. */
export type OwnedExperience = {
  id: string;
  slug: string;
  occasion: string;
  recipientName: string;
  senderName: string;
  published: boolean;
  hasConfiguration: boolean;
  assetIds: string[];
  createdAt: string;
  expiresAt: string | null;
  /** UTC instant until which the content is locked, or null when it opened immediately. */
  unlockAt: string | null;
  /** The zone the creator picked, kept for display only. */
  unlockTimezone: string | null;
};

export const REPORT_REASONS = ["harassment", "hate", "sexual", "scam", "privacy", "other"] as const;
export type ReportReason = (typeof REPORT_REASONS)[number];

/** One greeting as the admin sees it, with enough text to judge a report. */
export type AdminExperience = {
  id: string;
  slug: string;
  occasion: string;
  recipientName: string;
  senderName: string;
  headline: string | null;
  message: string | null;
  published: boolean;
  hidden: boolean;
  hiddenReason: string | null;
  createdAt: string;
  openReports: number;
};

export type AdminReport = {
  id: string;
  experienceId: string;
  slug: string;
  reason: ReportReason;
  details: string | null;
  createdAt: string;
  resolved: boolean;
};

export type GenerationRecord = {
  provider: string;
  status: "success" | "fallback" | "failed";
  durationMs?: number;
};

/** Everything a viewer needs and nothing private (no token hash, no moderation fields). */
export type PublishedExperience = {
  id: string;
  slug: string;
  occasion: string;
  recipientName: string;
  senderName: string;
  configuration: ExperienceConfig;
  publishedAt: string | null;
  expiresAt: string | null;
};

/** null = open immediately. Otherwise the content stays locked until unlockAt (a UTC instant). */
export type Schedule = { unlockAt: Date; timezone: string } | null;
export type ScheduleResult = { unlockAt: string | null; unlockTimezone: string | null };

/**
 * What a public visitor to /w/<slug> is allowed to learn. A locked greeting reveals only the
 * occasion (so the countdown can match its mood), the unlock instant and the server clock.
 * It never carries names, text, photos or any configuration.
 */
export type ViewState =
  | { kind: "missing" }
  | { kind: "open"; published: PublishedExperience }
  | { kind: "locked"; occasion: string; unlockAt: string; unlockTimezone: string; serverNow: string };

export interface ExperienceStore {
  readonly kind: "memory" | "supabase";

  /** Start a draft. The returned editToken is the only copy; only its hash is kept. */
  createDraft(input: DraftInput, opts?: { expiresAt?: Date | null }): Promise<Draft>;

  /** Save a generated or edited config. Re-validated here, even though callers already validated it. */
  saveConfiguration(
    id: string,
    token: string,
    config: ExperienceConfig,
    meta?: { message?: string | null; recipientName?: string; senderName?: string },
  ): Promise<void>;

  /** The creator's own view of a greeting. Same "forbidden" answer for a wrong token or unknown id. */
  getOwned(id: string, token: string): Promise<OwnedExperience>;

  /** `image.data` must already be the output of processImage(). */
  addAsset(id: string, token: string, image: { data: Uint8Array }): Promise<AssetRecord>;
  removeAsset(id: string, token: string, assetId: string): Promise<void>;

  /** Publish. With a schedule the link exists now but the content stays locked until the unlock instant. */
  publish(id: string, token: string, schedule?: Schedule): Promise<{ slug: string } & ScheduleResult>;
  /**
   * Change (or remove) the lock of a published greeting. Only possible while it is still locked:
   * a greeting that has already opened cannot be locked again.
   */
  setSchedule(id: string, token: string, schedule: Schedule): Promise<ScheduleResult>;
  deleteExperience(id: string, token: string): Promise<void>;

  /** Public read of the CONTENT. Returns null for anything not viewable, including a still-locked greeting. */
  getPublishedBySlug(slug: string): Promise<PublishedExperience | null>;

  /** Public state for the viewer page: missing, open (with content) or locked (without any). */
  getViewState(slug: string): Promise<ViewState>;

  /** Short-lived URLs for the creator's own photos. Unknown or foreign ids are omitted. */
  getAssetUrls(experienceId: string, assetIds: string[], ttlSec?: number): Promise<Record<string, string>>;

  /** Best-effort analytics row. Never throws. Stores no prompt or user text. */
  recordGeneration(id: string, rec: GenerationRecord): Promise<void>;

  /** Public: report a published greeting. Unknown, hidden or unpublished slugs give "not_found". */
  addReport(slug: string, reason: ReportReason, details?: string | null): Promise<void>;

  /** Sliding-window rate limit shared by every server instance when the store is a database. */
  hitRateLimit(key: string, limit: number, windowSec: number): Promise<{ ok: true } | { ok: false; retryAfterSec: number }>;

  /** Admin / maintenance (no token; callers must be trusted server code). */
  listForAdmin(opts?: { limit?: number }): Promise<AdminExperience[]>;
  listReports(opts?: { includeResolved?: boolean; limit?: number }): Promise<AdminReport[]>;
  resolveReports(experienceId: string): Promise<void>;
  /** Delete a greeting and its photos without its edit token. */
  adminDelete(id: string): Promise<void>;
  setHidden(id: string, hidden: boolean, reason?: string): Promise<void>;
  /** Deletes expired experiences and drafts older than DRAFT_TTL_DAYS, with their photos. Returns how many. */
  purgeExpired(now?: Date): Promise<number>;
}
