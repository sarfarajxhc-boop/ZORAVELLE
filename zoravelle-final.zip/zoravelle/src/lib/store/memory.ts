import { randomUUID } from "node:crypto";
import type { ExperienceConfig } from "@/lib/experience/schema";
import { generateEditToken, generateSlug, hashToken, tokenMatchesHash } from "@/lib/security/tokens";
import {
  DEFAULT_SIGNED_URL_TTL_SEC, DRAFT_TTL_DAYS, MAX_ASSETS_PER_EXPERIENCE,
  assertDraftInput, assertMessage, assertSchedule, assertPersonName, assertReport, assertStorableImage, headlineOf, isSlug, parseConfigForExperience, readConfig,
} from "./shared";
import {
  StoreError,
  type AdminExperience, type AdminReport, type AssetRecord, type Draft, type DraftInput, type ExperienceStore, type GenerationRecord, type OwnedExperience,
  type PublishedExperience, type ViewState,
} from "./types";

type Rec = {
  id: string;
  slug: string;
  occasion: string;
  recipientName: string;
  senderName: string;
  message: string | null;
  theme: string | null;
  configuration: ExperienceConfig | null;
  published: boolean;
  publishedAt: Date | null;
  tokenHash: string;
  hiddenAt: Date | null;
  hiddenReason: string | null;
  createdAt: Date;
  expiresAt: Date | null;
  unlockAt: Date | null;
  unlockTz: string | null;
  assets: Map<string, { id: string; byteSize: number; data: Uint8Array }>;
  generations: GenerationRecord[];
};

export type MemoryStore = ExperienceStore & { generationsFor(id: string): GenerationRecord[] };

const DAY_MS = 86_400_000;

/**
 * Demo-mode store. Same rules as the database, but data lives in this process
 * only: it is lost on restart and not shared between serverless instances, so a
 * published link will only open on the instance that created it.
 */
export function createMemoryStore(opts: { now?: () => Date } = {}): MemoryStore {
  const clock = opts.now ?? (() => new Date());
  const db = new Map<string, Rec>();
  const bySlug = new Map<string, string>();
  const reports: Array<AdminReport & { at: Date }> = [];
  const hits = new Map<string, number[]>();

  // Same answer for "no such experience" and "wrong token", so ids can't be probed.
  function authorize(id: string, token: string): Rec {
    const rec = db.get(id);
    if (!rec || !tokenMatchesHash(token, rec.tokenHash)) {
      throw new StoreError("forbidden", "That edit link doesn't match this greeting.");
    }
    return rec;
  }

  function drop(rec: Rec) {
    db.delete(rec.id);
    bySlug.delete(rec.slug);
    for (let i = reports.length - 1; i >= 0; i--) if (reports[i]?.experienceId === rec.id) reports.splice(i, 1);
  }

  /** Published, not hidden, not expired. */
  const isLive = (rec: Rec, now: Date) =>
    rec.published && !rec.hiddenAt && (!rec.expiresAt || rec.expiresAt > now);
  /** Live AND past its unlock instant: the only state in which content may leave the store. */
  const isViewable = (rec: Rec, now: Date) => isLive(rec, now) && (!rec.unlockAt || rec.unlockAt <= now);

  return {
    kind: "memory",

    async createDraft(input: DraftInput, o?: { expiresAt?: Date | null }): Promise<Draft> {
      assertDraftInput(input);
      let slug = generateSlug();
      while (bySlug.has(slug)) slug = generateSlug();
      const editToken = generateEditToken();
      const id = randomUUID();
      db.set(id, {
        id, slug, occasion: input.occasion,
        recipientName: input.recipientName.trim(), senderName: input.senderName.trim(),
        message: null, theme: null, configuration: null,
        published: false, publishedAt: null, tokenHash: hashToken(editToken),
        hiddenAt: null, hiddenReason: null, createdAt: clock(), expiresAt: o?.expiresAt ?? null,
        unlockAt: null, unlockTz: null,
        assets: new Map(), generations: [],
      });
      bySlug.set(slug, id);
      return { id, slug, editToken };
    },

    async saveConfiguration(id, token, config, meta) {
      const rec = authorize(id, token);
      const parsed = parseConfigForExperience(config, rec.occasion, new Set(rec.assets.keys()));
      const message = assertMessage(meta?.message);
      const recipientName = meta?.recipientName === undefined ? rec.recipientName : assertPersonName(meta.recipientName, "Recipient name");
      const senderName = meta?.senderName === undefined ? rec.senderName : assertPersonName(meta.senderName, "Sender name");
      rec.configuration = parsed;
      rec.theme = parsed.theme.name;
      rec.message = message;
      rec.recipientName = recipientName;
      rec.senderName = senderName;
    },

    async getOwned(id, token): Promise<OwnedExperience> {
      const rec = authorize(id, token);
      return {
        id: rec.id, slug: rec.slug, occasion: rec.occasion,
        recipientName: rec.recipientName, senderName: rec.senderName,
        published: rec.published, hasConfiguration: rec.configuration !== null,
        assetIds: [...rec.assets.keys()],
        createdAt: rec.createdAt.toISOString(), expiresAt: rec.expiresAt?.toISOString() ?? null,
        unlockAt: rec.unlockAt?.toISOString() ?? null, unlockTimezone: rec.unlockTz,
      };
    },

    async addAsset(id, token, image): Promise<AssetRecord> {
      const rec = authorize(id, token);
      assertStorableImage(image.data);
      if (rec.assets.size >= MAX_ASSETS_PER_EXPERIENCE) {
        throw new StoreError("limit", `You can add up to ${MAX_ASSETS_PER_EXPERIENCE} photos.`);
      }
      const assetId = randomUUID();
      rec.assets.set(assetId, { id: assetId, byteSize: image.data.length, data: new Uint8Array(image.data) });
      return { id: assetId, byteSize: image.data.length };
    },

    async removeAsset(id, token, assetId) {
      const rec = authorize(id, token);
      rec.assets.delete(assetId);
    },

    async publish(id, token, schedule) {
      const rec = authorize(id, token);
      if (!rec.configuration) throw new StoreError("invalid", "Generate your greeting before publishing.");
      assertSchedule(schedule, clock(), rec.expiresAt);
      rec.published = true;
      rec.publishedAt ??= clock();
      rec.unlockAt = schedule?.unlockAt ?? null;
      rec.unlockTz = schedule?.timezone ?? null;
      return { slug: rec.slug, unlockAt: rec.unlockAt?.toISOString() ?? null, unlockTimezone: rec.unlockTz };
    },

    async setSchedule(id, token, schedule) {
      const rec = authorize(id, token);
      const now = clock();
      if (!rec.published) throw new StoreError("invalid", "Publish the greeting first.");
      if (!rec.unlockAt || rec.unlockAt <= now) {
        throw new StoreError("invalid", "This greeting is already open, so it can't be locked again.");
      }
      assertSchedule(schedule, now, rec.expiresAt);
      rec.unlockAt = schedule?.unlockAt ?? null;
      rec.unlockTz = schedule?.timezone ?? null;
      return { unlockAt: rec.unlockAt?.toISOString() ?? null, unlockTimezone: rec.unlockTz };
    },

    async deleteExperience(id, token) {
      drop(authorize(id, token));
    },

    async getPublishedBySlug(slug): Promise<PublishedExperience | null> {
      if (!isSlug(slug)) return null;
      const id = bySlug.get(slug);
      const rec = id ? db.get(id) : undefined;
      if (!rec || !isViewable(rec, clock())) return null;
      const configuration = readConfig(rec.configuration);
      if (!configuration) return null;
      return {
        id: rec.id, slug: rec.slug, occasion: rec.occasion,
        recipientName: rec.recipientName, senderName: rec.senderName, configuration,
        publishedAt: rec.publishedAt?.toISOString() ?? null,
        expiresAt: rec.expiresAt?.toISOString() ?? null,
      };
    },

    async getViewState(slug): Promise<ViewState> {
      if (!isSlug(slug)) return { kind: "missing" };
      const id = bySlug.get(slug);
      const rec = id ? db.get(id) : undefined;
      const now = clock();
      if (!rec || !isLive(rec, now)) return { kind: "missing" };
      if (rec.unlockAt && rec.unlockAt > now) {
        return {
          kind: "locked", occasion: rec.occasion, unlockAt: rec.unlockAt.toISOString(),
          unlockTimezone: rec.unlockTz ?? "UTC", serverNow: now.toISOString(),
        };
      }
      if (!isViewable(rec, now)) return { kind: "missing" };
      const configuration = readConfig(rec.configuration);
      if (!configuration) return { kind: "missing" };
      return {
        kind: "open",
        published: {
          id: rec.id, slug: rec.slug, occasion: rec.occasion,
          recipientName: rec.recipientName, senderName: rec.senderName, configuration,
          publishedAt: rec.publishedAt?.toISOString() ?? null, expiresAt: rec.expiresAt?.toISOString() ?? null,
        },
      };
    },

    async getAssetUrls(experienceId, assetIds, _ttl = DEFAULT_SIGNED_URL_TTL_SEC) {
      const rec = db.get(experienceId);
      const out: Record<string, string> = {};
      if (!rec) return out;
      for (const aid of assetIds.slice(0, MAX_ASSETS_PER_EXPERIENCE)) {
        const a = rec.assets.get(aid);
        if (a) out[aid] = `data:image/webp;base64,${Buffer.from(a.data).toString("base64")}`;
      }
      return out;
    },

    async recordGeneration(id, g) {
      db.get(id)?.generations.push(g);
    },

    async addReport(slug, reason, details) {
      const r = assertReport(reason, details);
      const id = isSlug(slug) ? bySlug.get(slug) : undefined;
      const rec = id ? db.get(id) : undefined;
      if (!rec || !isViewable(rec, clock())) throw new StoreError("not_found", "That greeting isn't available.");
      const at = clock();
      reports.push({
        id: randomUUID(), experienceId: rec.id, slug: rec.slug, reason: r.reason, details: r.details,
        createdAt: at.toISOString(), resolved: false, at,
      });
    },

    async hitRateLimit(key, limit, windowSec) {
      const now = clock().getTime();
      const recent = (hits.get(key) ?? []).filter((t) => now - t < windowSec * 1000);
      if (recent.length >= limit) {
        return { ok: false, retryAfterSec: Math.max(1, Math.ceil(((recent[0] ?? now) + windowSec * 1000 - now) / 1000)) };
      }
      recent.push(now);
      hits.set(key, recent);
      return { ok: true };
    },

    async listForAdmin({ limit = 100 } = {}): Promise<AdminExperience[]> {
      return [...db.values()]
        .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
        .slice(0, Math.min(Math.max(limit, 1), 500))
        .map((r) => ({
          id: r.id, slug: r.slug, occasion: r.occasion, recipientName: r.recipientName, senderName: r.senderName,
          headline: headlineOf(r.configuration), message: r.message, published: r.published,
          hidden: r.hiddenAt !== null, hiddenReason: r.hiddenReason, createdAt: r.createdAt.toISOString(),
          openReports: reports.filter((x) => x.experienceId === r.id && !x.resolved).length,
        }));
    },

    async listReports({ includeResolved = false, limit = 100 } = {}): Promise<AdminReport[]> {
      return reports
        .filter((r) => includeResolved || !r.resolved)
        .sort((a, b) => b.at.getTime() - a.at.getTime())
        .slice(0, Math.min(Math.max(limit, 1), 500))
        .map(({ at: _at, ...rest }) => rest);
    },

    async resolveReports(experienceId) {
      for (const r of reports) if (r.experienceId === experienceId) r.resolved = true;
    },

    async adminDelete(id) {
      const rec = db.get(id);
      if (!rec) throw new StoreError("not_found", "No such greeting.");
      drop(rec);
    },

    async setHidden(id, hidden, reason) {
      const rec = db.get(id);
      if (!rec) throw new StoreError("not_found", "No such greeting.");
      rec.hiddenAt = hidden ? clock() : null;
      rec.hiddenReason = hidden ? (reason ?? null) : null;
    },

    async purgeExpired(now = clock()) {
      const staleBefore = new Date(now.getTime() - DRAFT_TTL_DAYS * DAY_MS);
      let n = 0;
      for (const rec of [...db.values()]) {
        const expired = rec.expiresAt !== null && rec.expiresAt <= now;
        const staleDraft = !rec.published && rec.createdAt < staleBefore;
        if (expired || staleDraft) { drop(rec); n++; }
      }
      return n;
    },

    generationsFor(id) {
      return db.get(id)?.generations ?? [];
    },
  };
}
