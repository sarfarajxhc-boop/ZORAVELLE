import "server-only";
import { checkRateLimit, type LimitResult } from "@/lib/rate-limit";
import { getStore } from "@/lib/store";

/**
 * Rate limit shared by every server instance when a database is configured
 * (the count lives in Postgres), and in memory per instance in demo mode.
 * If the database call fails we fall back to the in-memory limiter for that
 * request instead of blocking everyone, so an outage can't lock users out.
 */
export async function limit(key: string, max: number, windowMs: number): Promise<LimitResult> {
  const store = getStore();
  if (store.kind === "supabase") {
    try {
      return await store.hitRateLimit(key, max, Math.ceil(windowMs / 1000));
    } catch {
      // fall through to the local limiter
    }
  }
  return checkRateLimit(key, max, windowMs);
}
