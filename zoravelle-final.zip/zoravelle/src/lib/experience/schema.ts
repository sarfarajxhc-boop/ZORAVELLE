import { z } from "zod";

/**
 * The ONLY thing AI is allowed to produce: a validated, declarative config.
 * The trusted renderer maps these enums to pre-built components.
 * No field can carry HTML, JS, CSS or URLs, so nothing here can execute.
 */

export const CONFIG_VERSION = 1 as const;

const hex = z.string().regex(/^#[0-9a-fA-F]{6}$/, "Expected #RRGGBB");
/** Plain text only. The renderer outputs it as text nodes, never as HTML. */
const text = (max: number) => z.string().trim().min(1).max(max);

/** Scenes are reusable animation systems shipped in the codebase. */
export const SCENES = [
  "cake", "giftBox", "hearts", "loveLetter", "crescentLanterns", "diyas",
  "christmasTree", "fireworks", "colorBurst", "sunrise", "nightSky",
  "bloom", "confettiPop", "balloons", "polaroids", "cardOpen",
] as const;

export const AMBIENT_EFFECTS = [
  "none", "confetti", "snow", "floatingHearts", "fireflies", "stars",
  "sparkles", "petals", "lanterns", "fireworks", "colorPowder",
] as const;

export const BACKGROUNDS = [
  "solid", "softGradient", "aurora", "nightSky", "geometricIslamic",
  "paperTexture", "bokeh", "sunrise",
] as const;

export const FONT_PAIRS = [
  "elegantSerif", "modernSans", "playfulRounded", "romanticScript", "classicDisplay",
] as const;

export const INTERACTIONS = [
  "tapToBegin", "blowCandles", "openGift", "lightDiyas", "unwrapLetter",
  "countdown", "tapToReveal", "holdToCharge",
] as const;

/** How photos are laid out. Missing means "polaroid", so greetings made before this option look the same. */
export const GALLERY_LAYOUTS = ["polaroid", "grid", "filmstrip", "spotlight"] as const;

/** The look a recipient sees first (they can still switch). Missing means the default, "cinematic". */
export const LOOKS = ["calm", "cinematic", "expensive"] as const;

export const PaletteSchema = z.object({
  background: hex,
  surface: hex,
  text: hex,
  accent: hex,
  accentSoft: hex,
}).strict();

export const ThemeSchema = z.object({
  name: text(40),
  palette: PaletteSchema,
  fontPair: z.enum(FONT_PAIRS),
  background: z.enum(BACKGROUNDS),
}).strict();

export const AmbientSchema = z.object({
  effect: z.enum(AMBIENT_EFFECTS),
  intensity: z.number().int().min(1).max(5),
}).strict();

const HeroBlock = z.object({
  type: z.literal("hero"),
  scene: z.enum(SCENES),
  headline: text(80),
  subheadline: text(160).optional(),
}).strict();

const InteractionBlock = z.object({
  type: z.literal("interaction"),
  kind: z.enum(INTERACTIONS),
  prompt: text(60),
  /** Shown after the interaction completes. */
  revealText: text(160).optional(),
}).strict();

const MessageBlock = z.object({
  type: z.literal("message"),
  body: text(1200),
  signoff: text(60).optional(),
}).strict();

const GalleryBlock = z.object({
  type: z.literal("gallery"),
  /** References uploaded assets by id; never raw URLs. */
  assetIds: z.array(z.string().uuid()).min(1).max(6),
  caption: text(120).optional(),
  layout: z.enum(GALLERY_LAYOUTS).optional(),
}).strict();

const SurpriseBlock = z.object({
  type: z.literal("surprise"),
  buttonLabel: text(40),
  scene: z.enum(SCENES),
  text: text(200),
}).strict();

export const BlockSchema = z.discriminatedUnion("type", [
  HeroBlock, InteractionBlock, MessageBlock, GalleryBlock, SurpriseBlock,
]);

export const ExperienceConfigSchema = z.object({
  version: z.literal(CONFIG_VERSION),
  occasion: z.string().regex(/^[a-z0-9-]{2,40}$/),
  theme: ThemeSchema,
  ambient: AmbientSchema,
  look: z.enum(LOOKS).optional(),
  blocks: z.array(BlockSchema).min(1).max(8),
}).strict();

export type ExperienceConfig = z.infer<typeof ExperienceConfigSchema>;
export type Block = z.infer<typeof BlockSchema>;
export type Theme = z.infer<typeof ThemeSchema>;

/** What the creator submits. Validated server-side before any AI call. */
export const CreatorInputSchema = z.object({
  occasion: z.string().regex(/^[a-z0-9-]{2,40}$/),
  customOccasionLabel: text(40).optional(),
  recipientName: text(60),
  senderName: text(60),
  message: z.string().trim().max(1200).optional(),
  relationship: z.string().trim().max(60).optional(),
  themeHint: z.string().trim().max(60).optional(),
  colorHint: z.string().trim().max(60).optional(),
  extraInstructions: z.string().trim().max(400).optional(),
  assetIds: z.array(z.string().uuid()).max(6).default([]),
}).strict();

export type CreatorInput = z.infer<typeof CreatorInputSchema>;
