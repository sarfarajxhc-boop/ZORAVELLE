/** Single source of truth for the creator's public details. */
export const CREATOR = {
  name: "Sarfaraj",
  instagram: "https://www.instagram.com/sarfaraj_hc?dlrf=NXdrejV4Mzhmb2R0",
  instagramHandle: "@sarfaraj_hc",
  email: "Sarfarajxhc@gmail.com",
  website: "https://cosmic-croquembouche-5d58cc.netlify.app",
  intro:
    "Hi, I'm Sarfaraj, the creator of ZORAVELLE. I believe every special moment deserves something more than an ordinary greeting. I created this platform to help people express their feelings through beautiful, personalised, and interactive digital experiences.",
} as const;
