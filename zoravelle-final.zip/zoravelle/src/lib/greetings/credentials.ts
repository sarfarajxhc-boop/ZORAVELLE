import { TOKEN_RE } from "@/lib/security/tokens";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

/** The pair a creator's browser holds for one draft. The token is a bearer secret. */
export type Credentials = { id: string; token: string };

/** Shape check for untrusted client input. Authorization itself happens in the store. */
export function parseCredentials(input: unknown): Credentials | null {
  if (typeof input !== "object" || input === null) return null;
  const { id, token } = input as Record<string, unknown>;
  if (typeof id !== "string" || typeof token !== "string") return null;
  if (!UUID_RE.test(id) || !TOKEN_RE.test(token)) return null;
  return { id, token };
}
