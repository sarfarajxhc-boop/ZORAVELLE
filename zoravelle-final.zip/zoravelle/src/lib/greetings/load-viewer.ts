import { cache } from "react";
import { getStore } from "@/lib/store";
import type { ExperienceConfig } from "@/lib/experience/schema";

export type ViewerData = { config: ExperienceConfig; assets: Record<string, string> };

export type LockInfo = { occasion: string; unlockAt: string; unlockTimezone: string; serverNow: string };

/** What /w/<slug> may render. `locked` carries no greeting content, by construction. */
export type ViewerState =
  | { kind: "missing" }
  | { kind: "locked"; lock: LockInfo }
  | { kind: "open"; data: ViewerData };

/**
 * Everything the public viewer page needs. A greeting that is unknown, unpublished, hidden, expired
 * or malformed is "missing". One that is still locked yields only its lock facts: the store never
 * hands out its content (and no photo URLs are created) before the unlock instant.
 */
async function loadViewerStateUncached(slug: string): Promise<ViewerState> {
  const store = getStore();
  const view = await store.getViewState(slug);
  if (view.kind === "missing") return { kind: "missing" };
  if (view.kind === "locked") {
    return {
      kind: "locked",
      lock: { occasion: view.occasion, unlockAt: view.unlockAt, unlockTimezone: view.unlockTimezone, serverNow: view.serverNow },
    };
  }
  const published = view.published;
  const assetIds = published.configuration.blocks.flatMap((b) => (b.type === "gallery" ? b.assetIds : []));
  const assets = assetIds.length > 0 ? await store.getAssetUrls(published.id, assetIds) : {};
  return { kind: "open", data: { config: published.configuration, assets } };
}

/** One lookup per request, shared by the page and its metadata. */
export const loadViewerState = cache(loadViewerStateUncached);

/** Content only. Null for missing OR still-locked greetings. */
export async function loadViewerData(slug: string): Promise<ViewerData | null> {
  const s = await loadViewerState(slug);
  return s.kind === "open" ? s.data : null;
}
