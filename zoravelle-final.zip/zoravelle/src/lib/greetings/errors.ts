import { StoreError, type StoreErrorCode } from "@/lib/store/types";

export type UserFacingError = { message: string; code: StoreErrorCode | "unknown" };

/**
 * Turn any thrown value into a message that is safe to show. Unexpected errors
 * are logged by type only (never message or content) and shown generically.
 */
export function toUserError(e: unknown): UserFacingError {
  if (e instanceof StoreError) {
    if (e.code === "forbidden") {
      return { code: e.code, message: "This greeting's edit link isn't valid any more. Start a new greeting." };
    }
    return { code: e.code, message: e.message };
  }
  console.error(`[greetings] unexpected ${e instanceof Error ? e.name : typeof e}`);
  return { code: "unknown", message: "Something went wrong. Please try again." };
}
