import { z } from "zod";
import { isValidTimeZone } from "@/lib/schedule/time";
import type { Schedule } from "@/lib/store";

/** What the browser may send. The server re-checks the rules against its own clock in the store. */
export const ScheduleInputSchema = z.discriminatedUnion("mode", [
  z.object({ mode: z.literal("now") }).strict(),
  z.object({
    mode: z.literal("lock"),
    unlockAt: z.string().datetime({ offset: true }),
    timezone: z.string().refine(isValidTimeZone, "Unknown time zone"),
  }).strict(),
]);
export type ScheduleInput = z.infer<typeof ScheduleInputSchema>;

/** undefined = "publish now" for callers that predate scheduling. Returns "bad" for malformed input. */
export function parseSchedule(raw: unknown): Schedule | "bad" {
  if (raw === undefined || raw === null) return null;
  const p = ScheduleInputSchema.safeParse(raw);
  if (!p.success) return "bad";
  return p.data.mode === "now" ? null : { unlockAt: new Date(p.data.unlockAt), timezone: p.data.timezone };
}
