import { LIMITS, type LimitKind } from "@/lib/limits";
import { limit } from "@/lib/limiter";
import { clientIp } from "@/lib/request";

/** Returns a message to show when the caller is over the limit, or null when allowed. */
export async function rateLimited(kind: LimitKind): Promise<string | null> {
  const { max, windowMs } = LIMITS[kind];
  const r = await limit(`${kind}:${await clientIp()}`, max, windowMs);
  if (r.ok) return null;
  const minutes = Math.max(1, Math.ceil(r.retryAfterSec / 60));
  return `You're going a bit fast. Try again in ${minutes} minute${minutes === 1 ? "" : "s"}.`;
}
