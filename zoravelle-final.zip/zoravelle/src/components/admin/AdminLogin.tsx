"use client";

import { useActionState, useEffect } from "react";
import { login } from "@/app/(bare)/admin/actions";

export function AdminLogin() {
  const [state, action, pending] = useActionState(login, null);
  useEffect(() => {
    if (state?.ok) window.location.reload();
  }, [state]);

  return (
    <main className="mx-auto max-w-sm p-6">
      <h1 className="text-2xl font-bold">Admin</h1>
      <form action={action} className="mt-6 space-y-4">
        <div>
          <label htmlFor="token" className="block font-semibold">Admin token</label>
          <input
            id="token" name="token" type="password" autoComplete="current-password" required
            className="mt-1.5 w-full rounded-2xl border border-black/20 bg-white px-4 py-3 text-base"
          />
        </div>
        {state && !state.ok && <p role="alert" className="text-sm font-medium text-[#B51224]">{state.message}</p>}
        <button disabled={pending} className="min-h-12 rounded-full bg-black px-8 font-semibold text-white disabled:opacity-60">
          {pending ? "Checking…" : "Sign in"}
        </button>
      </form>
    </main>
  );
}
