"use client";

import { useState, useTransition } from "react";
import { deleteGreeting, dismissReports, hideGreeting, logout, unhideGreeting, type ActionResult } from "@/app/(bare)/admin/actions";
import type { AdminExperience, AdminReport } from "@/lib/store/types";

type Props = { items: AdminExperience[]; reports: AdminReport[]; persistent: boolean };

export function AdminPanel({ items, reports, persistent }: Props) {
  const [filter, setFilter] = useState<"reported" | "all">("reported");
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();

  const run = (fn: () => Promise<ActionResult>) =>
    start(async () => {
      const r = await fn();
      setError(r.ok ? null : r.message);
    });

  const shown = items.filter((i) => (filter === "all" ? true : i.openReports > 0));
  const reportsFor = (id: string) => reports.filter((r) => r.experienceId === id);

  return (
    <main className="mx-auto max-w-4xl p-4 sm:p-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">Moderation</h1>
        <form action={logout}><button className="min-h-11 rounded-full border border-black/25 px-5 font-semibold">Sign out</button></form>
      </div>
      {!persistent && <p role="note" className="mt-3 rounded-2xl bg-[#f7f0e1] p-3 text-sm">Demo store: data is in memory and not shared between servers.</p>}
      {error && <p role="alert" className="mt-3 text-sm font-medium text-[#B51224]">{error}</p>}

      <div className="mt-4 flex gap-2" role="group" aria-label="Filter">
        {(["reported", "all"] as const).map((f) => (
          <button
            key={f} type="button" aria-pressed={filter === f} onClick={() => setFilter(f)}
            className={`min-h-11 rounded-full border px-4 text-sm font-semibold ${filter === f ? "border-black bg-black text-white" : "border-black/25"}`}
          >
            {f === "reported" ? `With open reports (${items.filter((i) => i.openReports > 0).length})` : `All (${items.length})`}
          </button>
        ))}
      </div>

      {shown.length === 0 && <p className="mt-6 text-sm">Nothing to show.</p>}
      <ul className="mt-4 space-y-4">
        {shown.map((g) => (
          <li key={g.id} className="rounded-3xl border border-black/15 p-4">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              <p className="font-semibold">{g.occasion} · for {g.recipientName} · from {g.senderName}</p>
              <p className="text-xs">
                {g.published ? "published" : "draft"}{g.hidden ? " · HIDDEN" : ""} · {new Date(g.createdAt).toLocaleString()}
              </p>
            </div>
            {g.headline && <p className="mt-2 font-medium">{g.headline}</p>}
            {g.message && <p className="mt-1 whitespace-pre-wrap text-sm">{g.message.slice(0, 400)}</p>}
            {g.hidden && g.hiddenReason && <p className="mt-1 text-xs">Reason: {g.hiddenReason}</p>}
            <p className="mt-1 text-xs">slug {g.slug}</p>

            {reportsFor(g.id).length > 0 && (
              <ul className="mt-3 space-y-1 text-sm">
                {reportsFor(g.id).map((r) => (
                  <li key={r.id}><strong>{r.reason}</strong>{r.details ? `: ${r.details}` : ""} <span className="text-xs">({new Date(r.createdAt).toLocaleString()}{r.resolved ? ", resolved" : ""})</span></li>
                ))}
              </ul>
            )}

            <div className="mt-4 flex flex-wrap gap-2">
              {g.hidden ? (
                <Btn disabled={pending} onClick={() => run(() => unhideGreeting(g.id))}>Unhide</Btn>
              ) : (
                <Btn disabled={pending} onClick={() => run(() => hideGreeting(g.id, "Hidden after review"))}>Hide (takedown)</Btn>
              )}
              {g.openReports > 0 && <Btn disabled={pending} onClick={() => run(() => dismissReports(g.id))}>Dismiss reports</Btn>}
              <Btn
                danger disabled={pending}
                onClick={() => { if (window.confirm("Delete this greeting and its photos permanently?")) run(() => deleteGreeting(g.id)); }}
              >
                Delete
              </Btn>
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}

function Btn({ children, danger, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement> & { danger?: boolean }) {
  return (
    <button
      type="button" {...rest}
      className={`min-h-11 rounded-full border px-4 text-sm font-semibold disabled:opacity-60 ${danger ? "border-[#B51224] text-[#B51224]" : "border-black/25"}`}
    >
      {children}
    </button>
  );
}
