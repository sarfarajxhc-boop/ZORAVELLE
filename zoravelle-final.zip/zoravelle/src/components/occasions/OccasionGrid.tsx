import Link from "next/link";
import { OccasionIcon } from "@/components/ui/OccasionIcon";
import { OCCASIONS } from "@/lib/occasions/registry";

export function OccasionGrid() {
  return (
    <ul className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
      {OCCASIONS.map((o) => (
        <li key={o.id}>
          <Link
            href={`/create/${o.id}`}
            className="group flex h-full min-h-32 items-start gap-4 rounded-3xl border border-ink/10 bg-white p-5 shadow-sm transition duration-300 hover:-translate-y-1 hover:border-gold hover:shadow-lg focus-visible:-translate-y-1"
          >
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-full bg-ink/5 text-ink transition duration-300 group-hover:bg-ink group-hover:text-gold-bright">
              <OccasionIcon name={o.icon} className="h-5 w-5" />
            </span>
            <span>
              <span className="block font-display text-lg font-semibold leading-tight">{o.title}</span>
              <span className="mt-1 block text-sm text-ink-soft">{o.blurb}</span>
            </span>
          </Link>
        </li>
      ))}
    </ul>
  );
}
