"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { deleteOwned, loadOwned, rescheduleOwned, type ManagedGreeting } from "@/app/(site)/manage/actions";
import { ScheduleFields, buildSchedule, defaultLock, type Delivery } from "@/components/create/PublishOptions";
import { formatInZone } from "@/lib/schedule/time";
import { forgetGreeting, loadSaved, type SavedGreeting } from "@/lib/client/my-greetings";
import { ShareCard } from "@/components/create/ShareCard";

const HASH_RE = /^#([0-9a-f-]{36})\.([A-Za-z0-9_-]{43})$/;

type View =
  | { kind: "list"; saved: SavedGreeting[] }
  | { kind: "loading" }
  | { kind: "error"; message: string }
  | { kind: "greeting"; id: string; token: string; greeting: ManagedGreeting }
  | { kind: "deleted" };

export function ManageClient() {
  const [view, setView] = useState<View>({ kind: "loading" });
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const [editing, setEditing] = useState<Extract<Delivery, { mode: "lock" }> | null>(null);
  const [schedMsg, setSchedMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    setConfirming(false);
    setActionError(null);
    const m = HASH_RE.exec(window.location.hash);
    if (!m) return setView({ kind: "list", saved: loadSaved() });

    setView({ kind: "loading" });
    const [, id, token] = m as unknown as [string, string, string];
    const r = await loadOwned({ id, token });
    setView(r.ok ? { kind: "greeting", id, token, greeting: r.greeting } : { kind: "error", message: r.message });
  }, []);

  useEffect(() => {
    void load();
    const onHash = () => void load();
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, [load]);

  async function remove(id: string, token: string) {
    setBusy(true);
    setActionError(null);
    const r = await deleteOwned({ id, token });
    setBusy(false);
    if (r.ok) {
      forgetGreeting(id);
      setView({ kind: "deleted" });
    } else {
      setActionError(r.message);
    }
  }

  async function reschedule(id: string, token: string, greeting: ManagedGreeting, to: Delivery) {
    const built = buildSchedule(to);
    if (!built.ok) return setSchedMsg(built.message);
    setBusy(true);
    setSchedMsg(null);
    const r = await rescheduleOwned({ id, token }, built.input);
    setBusy(false);
    if (!r.ok) return setSchedMsg(r.message);
    setEditing(null);
    setSchedMsg(r.unlockAt ? "Unlock time updated." : "Opened. The greeting is visible to anyone with the link now.");
    setView({ kind: "greeting", id, token, greeting: { ...greeting, unlockAt: r.unlockAt, unlockTimezone: r.unlockTimezone } });
  }

  if (view.kind === "loading") return <p className="text-ink-soft" role="status">Loading…</p>;

  if (view.kind === "error") {
    return (
      <div>
        <p role="alert" className="rounded-2xl bg-[#fbeaec] p-4 font-medium text-[#780D1B]">{view.message}</p>
        <Link href="/manage" onClick={() => setTimeout(() => void load(), 0)} className="mt-6 inline-block font-semibold underline underline-offset-4">
          See greetings saved in this browser
        </Link>
      </div>
    );
  }

  if (view.kind === "deleted") {
    return (
      <div>
        <p role="status" className="text-lg font-semibold">The greeting was deleted. Its link no longer opens.</p>
        <div className="mt-6 flex gap-3">
          <Link href="/create" className="inline-flex min-h-12 items-center rounded-full bg-crimson px-6 font-semibold text-white hover:bg-crimson-dark">
            Create a greeting
          </Link>
        </div>
      </div>
    );
  }

  if (view.kind === "list") {
    if (view.saved.length === 0) {
      return (
        <div className="max-w-[56ch]">
          <p className="text-lg text-ink-soft">
            No greetings are saved in this browser. To manage a greeting, open its private manage link, which you were shown when you published it.
          </p>
          <Link href="/create" className="mt-6 inline-flex min-h-12 items-center rounded-full bg-crimson px-6 font-semibold text-white hover:bg-crimson-dark">
            Create a greeting
          </Link>
        </div>
      );
    }
    return (
      <ul className="divide-y divide-ink/10 border-y border-ink/10">
        {view.saved.map((g) => (
          <li key={g.id} className="flex flex-wrap items-center justify-between gap-3 py-4">
            <div>
              <p className="font-semibold">{g.label}</p>
              <p className="text-sm text-ink-soft">Created {new Date(g.createdAt).toLocaleDateString()}</p>
            </div>
            <a
              href={`/manage#${g.id}.${g.token}`}
              className="inline-flex min-h-11 items-center rounded-full border border-ink/25 px-5 font-semibold hover:bg-ink/5"
            >
              Manage
            </a>
          </li>
        ))}
      </ul>
    );
  }

  const { greeting, id, token } = view;
  return (
    <div className="space-y-8">
      <p className="text-lg">
        <span className="font-semibold">{greeting.recipientName}</span>
        <span className="text-ink-soft"> · from {greeting.senderName} · </span>
        <span className="font-semibold">{greeting.published ? "Published" : "Not published yet"}</span>
      </p>

      {greeting.published ? (
        <ShareCard url={greeting.url} persistent={greeting.persistent} recipientName={greeting.recipientName} unlockAt={greeting.unlockAt} unlockTimezone={greeting.unlockTimezone} />
      ) : (
        <p className="max-w-[56ch] text-ink-soft">
          This greeting hasn&apos;t been published, so it has no public link. You can delete it below.
        </p>
      )}

      {greeting.published && greeting.unlockAt && Date.parse(greeting.unlockAt) > Date.now() && (
        <div className="rounded-3xl border border-ink/15 bg-white/60 p-5">
          <h2 className="text-lg font-semibold">Locked until {formatInZone(Date.parse(greeting.unlockAt), greeting.unlockTimezone ?? undefined)}</h2>
          <p className="mt-1 max-w-[56ch] text-sm text-ink-soft">
            You can move the time or open it now. Once it has opened it can&apos;t be locked again.
          </p>
          {schedMsg && <p role="status" className="mt-3 text-sm font-medium">{schedMsg}</p>}
          {editing ? (
            <div className="mt-4 space-y-4">
              <ScheduleFields idPrefix="move" value={editing} onChange={setEditing} />
              <div className="flex flex-wrap gap-3">
                <button type="button" disabled={busy} onClick={() => void reschedule(id, token, greeting, editing)} className="min-h-12 rounded-full bg-crimson px-6 font-semibold text-white hover:bg-crimson-dark disabled:opacity-60">
                  {busy ? "Saving…" : "Save new time"}
                </button>
                <button type="button" disabled={busy} onClick={() => setEditing(null)} className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5">Cancel</button>
              </div>
            </div>
          ) : (
            <div className="mt-4 flex flex-wrap gap-3">
              <button type="button" onClick={() => { setSchedMsg(null); setEditing(defaultLock()); }} className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5">Change the time</button>
              <button type="button" disabled={busy} onClick={() => void reschedule(id, token, greeting, { mode: "now" })} className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5 disabled:opacity-60">Open it now</button>
            </div>
          )}
        </div>
      )}

      <div className="rounded-3xl border border-[#e6b3b9] bg-white/60 p-5">
        <h2 className="text-lg font-semibold">Delete this greeting</h2>
        <p className="mt-1 max-w-[56ch] text-sm text-ink-soft">
          This removes the greeting and its photos for good. The link stops working immediately and it can&apos;t be undone.
        </p>
        {actionError && <p role="alert" className="mt-3 text-sm font-medium text-[#B51224]">{actionError}</p>}
        <div className="mt-4 flex flex-wrap gap-3">
          {!confirming ? (
            <button
              type="button"
              onClick={() => setConfirming(true)}
              className="min-h-12 rounded-full border border-[#B51224] px-6 font-semibold text-[#B51224] hover:bg-[#B51224]/5"
            >
              Delete greeting
            </button>
          ) : (
            <>
              <button
                type="button"
                disabled={busy}
                onClick={() => void remove(id, token)}
                className="min-h-12 rounded-full bg-[#B51224] px-6 font-semibold text-white hover:bg-[#780D1B] disabled:opacity-60"
              >
                {busy ? "Deleting…" : "Yes, delete it forever"}
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={() => setConfirming(false)}
                className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5"
              >
                Keep it
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
