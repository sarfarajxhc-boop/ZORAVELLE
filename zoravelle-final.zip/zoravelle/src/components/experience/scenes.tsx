"use client";

import { useId } from "react";
import { AnimatePresence, motion } from "motion/react";
import type { ExperienceConfig } from "@/lib/experience/schema";

export type Palette = ExperienceConfig["theme"]["palette"];
type HeroBlock = Extract<ExperienceConfig["blocks"][number], { type: "hero" }>;
export type SceneName = HeroBlock["scene"];

const SVG_CLS = "mx-auto block w-full max-w-[17rem] overflow-visible";
const HEART24 = "M12 21s-7-4.6-9.3-9.2C1 8.3 3 5 6.3 5c1.9 0 3.4 1 4.2 2.4h1C12.3 6 13.8 5 15.7 5 19 5 21 8.3 19.3 11.8 17 16.4 12 21 12 21z";
const STAR4 = "M12 0l2.4 9.6L24 12l-9.6 2.4L12 24l-2.4-9.6L0 12l9.6-2.4z";
const GOLD = "#fbbf24";
const PARTY = ["#fbbf24", "#34d399", "#60a5fa", "#fb7185", "#fde68a"];

const anim = (dur: number, delay = 0) => ({
  animationDuration: `${dur}s`,
  animationDelay: `${delay}s`,
  animationIterationCount: "infinite" as const,
});

/* ---------- shared pieces (also used by interactions) ---------- */

export function Flame({ x, y, lit, scale = 1 }: { x: number; y: number; lit: boolean; scale?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${scale})`}>
      <AnimatePresence>
        {lit && (
          <motion.g
            initial={{ opacity: 0, scaleY: 0 }}
            animate={{ opacity: 1, scaleY: 1 }}
            exit={{ opacity: 0, scaleY: 0.2, transition: { duration: 0.25 } }}
            style={{ transformBox: "fill-box", transformOrigin: "50% 100%" }}
          >
            <path className="ex-svg-bottom ex-flicker" d="M0 0C-8 -9 -6 -20 0 -30 6 -20 8 -9 0 0Z" fill="#ffb224" />
            <path d="M0 -2C-3 -6 -2 -11 0 -15 2 -11 3 -6 0 -2Z" fill="#fff3c4" />
          </motion.g>
        )}
      </AnimatePresence>
    </g>
  );
}

export function CakeArt({ lit, palette }: { lit: boolean; palette: Palette }) {
  const { accent, accentSoft, text } = palette;
  return (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <ellipse cx="120" cy="212" rx="102" ry="10" fill={text} opacity="0.15" />
      <rect x="45" y="125" width="150" height="85" rx="14" fill={accent} />
      <rect x="45" y="168" width="150" height="9" fill={accentSoft} opacity="0.6" />
      <path d="M45 140c0-10 8-16 16-16h118c8 0 16 6 16 16 0 9-6 12-11 12s-6-7-12-7-6 9-14 9-8-9-15-9-8 8-15 8-8-8-15-8-8 9-14 9-7-8-12-8-6 7-11 7-11-3-11-12Z" fill={accentSoft} />
      {[85, 120, 155].map((x) => (
        <g key={x}>
          <rect x={x - 4} y="96" width="8" height="30" rx="2" fill="#fff6e5" />
          <rect x={x - 4} y="106" width="8" height="4" fill={GOLD} opacity="0.8" />
          <Flame x={x} y={94} lit={lit} />
        </g>
      ))}
    </svg>
  );
}

export function GiftArt({ open, palette }: { open: boolean; palette: Palette }) {
  const { accent, accentSoft } = palette;
  return (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <motion.circle
        cx="120" cy="105" fill={GOLD}
        initial={false}
        animate={{ r: open ? 46 : 4, opacity: open ? 0.55 : 0 }}
        transition={{ duration: 0.6 }}
      />
      <rect x="60" y="112" width="120" height="98" rx="8" fill={accent} />
      <rect x="112" y="112" width="16" height="98" fill={accentSoft} />
      <motion.g
        initial={false}
        animate={open ? { y: -64, x: -14, rotate: -14, opacity: 0.9 } : { y: 0, x: 0, rotate: 0, opacity: 1 }}
        transition={{ type: "spring", stiffness: 120, damping: 12 }}
        style={{ transformBox: "fill-box", transformOrigin: "50% 100%" }}
      >
        <rect x="52" y="86" width="136" height="30" rx="8" fill={accent} />
        <rect x="112" y="86" width="16" height="30" fill={accentSoft} />
        <ellipse cx="100" cy="78" rx="20" ry="11" fill={accentSoft} transform="rotate(-20 100 78)" />
        <ellipse cx="140" cy="78" rx="20" ry="11" fill={accentSoft} transform="rotate(20 140 78)" />
        <circle cx="120" cy="82" r="8" fill={accent} />
      </motion.g>
      <ellipse cx="120" cy="214" rx="86" ry="8" fill="#000" opacity="0.12" />
    </svg>
  );
}

export function DiyaArt({ lit }: { lit: boolean }) {
  return (
    <svg viewBox="0 0 120 120" className="mx-auto block w-full overflow-visible" aria-hidden="true">
      <motion.circle cx="60" cy="48" r="46" fill="#ffb224" initial={false} animate={{ opacity: lit ? 0.28 : 0 }} transition={{ duration: 0.4 }} />
      <path d="M12 66Q60 120 108 66Z" fill="#b4531a" />
      <ellipse cx="60" cy="66" rx="48" ry="8" fill="#d9792b" />
      <path d="M96 66q14-4 18-14-8 2-18 6Z" fill="#b4531a" />
      <Flame x={60} y={64} lit={lit} scale={1.4} />
    </svg>
  );
}

export function LetterArt({ open, palette }: { open: boolean; palette: Palette }) {
  const { accent, accentSoft } = palette;
  return (
    <svg viewBox="0 0 240 220" className={SVG_CLS} aria-hidden="true">
      <rect x="30" y="80" width="180" height="110" rx="8" fill={accentSoft} />
      <motion.path
        d="M30 80h180l-90 64z" fill={accentSoft} stroke={accent} strokeWidth="1"
        initial={false}
        animate={{ opacity: open ? 1 : 0, scaleY: -1 }}
        style={{ transformBox: "fill-box", transformOrigin: "50% 0%" }}
      />
      <motion.rect
        x="48" width="144" height="110" rx="6" fill="#fffdf5"
        initial={false}
        animate={{ y: open ? 28 : 96 }}
        transition={{ type: "spring", stiffness: 90, damping: 14 }}
      />
      <motion.g initial={false} animate={{ opacity: open ? 1 : 0 }}>
        <rect x="68" y="58" width="104" height="5" rx="2.5" fill={accent} opacity="0.35" />
        <rect x="68" y="72" width="80" height="5" rx="2.5" fill={accent} opacity="0.25" />
        <rect x="68" y="86" width="92" height="5" rx="2.5" fill={accent} opacity="0.25" />
      </motion.g>
      <path d="M30 190V84l90 62 90-62v106a8 8 0 0 1-8 8H38a8 8 0 0 1-8-8Z" fill={accent} />
      <motion.g initial={false} animate={{ opacity: open ? 0 : 1 }}>
        <path d="M30 80h180l-90 64z" fill={accentSoft} stroke={accent} strokeWidth="1" />
        <g transform="translate(120 112) scale(1.2)">
          <path d="M0 8c-7-5-10-8-10-12a5 5 0 0 1 10-1 5 5 0 0 1 10 1c0 4-3 7-10 12Z" fill="#e11d48" />
        </g>
      </motion.g>
    </svg>
  );
}

/* ---------- decorative hero scenes ---------- */

function Heart({ x, y, k, fill, cls = "", delay = 0 }: { x: number; y: number; k: number; fill: string; cls?: string; delay?: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${k})`}>
      <path className={`ex-svg ${cls}`} style={{ animationDelay: `${delay}s` }} d={HEART24} fill={fill} />
    </g>
  );
}

function Moon({ cx = 105, cy = 100 }: { cx?: number; cy?: number }) {
  const id = useId().replace(/:/g, "");
  return (
    <>
      <mask id={id}>
        <rect width="240" height="240" fill="#fff" />
        <circle cx={cx + 36} cy={cy - 12} r="52" fill="#000" />
      </mask>
      <circle cx={cx} cy={cy} r="62" fill={GOLD} mask={`url(#${id})`} />
    </>
  );
}

function Stars({ pts, fill = "#fff" }: { pts: [number, number, number][]; fill?: string }) {
  return (
    <>
      {pts.map(([x, y, k], i) => (
        <g key={i} transform={`translate(${x} ${y}) scale(${k})`}>
          <path className="ex-svg ex-twinkle" style={anim(2.4 + (i % 3), -i * 0.7)} d={STAR4} fill={fill} />
        </g>
      ))}
    </>
  );
}

function Lantern({ x, len, color }: { x: number; len: number; color: string }) {
  return (
    <g className="ex-float" style={{ animationDelay: `${-x / 40}s` }}>
      <line x1={x} y1="0" x2={x} y2={len} stroke="#ffffff55" strokeWidth="1.5" />
      <rect x={x - 14} y={len} width="28" height="38" rx="9" fill={color} />
      <rect x={x - 14} y={len} width="28" height="38" rx="9" fill="#fff" opacity="0.18" />
      <rect x={x - 8} y={len - 5} width="16" height="6" rx="2" fill="#7c2d12" />
      <rect x={x - 8} y={len + 36} width="16" height="6" rx="2" fill="#7c2d12" />
    </g>
  );
}

function Starburst({ cx, cy, r, color, delay }: { cx: number; cy: number; r: number; color: string; delay: number }) {
  return (
    <g className="ex-svg ex-pulse" style={{ animationDelay: `${delay}s`, animationDuration: "2.6s" }}>
      {Array.from({ length: 12 }, (_, i) => {
        const a = (i / 12) * Math.PI * 2;
        return (
          <line
            key={i} stroke={color} strokeWidth="3" strokeLinecap="round"
            x1={cx + Math.cos(a) * r * 0.45} y1={cy + Math.sin(a) * r * 0.45}
            x2={cx + Math.cos(a) * r} y2={cy + Math.sin(a) * r}
          />
        );
      })}
      <circle cx={cx} cy={cy} r="4" fill={color} />
    </g>
  );
}

const SCENES: Record<SceneName, (p: { palette: Palette }) => React.ReactNode> = {
  cake: ({ palette }) => <CakeArt lit palette={palette} />,
  giftBox: ({ palette }) => (
    <div className="ex-float"><GiftArt open={false} palette={palette} /></div>
  ),
  hearts: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <Heart x={34} y={34} k={9} fill={palette.accent} cls="ex-pulse" />
      <Heart x={170} y={30} k={2.6} fill={palette.accentSoft} cls="ex-float" delay={-1} />
      <Heart x={28} y={150} k={2} fill={palette.accentSoft} cls="ex-float" delay={-2.2} />
      <Heart x={190} y={150} k={3} fill={palette.accent} cls="ex-float" delay={-0.5} />
    </svg>
  ),
  loveLetter: ({ palette }) => <div className="ex-float"><LetterArt open={false} palette={palette} /></div>,
  crescentLanterns: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <Moon cx={125} cy={115} />
      <Lantern x={34} len={30} color={palette.accent} />
      <Lantern x={206} len={55} color={GOLD} />
      <Stars pts={[[170, 60, 0.5], [60, 150, 0.4], [200, 170, 0.35], [90, 40, 0.3]]} />
    </svg>
  ),
  diyas: () => (
    <div className="mx-auto flex max-w-[20rem] items-end justify-center gap-1">
      {[0.8, 1, 0.8].map((k, i) => (
        <div key={i} style={{ width: `${k * 34}%` }}><DiyaArt lit /></div>
      ))}
    </div>
  ),
  christmasTree: () => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <rect x="108" y="190" width="24" height="30" fill="#7c4a1d" />
      <polygon points="120,30 74,104 166,104" fill="#15803d" />
      <polygon points="120,70 58,146 182,146" fill="#16a34a" />
      <polygon points="120,110 40,194 200,194" fill="#15803d" />
      <g transform="translate(108 8) scale(1)"><path className="ex-svg ex-pulse" d={STAR4} fill={GOLD} /></g>
      {[[100, 92], [140, 128], [88, 160], [150, 172], [118, 140], [70, 184], [172, 186]].map(([x, y], i) => (
        <circle
          key={i} cx={x} cy={y} r="5" fill={["#ef4444", GOLD, "#60a5fa", "#fb7185"][i % 4]}
          className="ex-svg ex-twinkle" style={anim(1.6 + (i % 3) * 0.5, -i * 0.4)}
        />
      ))}
    </svg>
  ),
  fireworks: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <Starburst cx={70} cy={90} r={46} color={GOLD} delay={0} />
      <Starburst cx={172} cy={64} r={40} color="#fb7185" delay={-0.9} />
      <Starburst cx={122} cy={168} r={52} color={palette.accent} delay={-1.7} />
    </svg>
  ),
  colorBurst: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      {[
        [90, 100, 52, "#e11d48"], [150, 90, 48, "#3b82f6"], [120, 150, 54, "#f59e0b"],
        [70, 160, 36, "#22c55e"], [175, 160, 38, palette.accent],
      ].map(([cx, cy, r, f], i) => (
        <circle
          key={i} cx={cx as number} cy={cy as number} r={r as number} fill={f as string} opacity="0.78"
          className="ex-svg ex-pulse" style={{ animationDelay: `${-i * 0.5}s`, animationDuration: "3s" }}
        />
      ))}
    </svg>
  ),
  sunrise: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <g className="ex-svg ex-pulse" style={{ animationDuration: "5s" }}>
        {Array.from({ length: 11 }, (_, i) => {
          const a = Math.PI + (i / 10) * Math.PI;
          return <line key={i} x1={120 + Math.cos(a) * 66} y1={150 + Math.sin(a) * 66} x2={120 + Math.cos(a) * 88} y2={150 + Math.sin(a) * 88} stroke={GOLD} strokeWidth="5" strokeLinecap="round" />;
        })}
      </g>
      <circle cx="120" cy="150" r="52" fill={GOLD} />
      <path d="M0 178Q60 150 120 174T240 168V240H0Z" fill={palette.accent} />
      <path d="M0 204Q70 182 130 200T240 196V240H0Z" fill={palette.text} opacity="0.25" />
    </svg>
  ),
  nightSky: () => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <Moon cx={115} cy={115} />
      <Stars pts={[[40, 50, 0.6], [185, 40, 0.5], [200, 130, 0.4], [50, 170, 0.45], [150, 195, 0.3], [20, 110, 0.3]]} />
    </svg>
  ),
  bloom: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <path d="M120 232C122 190 118 160 120 130" stroke="#16a34a" strokeWidth="6" fill="none" strokeLinecap="round" />
      <ellipse cx="96" cy="196" rx="24" ry="9" fill="#22c55e" transform="rotate(-28 96 196)" />
      <ellipse cx="146" cy="180" rx="24" ry="9" fill="#16a34a" transform="rotate(28 146 180)" />
      <g className="ex-svg ex-pulse" style={{ animationDuration: "4s" }}>
        {Array.from({ length: 8 }, (_, i) => (
          <ellipse key={i} cx="120" cy="82" rx="15" ry="32" fill={i % 2 ? palette.accent : palette.accentSoft} transform={`rotate(${i * 45} 120 120)`} />
        ))}
        <circle cx="120" cy="120" r="17" fill={GOLD} />
      </g>
    </svg>
  ),
  confettiPop: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <polygon points="40,220 92,120 138,172" fill={palette.accent} />
      <polygon points="40,220 66,170 92,198" fill={palette.accentSoft} opacity="0.7" />
      {[
        [120, 80, 0], [150, 50, 1], [180, 100, 2], [110, 30, 3], [196, 60, 4], [160, 140, 0],
        [90, 60, 1], [205, 128, 3], [135, 112, 2], [176, 28, 4], [70, 96, 0], [214, 94, 1],
      ].map(([x, y, c], i) => (
        <rect
          key={i} x={x} y={y} width="8" height="13" rx="2" fill={PARTY[c as number]}
          transform={`rotate(${i * 37} ${(x as number) + 4} ${(y as number) + 6})`}
          className="ex-svg ex-float" style={{ animationDelay: `${-i * 0.35}s` }}
        />
      ))}
    </svg>
  ),
  balloons: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      {[
        { x: 78, y: 92, f: palette.accent, d: 0 }, { x: 128, y: 70, f: palette.accentSoft, d: -1.4 }, { x: 176, y: 98, f: GOLD, d: -2.6 },
      ].map((b) => (
        <g key={b.x} className="ex-float" style={{ animationDelay: `${b.d}s`, animationDuration: "5s" }}>
          <path d={`M${b.x} ${b.y + 46}C${b.x - 8} ${b.y + 100} ${b.x + 10} ${b.y + 120} ${b.x} ${b.y + 150}`} stroke={palette.text} strokeOpacity="0.4" strokeWidth="1.5" fill="none" />
          <ellipse cx={b.x} cy={b.y} rx="36" ry="46" fill={b.f} />
          <ellipse cx={b.x - 12} cy={b.y - 16} rx="7" ry="12" fill="#fff" opacity="0.35" />
          <polygon points={`${b.x - 6},${b.y + 50} ${b.x + 6},${b.y + 50} ${b.x},${b.y + 42}`} fill={b.f} />
        </g>
      ))}
    </svg>
  ),
  polaroids: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      {[
        { x: 28, y: 52, r: -10, f: palette.accentSoft }, { x: 118, y: 40, r: 8, f: palette.accent }, { x: 72, y: 100, r: -2, f: palette.accentSoft },
      ].map((p, i) => (
        <g key={i} transform={`rotate(${p.r} ${p.x + 45} ${p.y + 54})`} className="ex-float" style={{ animationDelay: `${-i * 1.2}s` }}>
          <rect x={p.x} y={p.y} width="90" height="108" rx="4" fill="#fffdf8" stroke="#00000015" />
          <rect x={p.x + 7} y={p.y + 7} width="76" height="76" fill={p.f} opacity="0.85" />
          <g transform={`translate(${p.x + 33} ${p.y + 33}) scale(1)`}><path d={HEART24} fill="#fff" opacity="0.8" /></g>
        </g>
      ))}
    </svg>
  ),
  cardOpen: ({ palette }) => (
    <svg viewBox="0 0 240 240" className={SVG_CLS} aria-hidden="true">
      <g className="ex-float">
        <rect x="55" y="40" width="130" height="170" rx="10" fill={palette.accent} />
        <rect x="65" y="50" width="110" height="150" rx="6" fill="none" stroke={palette.accentSoft} strokeWidth="2" />
        <g transform="translate(98 95) scale(1.1)"><path className="ex-svg ex-pulse" d={STAR4} fill={GOLD} /></g>
        <rect x="85" y="165" width="70" height="5" rx="2.5" fill={palette.accentSoft} />
        <rect x="100" y="176" width="40" height="5" rx="2.5" fill={palette.accentSoft} opacity="0.7" />
      </g>
    </svg>
  ),
};

export function Scene({ name, palette }: { name: SceneName; palette: Palette }) {
  const Render = SCENES[name];
  return <div aria-hidden="true">{Render({ palette })}</div>;
}
