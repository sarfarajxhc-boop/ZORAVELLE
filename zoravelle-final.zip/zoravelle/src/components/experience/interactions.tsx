"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { motion, useReducedMotion } from "motion/react";
import type { ExperienceConfig } from "@/lib/experience/schema";
import { CakeArt, DiyaArt, GiftArt, LetterArt, type Palette } from "./scenes";
import { onColor } from "./color";

type InteractionBlock = Extract<ExperienceConfig["blocks"][number], { type: "interaction" }>;

type Props = {
  kind: InteractionBlock["kind"];
  prompt: string;
  revealText?: string;
  palette: Palette;
  onComplete: () => void;
};

const BURST_COLORS = ["#fbbf24", "#fb7185", "#60a5fa", "#fde68a", "#34d399", "#ffffff"];

/** One-shot radial burst. Skipped entirely under reduced motion. */
export function Burst({ radius = 120, count = 18 }: { radius?: number; count?: number }) {
  const reduce = useReducedMotion();
  if (reduce) return null;
  return (
    <div className="pointer-events-none absolute left-1/2 top-1/2 h-0 w-0" aria-hidden="true">
      {Array.from({ length: count }, (_, i) => {
        const a = (i / count) * Math.PI * 2;
        return (
          <motion.span
            key={i}
            className="absolute -ml-1 -mt-1 h-2 w-2 rounded-full"
            style={{ background: BURST_COLORS[i % BURST_COLORS.length] }}
            initial={{ x: 0, y: 0, opacity: 1, scale: 1 }}
            animate={{ x: Math.cos(a) * radius, y: Math.sin(a) * radius, opacity: 0, scale: 0.4 }}
            transition={{ duration: 1.1, ease: "easeOut" }}
          />
        );
      })}
    </div>
  );
}

function useComplete(onComplete: () => void) {
  const fired = useRef(false);
  return useCallback(
    (delay = 0) => {
      if (fired.current) return;
      fired.current = true;
      setTimeout(onComplete, delay);
    },
    [onComplete],
  );
}

function ActionButton({
  palette, onClick, children, disabled,
}: { palette: Palette; onClick: () => void; children: React.ReactNode; disabled?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="min-h-12 rounded-full px-8 text-lg font-semibold shadow-lg transition-transform active:scale-95 disabled:opacity-60"
      style={{ background: palette.accent, color: onColor(palette.accent) }}
    >
      {children}
    </button>
  );
}

function Prompt({ children }: { children: React.ReactNode }) {
  return <p className="ex-display max-w-[20ch] text-balance text-2xl sm:text-3xl" aria-live="polite">{children}</p>;
}

/* ---------- individual interactions ---------- */

function BlowCandles({ prompt, revealText, palette, onComplete }: Omit<Props, "kind">) {
  const [lit, setLit] = useState(true);
  const complete = useComplete(onComplete);
  return (
    <div className="relative flex flex-col items-center gap-4">
      <button
        type="button"
        aria-label={lit ? "Blow out the candles" : "Candles blown out"}
        disabled={!lit}
        onClick={() => { setLit(false); complete(1400); }}
        className="relative w-full max-w-[17rem]"
      >
        <CakeArt lit={lit} palette={palette} />
        {!lit && <Burst radius={90} />}
      </button>
      <Prompt>{lit ? prompt : revealText ?? "Make a wish!"}</Prompt>
    </div>
  );
}

function OpenGift({ prompt, revealText, palette, onComplete }: Omit<Props, "kind">) {
  const [open, setOpen] = useState(false);
  const complete = useComplete(onComplete);
  return (
    <div className="relative flex flex-col items-center gap-4">
      <button
        type="button"
        aria-label={open ? "Gift opened" : "Open the gift"}
        disabled={open}
        onClick={() => { setOpen(true); complete(1500); }}
        className="relative w-full max-w-[17rem]"
      >
        <GiftArt open={open} palette={palette} />
        {open && <Burst radius={110} />}
      </button>
      <Prompt>{open ? revealText ?? "Surprise!" : prompt}</Prompt>
    </div>
  );
}

function LightDiyas({ prompt, revealText, palette, onComplete }: Omit<Props, "kind">) {
  const [lit, setLit] = useState([false, false, false]);
  const complete = useComplete(onComplete);
  const all = lit.every(Boolean);
  useEffect(() => { if (all) complete(1400); }, [all, complete]);
  return (
    <div className="relative flex flex-col items-center gap-4">
      <div className="flex w-full max-w-[22rem] items-end justify-center">
        {lit.map((on, i) => (
          <button
            key={i}
            type="button"
            aria-pressed={on}
            aria-label={`Diya ${i + 1} of 3, ${on ? "lit" : "unlit"}`}
            onClick={() => setLit((l) => l.map((v, j) => (j === i ? true : v)))}
            className="w-1/3 p-1"
          >
            <DiyaArt lit={on} />
          </button>
        ))}
      </div>
      {all && <Burst radius={100} />}
      <Prompt>{all ? revealText ?? "Light up your year." : prompt}</Prompt>
    </div>
  );
}

function UnwrapLetter({ prompt, revealText, palette, onComplete }: Omit<Props, "kind">) {
  const [open, setOpen] = useState(false);
  const complete = useComplete(onComplete);
  return (
    <div className="flex flex-col items-center gap-4">
      <button
        type="button"
        aria-label={open ? "Letter opened" : "Open the letter"}
        disabled={open}
        onClick={() => { setOpen(true); complete(1700); }}
        className="w-full max-w-[17rem]"
      >
        <LetterArt open={open} palette={palette} />
      </button>
      <Prompt>{open ? revealText ?? "Just for you." : prompt}</Prompt>
    </div>
  );
}

function Countdown({ prompt, revealText, palette, onComplete }: Omit<Props, "kind">) {
  const [n, setN] = useState<number | null>(null);
  const complete = useComplete(onComplete);
  const reduce = useReducedMotion();
  useEffect(() => {
    if (n === null) return;
    if (n === 0) { complete(1600); return; }
    const t = setTimeout(() => setN((v) => (v === null ? v : v - 1)), 900);
    return () => clearTimeout(t);
  }, [n, complete]);
  return (
    <div className="relative flex min-h-56 flex-col items-center justify-center gap-4" aria-live="polite">
      {n === null && <ActionButton palette={palette} onClick={() => setN(3)}>{prompt}</ActionButton>}
      {n !== null && n > 0 && (
        <motion.span
          key={n}
          className="ex-display text-9xl tabular-nums"
          initial={reduce ? false : { scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.35 }}
        >
          {n}
        </motion.span>
      )}
      {n === 0 && (
        <>
          <Burst radius={130} count={24} />
          <Prompt>{revealText ?? "Here we go!"}</Prompt>
        </>
      )}
    </div>
  );
}

function SimpleTap({ kind, prompt, revealText, palette, onComplete }: Props) {
  const [done, setDone] = useState(false);
  const complete = useComplete(onComplete);
  return (
    <div className="relative flex min-h-48 flex-col items-center justify-center gap-5">
      {!done ? (
        <>
          {kind === "tapToBegin" && <p className="text-sm opacity-70">Ready when you are</p>}
          <ActionButton palette={palette} onClick={() => { setDone(true); complete(1200); }}>
            {prompt}
          </ActionButton>
        </>
      ) : (
        <>
          <Burst radius={110} />
          <Prompt>{revealText ?? "Here it is."}</Prompt>
        </>
      )}
    </div>
  );
}

function HoldToCharge({ prompt, revealText, palette, onComplete }: Omit<Props, "kind">) {
  const [p, setP] = useState(0);
  const [done, setDone] = useState(false);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const complete = useComplete(onComplete);

  const stop = useCallback(() => {
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    setP((v) => (v >= 1 ? v : 0));
  }, []);

  const start = useCallback(() => {
    if (done || timer.current) return;
    timer.current = setInterval(() => {
      setP((v) => {
        const next = Math.min(1, v + 0.02);
        if (next >= 1) {
          if (timer.current) clearInterval(timer.current);
          timer.current = null;
          setDone(true);
          complete(1400);
        }
        return next;
      });
    }, 30);
  }, [done, complete]);

  useEffect(() => () => { if (timer.current) clearInterval(timer.current); }, []);

  const C = 2 * Math.PI * 54;
  return (
    <div className="relative flex flex-col items-center gap-4">
      <button
        type="button"
        disabled={done}
        aria-label={done ? "Celebration complete" : "Press and hold to celebrate"}
        onPointerDown={start}
        onPointerUp={stop}
        onPointerLeave={stop}
        onPointerCancel={stop}
        onKeyDown={(e) => { if ((e.key === " " || e.key === "Enter") && !e.repeat) { e.preventDefault(); start(); } }}
        onKeyUp={(e) => { if (e.key === " " || e.key === "Enter") stop(); }}
        onContextMenu={(e) => e.preventDefault()}
        className="relative h-44 w-44 touch-none select-none rounded-full"
      >
        <svg viewBox="0 0 120 120" className="absolute inset-0 -rotate-90" aria-hidden="true">
          <circle cx="60" cy="60" r="54" fill="none" stroke={palette.accentSoft} strokeWidth="8" opacity="0.5" />
          <circle cx="60" cy="60" r="54" fill="none" stroke={palette.accent} strokeWidth="8" strokeLinecap="round" strokeDasharray={C} strokeDashoffset={C * (1 - p)} />
        </svg>
        <span
          className="absolute inset-4 grid place-items-center rounded-full text-lg font-semibold"
          style={{ background: palette.accent, color: onColor(palette.accent), transform: `scale(${0.9 + p * 0.1})` }}
        >
          {done ? "Yes!" : "Hold"}
        </span>
        {done && <Burst radius={120} count={24} />}
      </button>
      <Prompt>{done ? revealText ?? "You did it!" : prompt}</Prompt>
    </div>
  );
}

export function Interaction(props: Props) {
  const { kind, ...rest } = props;
  switch (kind) {
    case "blowCandles": return <BlowCandles {...rest} />;
    case "openGift": return <OpenGift {...rest} />;
    case "lightDiyas": return <LightDiyas {...rest} />;
    case "unwrapLetter": return <UnwrapLetter {...rest} />;
    case "countdown": return <Countdown {...rest} />;
    case "holdToCharge": return <HoldToCharge {...rest} />;
    case "tapToBegin":
    case "tapToReveal":
    default:
      return <SimpleTap {...props} />;
  }
}
