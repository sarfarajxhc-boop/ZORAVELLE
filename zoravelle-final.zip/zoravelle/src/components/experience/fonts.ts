import { Cinzel, Dancing_Script, Nunito, Playfair_Display } from "next/font/google";
import type { ExperienceConfig } from "@/lib/experience/schema";

const playfair = Playfair_Display({ subsets: ["latin"], display: "swap" });
const script = Dancing_Script({ subsets: ["latin"], display: "swap" });
const nunito = Nunito({ subsets: ["latin"], display: "swap" });
const cinzel = Cinzel({ subsets: ["latin"], display: "swap" });

type Pair = { display: string; displayWeight: number; body: string };
const modern = "var(--font-inter), ui-sans-serif, system-ui, sans-serif";

/** Config enum -> font stacks. AI can only choose a key, never a font name. */
export const FONT_STACKS: Record<ExperienceConfig["theme"]["fontPair"], Pair> = {
  elegantSerif: { display: playfair.style.fontFamily, displayWeight: 700, body: playfair.style.fontFamily },
  modernSans: { display: modern, displayWeight: 700, body: modern },
  playfulRounded: { display: nunito.style.fontFamily, displayWeight: 800, body: nunito.style.fontFamily },
  romanticScript: { display: script.style.fontFamily, displayWeight: 700, body: nunito.style.fontFamily },
  classicDisplay: { display: cinzel.style.fontFamily, displayWeight: 700, body: playfair.style.fontFamily },
};
