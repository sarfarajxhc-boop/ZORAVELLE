import type { ExperienceConfig } from "@/lib/experience/schema";
import { mulberry32 } from "./random";

type Props = {
  kind: ExperienceConfig["theme"]["background"];
  palette: ExperienceConfig["theme"]["palette"];
};

const NOISE =
  "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)' opacity='0.5'/></svg>\")";

function Stars({ color }: { color: string }) {
  const rand = mulberry32(7);
  const stars = Array.from({ length: 48 }, (_, i) => ({
    left: rand() * 100,
    top: rand() * 100,
    size: 1 + rand() * 2.2,
    delay: rand() * 4,
    dur: 2.5 + rand() * 3,
    key: i,
  }));
  return (
    <>
      {stars.map((s) => (
        <span
          key={s.key}
          className="absolute rounded-full ex-twinkle"
          style={{
            left: `${s.left}%`,
            top: `${s.top}%`,
            width: s.size,
            height: s.size,
            background: color,
            animationDuration: `${s.dur}s`,
            animationDelay: `${s.delay}s`,
            animationIterationCount: "infinite",
          }}
        />
      ))}
    </>
  );
}

/** Pattern tile for the geometric Islamic style: interlocking eight-point stars. */
function Geometric({ color }: { color: string }) {
  return (
    <svg className="absolute inset-0 h-full w-full" aria-hidden="true">
      <defs>
        <pattern id="ex-geo" width="72" height="72" patternUnits="userSpaceOnUse">
          <g fill="none" stroke={color} strokeWidth="1" opacity="0.28">
            <rect x="18" y="18" width="36" height="36" />
            <rect x="18" y="18" width="36" height="36" transform="rotate(45 36 36)" />
            <circle cx="36" cy="36" r="9" />
            <path d="M0 0L18 18M72 0L54 18M0 72L18 54M72 72L54 54" />
          </g>
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#ex-geo)" />
    </svg>
  );
}

export function Background({ kind, palette }: Props) {
  const { background, accent, accentSoft } = palette;
  const base = { backgroundColor: background };

  switch (kind) {
    case "softGradient":
      return (
        <div
          className="absolute inset-0"
          style={{
            ...base,
            backgroundImage: `radial-gradient(60% 45% at 15% 10%, ${accentSoft}cc, transparent 70%), radial-gradient(55% 45% at 90% 95%, ${accent}33, transparent 70%)`,
          }}
        />
      );
    case "aurora":
      return (
        <div className="absolute inset-0 overflow-hidden" style={base}>
          <div className="ex-drift absolute -left-1/4 top-0 h-2/3 w-3/4 rounded-full opacity-40 blur-3xl" style={{ background: accent }} />
          <div className="ex-drift absolute -right-1/4 bottom-0 h-2/3 w-3/4 rounded-full opacity-40 blur-3xl" style={{ background: accentSoft, animationDelay: "-6s" }} />
        </div>
      );
    case "nightSky":
      return (
        <div className="absolute inset-0 overflow-hidden" style={{ ...base, backgroundImage: `linear-gradient(180deg, ${background}, ${accentSoft}66)` }}>
          <Stars color="#ffffff" />
        </div>
      );
    case "geometricIslamic":
      return (
        <div className="absolute inset-0" style={base}>
          <Geometric color={accent} />
        </div>
      );
    case "paperTexture":
      return <div className="absolute inset-0" style={{ ...base, backgroundImage: NOISE, backgroundBlendMode: "multiply" }} />;
    case "bokeh": {
      const rand = mulberry32(11);
      const dots = Array.from({ length: 9 }, (_, i) => ({
        i, left: rand() * 100, top: rand() * 100, size: 60 + rand() * 120, delay: -rand() * 10,
        color: i % 2 ? accent : accentSoft,
      }));
      return (
        <div className="absolute inset-0 overflow-hidden" style={base}>
          {dots.map((d) => (
            <span
              key={d.i}
              className="ex-drift absolute rounded-full opacity-25 blur-2xl"
              style={{ left: `${d.left}%`, top: `${d.top}%`, width: d.size, height: d.size, background: d.color, animationDelay: `${d.delay}s` }}
            />
          ))}
        </div>
      );
    }
    case "sunrise":
      return (
        <div
          className="absolute inset-0"
          style={{ ...base, backgroundImage: `linear-gradient(0deg, ${accentSoft} 0%, ${accentSoft}88 25%, ${background} 75%)` }}
        />
      );
    case "solid":
    default:
      return <div className="absolute inset-0" style={base} />;
  }
}
