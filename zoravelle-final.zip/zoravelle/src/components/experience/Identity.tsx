import type { CSSProperties, ReactNode } from "react";
import type { ExperienceConfig } from "@/lib/experience/schema";
import { mulberry32 } from "./random";

type Palette = ExperienceConfig["theme"]["palette"];
export type Motif = "sakura" | "sunTorii" | "moon" | "chochin" | "snowPine" | "wave";

/** Each occasion gets one distinct, Japanese-inspired motif. Unknown occasions get sakura. */
const MOTIF_BY_OCCASION: Record<string, Motif> = {
  "new-year": "sunTorii",
  "good-morning": "sunTorii",
  eid: "moon",
  ramadan: "moon",
  "good-night": "moon",
  diwali: "chochin",
  festival: "chochin",
  holi: "chochin",
  christmas: "snowPine",
  friendship: "wave",
  farewell: "wave",
  graduation: "wave",
  congratulations: "wave",
};
export const motifFor = (occasion: string): Motif => MOTIF_BY_OCCASION[occasion] ?? "sakura";

/** Five-petal blossom. */
function Blossom({ x, y, r, fill, core }: { x: number; y: number; r: number; fill: string; core: string }) {
  return (
    <g transform={`translate(${x} ${y})`}>
      {[0, 72, 144, 216, 288].map((a) => (
        <ellipse key={a} cx="0" cy={-r * 0.58} rx={r * 0.42} ry={r * 0.62} fill={fill} transform={`rotate(${a})`} />
      ))}
      <circle r={r * 0.2} fill={core} />
    </g>
  );
}

function Sakura({ p }: { p: Palette }) {
  const rand = mulberry32(21);
  const blossoms = Array.from({ length: 11 }, (_, i) => ({
    x: 250 + rand() * 150, y: 10 + rand() * 190, r: 13 + rand() * 12, i,
  }));
  return (
    <g>
      <g className="ex-sway-top ex-anim ex-glow">
        <path d="M410 40 C 340 60 300 110 250 120 S 170 150 120 210" fill="none" stroke={p.text} strokeOpacity="0.4" strokeWidth="5" strokeLinecap="round" />
        <path d="M330 78 C 310 120 300 150 270 190 M280 112 C 240 100 220 120 200 150" fill="none" stroke={p.text} strokeOpacity="0.35" strokeWidth="3" strokeLinecap="round" />
        {blossoms.map((b) => (
          <Blossom key={b.i} x={b.x} y={b.y} r={b.r} fill={b.i % 3 ? p.accentSoft : p.accent} core={p.text} />
        ))}
      </g>
      {/* low ground blossoms */}
      <g opacity="0.55">
        {[[40, 770], [92, 790], [350, 780]].map(([x = 0, y = 0], i) => (
          <Blossom key={i} x={x} y={y} r={10} fill={p.accentSoft} core={p.accent} />
        ))}
      </g>
    </g>
  );
}

function SunTorii({ p }: { p: Palette }) {
  return (
    <g>
      <g className="ex-rise-sun ex-glow">
        <circle cx="200" cy="230" r="150" fill={p.accent} opacity="0.14" />
        <circle cx="200" cy="230" r="96" fill={p.accent} opacity="0.55" />
      </g>
      {/* torii gate on the horizon, silhouetted */}
      <g transform="translate(0 170)">
        <g fill={p.text} opacity="0.5">
          <rect x="150" y="560" width="10" height="90" />
          <rect x="240" y="560" width="10" height="90" />
          <path d="M132 560 Q 200 545 268 560 L 271 549 Q 200 532 129 549 Z" />
          <rect x="146" y="576" width="108" height="7" />
        </g>
      </g>
      <rect className="ex-mist ex-anim" x="-40" y="700" width="520" height="34" rx="17" fill={p.accentSoft} opacity="0.4" />
      <rect className="ex-mist ex-anim" x="-60" y="750" width="520" height="28" rx="14" fill={p.accentSoft} opacity="0.3" style={{ animationDelay: "-9s" }} />
    </g>
  );
}

function Moon({ p }: { p: Palette }) {
  return (
    <g>
      <g className="ex-glow">
        <circle cx="318" cy="96" r="44" fill={p.accentSoft} opacity="0.5" />
        <circle cx="318" cy="96" r="72" fill={p.accentSoft} opacity="0.12" />
      </g>
      {/* susuki pampas grass, swaying */}
      {[[40, 800, -8], [76, 800, 6], [350, 800, 10], [384, 800, -5]].map(([x = 0, y = 0, lean = 0], i) => (
        <g key={i} className="ex-sway-bottom ex-anim" style={{ animationDelay: `${-i * 1.3}s` }}>
          <path d={`M${x} ${y} Q ${x + lean * 3} ${y - 90} ${x + lean * 6} ${y - 190}`} stroke={p.text} strokeOpacity="0.45" strokeWidth="3" fill="none" strokeLinecap="round" />
          <ellipse cx={x + lean * 6} cy={y - 205} rx="7" ry="30" fill={p.accentSoft} opacity="0.7" transform={`rotate(${lean * 1.4} ${x + lean * 6} ${y - 205})`} />
        </g>
      ))}
    </g>
  );
}

function Chochin({ p }: { p: Palette }) {
  const lamps = [
    { x: 60, drop: 40, s: 0.85, d: 0 },
    { x: 200, drop: 20, s: 0.8, d: -1.6 },
    { x: 340, drop: 50, s: 0.85, d: -3.1 },
  ];
  return (
    <g>
      {lamps.map((l) => (
        <g key={l.x} className="ex-sway-top ex-anim ex-glow" style={{ animationDelay: `${l.d}s` }}>
          <line x1={l.x} y1="0" x2={l.x} y2={l.drop} stroke={p.text} strokeOpacity="0.5" strokeWidth="1.5" />
          <g transform={`translate(${l.x} ${l.drop}) scale(${l.s})`}>
            <rect x="-9" y="0" width="18" height="6" fill={p.text} opacity="0.7" />
            <ellipse cx="0" cy="38" rx="24" ry="34" fill={p.accent} />
            {[18, 30, 42, 54].map((y) => (
              <path key={y} d={`M-${Math.round(Math.sqrt(1 - ((y - 38) / 34) ** 2) * 24)} ${y} H ${Math.round(Math.sqrt(1 - ((y - 38) / 34) ** 2) * 24)}`} stroke={p.background} strokeOpacity="0.45" strokeWidth="1.4" />
            ))}
            <ellipse cx="0" cy="38" rx="24" ry="34" fill="#fff4c2" opacity="0.28" className="ex-flicker ex-anim" />
            <rect x="-9" y="68" width="18" height="6" fill={p.text} opacity="0.7" />
            <line x1="0" y1="74" x2="0" y2="92" stroke={p.accentSoft} strokeWidth="2" />
          </g>
        </g>
      ))}
    </g>
  );
}

function SnowPine({ p }: { p: Palette }) {
  const needles = Array.from({ length: 26 }, (_, i) => i);
  return (
    <g>
      <g className="ex-sway-top ex-anim">
        <path d="M-10 70 C 80 80 150 110 230 170" fill="none" stroke={p.text} strokeOpacity="0.5" strokeWidth="5" strokeLinecap="round" />
        {needles.map((i) => {
          const t = i / 25;
          const x = -10 + t * 240;
          const y = 70 + Math.sin(t * 2.1) * 56 + t * 44;
          return (
            <g key={i}>
              <path d={`M${x} ${y} l ${-10 - t * 8} ${22 + t * 6} M${x} ${y} l ${10 + t * 8} ${22 + t * 6}`} stroke="#2f7d4f" strokeWidth="2.6" strokeLinecap="round" opacity="0.9" />
              <circle cx={x} cy={y - 3} r="3.2" fill="#fff" opacity="0.85" />
            </g>
          );
        })}
      </g>
      <path d="M-20 800 Q 80 740 200 780 T 420 760 V 820 H -20 Z" fill="#fff" opacity="0.8" />
      <path d="M-20 820 Q 120 770 250 800 T 420 790 V 830 H -20 Z" fill={p.accentSoft} opacity="0.5" />
    </g>
  );
}

function Wave({ p }: { p: Palette }) {
  // seigaiha: overlapping concentric arcs, drifting slowly sideways
  return (
    <g>
      <defs>
        <pattern id="ex-seigaiha" width="60" height="30" patternUnits="userSpaceOnUse">
          <g fill="none" stroke={p.accent} strokeOpacity="0.5" strokeWidth="1.4">
            {[0, 30, 60].map((cx) => (
              <g key={cx}>
                <circle cx={cx} cy="30" r="28" />
                <circle cx={cx} cy="30" r="20" />
                <circle cx={cx} cy="30" r="12" />
              </g>
            ))}
          </g>
        </pattern>
      </defs>
      <g className="ex-glow">
        <circle cx="338" cy="92" r="30" fill={p.accent} opacity="0.85" />
      </g>
      <g className="ex-wave ex-anim">
        <rect x="-60" y="690" width="540" height="140" fill="url(#ex-seigaiha)" opacity="0.7" />
      </g>
      <rect x="-20" y="740" width="440" height="80" fill={p.background} opacity="0.55" />
    </g>
  );
}

const MOTIFS: Record<Motif, (props: { p: Palette }) => ReactNode> = {
  sakura: Sakura, sunTorii: SunTorii, moon: Moon, chochin: Chochin, snowPine: SnowPine, wave: Wave,
};

/** Decorative per-occasion art that sits between the background and the content. */
export function Identity({ occasion, palette }: { occasion: string; palette: Palette }) {
  const Motif = MOTIFS[motifFor(occasion)];
  return (
    <div className="ex-parallax pointer-events-none absolute inset-0" style={{ "--ex-par": "-0.12" } as unknown as CSSProperties} aria-hidden="true">
      <svg className="h-full w-full" viewBox="0 0 400 800" preserveAspectRatio="xMidYMid slice" focusable="false">
        <Motif p={palette} />
      </svg>
    </div>
  );
}
