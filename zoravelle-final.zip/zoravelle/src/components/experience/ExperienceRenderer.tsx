"use client";

import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";
import { ChevronDown } from "lucide-react";
import type { ExperienceConfig } from "@/lib/experience/schema";
import { Background } from "./Background";
import { Ambient } from "./Ambient";
import { Scene, type Palette } from "./scenes";
import { Interaction, Burst } from "./interactions";
import { FONT_STACKS } from "./fonts";
import { onColor } from "./color";
import { Identity } from "./Identity";
import { Reveal, InkWords } from "./Reveal";
import { MotionControl } from "./MotionControl";
import { LEVEL_SCALE, useMotionLevel, type MotionLevel } from "./motion-level";
import { lookFor } from "./looks";
import { GoldFrame, Flourish, Crown } from "./Ornaments";

type Block = ExperienceConfig["blocks"][number];

type Props = {
  config: ExperienceConfig;
  /** assetId -> trusted image URL, resolved server-side. Unknown ids are skipped. */
  assets?: Record<string, string>;
  /** "page" fills the screen (published link). "embedded" is a phone-sized preview. */
  mode?: "page" | "embedded";
  /** Shown at the very end, after the greeting has been fully opened. */
  footer?: ReactNode;
  /** Creator preview only: show this look regardless of what this browser remembered. */
  forceLook?: MotionLevel;
};

/**
 * TRUSTED RENDERER. Every field of the config is either an enum that selects a
 * component written in this codebase, a hex colour, or plain text rendered as a
 * React text node. Nothing from the config is ever interpreted as code or markup.
 */
export function ExperienceRenderer({ config, assets = {}, mode = "page", footer, forceLook }: Props) {
  const { theme, ambient, blocks } = config;
  const { level, setLevel, reduced } = useMotionLevel(config.look ?? "cinematic", forceLook);
  // The viewer's look (Calm / Cinematic / Expensive) sets palette, background and lettering.
  const look = lookFor(level, config.occasion);
  const palette = look.palette;
  const fonts = { ...FONT_STACKS[theme.fontPair], display: FONT_STACKS.romanticScript.display, displayWeight: 700 };

  const gateIndex = blocks.findIndex((b) => b.type === "interaction");
  const [unlocked, setUnlocked] = useState(gateIndex < 0);
  const scroller = useRef<HTMLDivElement>(null);
  const rootRef = useRef<HTMLDivElement>(null);

  // Parallax: publish the scroll offset as a CSS variable; layers move at different speeds.
  useEffect(() => {
    const sc = scroller.current;
    const root = rootRef.current;
    if (!sc || !root || reduced || level === "calm") {
      rootRef.current?.style.setProperty("--ex-sy", "0");
      return;
    }
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => root.style.setProperty("--ex-sy", String(sc.scrollTop)));
    };
    sc.addEventListener("scroll", onScroll, { passive: true });
    return () => { sc.removeEventListener("scroll", onScroll); cancelAnimationFrame(raf); };
  }, [level, reduced]);

  const visible = unlocked ? blocks : blocks.slice(0, gateIndex + 1);

  // After the interaction finishes, glide to the next block.
  useEffect(() => {
    if (!unlocked || gateIndex < 0) return;
    const t = setTimeout(() => {
      const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
      scroller.current
        ?.querySelector<HTMLElement>("[data-after-gate]")
        ?.scrollIntoView({ behavior: reduce ? "auto" : "smooth", block: "start" });
    }, 500);
    return () => clearTimeout(t);
  }, [unlocked, gateIndex]);

  const rootStyle = {
    color: palette.text,
    fontFamily: fonts.body,
    "--ex-display": fonts.display,
    "--ex-display-weight": String(fonts.displayWeight),
    "--ex-accent": palette.accent,
  } as CSSProperties;

  return (
    <div
      ref={rootRef}
      data-motion={level}
      className={`relative isolate overflow-hidden ${mode === "page" ? "h-dvh" : "h-[640px] rounded-3xl"}`}
      style={rootStyle}
    >
      {look.image ? (
        // Designed background picture; drifts slowly for depth (Calm and reduced motion keep it still).
        <div aria-hidden="true" className="ex-parallax absolute -inset-[4%]" style={{ "--ex-par": "-0.05" } as CSSProperties}>
          <div
            className="ex-kenburns ex-anim h-full w-full bg-cover bg-center"
            style={{ backgroundColor: palette.background, backgroundImage: `url(${look.image})` }}
          />
        </div>
      ) : (
        <Background kind={look.background} palette={palette} />
      )}
      {look.image && (
        // Soft fade into the look's base colour so the lettering always has a calm area to sit on.
        <div
          aria-hidden="true"
          className="pointer-events-none absolute inset-0"
          style={{ backgroundImage: `linear-gradient(180deg, ${palette.background}00 36%, ${palette.background}d9 62%, ${palette.background}f2 100%)` }}
        />
      )}
      {look.gold && (
        <div aria-hidden="true" className="absolute inset-0" style={{ backgroundImage: "radial-gradient(70% 45% at 50% 0%, rgba(201,162,74,0.18), transparent 70%), radial-gradient(60% 40% at 50% 100%, rgba(201,162,74,0.12), transparent 70%)" }} />
      )}
      {look.frame && <GoldFrame color={palette.accent} />}
      {!look.image && (
        <div className={`pointer-events-none absolute inset-0 ${look.gold ? "ex-goldtone" : ""}`}>
          <Identity occasion={config.occasion} palette={palette} />
        </div>
      )}
      <Ambient effect={look.gold && (ambient.effect === "confetti" || ambient.effect === "colorPowder") ? "sparkles" : ambient.effect} intensity={ambient.intensity} scale={LEVEL_SCALE[level] * (look.image ? 0.6 : 1)} palette={palette} />
      {!reduced && <MotionControl level={level} onChange={setLevel} />}

      <div ref={scroller} className="ex-layer absolute inset-0 z-10 overflow-y-auto overflow-x-hidden">
        <div className="mx-auto w-full max-w-md px-6">
          {visible.map((block, i) => (
            <BlockView
              key={i}
              block={block}
              palette={palette}
              gold={look.gold}
              pictured={Boolean(look.image)}
              shadow={Boolean(look.image) && level !== "calm"}
              assets={assets}
              afterGate={gateIndex >= 0 && i === gateIndex + 1}
              onGateComplete={() => setUnlocked(true)}
              showScrollHint={block.type === "hero" && visible.length > 1}
            />
          ))}
          {unlocked && footer}
          <div className="h-16" />
        </div>
      </div>
    </div>
  );
}

const IMG = "h-full w-full object-cover";
const imgProps = { alt: "", loading: "lazy", decoding: "async", referrerPolicy: "no-referrer" } as const;

/** The creator's photo layout. Every layout shows every photo; only the arrangement changes. */
function Photos({ urls, layout, palette }: { urls: string[]; layout: "polaroid" | "grid" | "filmstrip" | "spotlight"; palette: Palette }) {
  const ring = { border: `1px solid ${palette.accent}` };
  if (layout === "grid") {
    return (
      <div className="grid grid-cols-2 gap-3" data-layout="grid">
        {urls.map((src) => (
          // eslint-disable-next-line @next/next/no-img-element
          <div key={src} className="aspect-square overflow-hidden rounded-xl shadow-lg" style={ring}><img src={src} {...imgProps} className={IMG} /></div>
        ))}
      </div>
    );
  }
  if (layout === "filmstrip") {
    return (
      <div className="-mx-6 flex snap-x snap-mandatory gap-3 overflow-x-auto px-6 pb-3" data-layout="filmstrip" tabIndex={0} aria-label="Photos, swipe to see more">
        {urls.map((src) => (
          // eslint-disable-next-line @next/next/no-img-element
          <div key={src} className="aspect-[4/5] w-[72%] shrink-0 snap-center overflow-hidden rounded-xl shadow-lg" style={ring}><img src={src} {...imgProps} className={IMG} /></div>
        ))}
      </div>
    );
  }
  if (layout === "spotlight") {
    const [first, ...rest] = urls;
    return (
      <div className="space-y-3" data-layout="spotlight">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <div className="aspect-[4/3] overflow-hidden rounded-2xl shadow-xl" style={ring}><img src={first} {...imgProps} className={IMG} /></div>
        {rest.length > 0 && (
          <div className={`grid gap-3 ${rest.length === 1 ? "grid-cols-1" : rest.length === 2 ? "grid-cols-2" : "grid-cols-3"}`}>
            {rest.map((src) => (
              // eslint-disable-next-line @next/next/no-img-element
              <div key={src} className="aspect-square overflow-hidden rounded-xl shadow-md" style={ring}><img src={src} {...imgProps} className={IMG} /></div>
            ))}
          </div>
        )}
      </div>
    );
  }
  return (
    <div className="grid grid-cols-2 gap-4" data-layout="polaroid">
      {urls.map((src, i) => (
        <figure key={src} className="rounded-md bg-[#fffdf8] p-2 pb-6 shadow-lg" style={{ transform: `rotate(${i % 2 ? 2.5 : -2.5}deg)` }}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={src} alt="" loading="lazy" decoding="async" referrerPolicy="no-referrer" className="aspect-square w-full object-cover" />
        </figure>
      ))}
    </div>
  );
}

function BlockView({
  block, palette, gold, pictured, shadow, assets, afterGate, onGateComplete, showScrollHint,
}: {
  block: Block;
  palette: Palette;
  gold: boolean;
  /** The look has a designed background picture, which already carries the scene art. */
  pictured: boolean;
  shadow: boolean;
  assets: Record<string, string>;
  afterGate: boolean;
  onGateComplete: () => void;
  showScrollHint: boolean;
}) {
  const gateAttr = afterGate ? { "data-after-gate": "" } : {};

  switch (block.type) {
    case "hero":
      return (
        <section className={`relative flex min-h-[100cqh] flex-col items-center gap-8 pb-14 text-center ${pictured ? "justify-start pt-[53cqh]" : "justify-center py-14"}`}>
          {!pictured && (
            <div className={`w-full ${gold ? "ex-goldtone" : ""}`}>
              <Scene name={block.scene} palette={palette} />
            </div>
          )}
          <div style={shadow ? { textShadow: "0 2px 18px rgba(0,0,0,0.6)" } : undefined}>
            {gold && <Crown color={palette.accent} />}
            <h1 className={`ex-display text-balance ${pictured ? "text-4xl sm:text-5xl" : "text-5xl sm:text-6xl"} ${gold ? "ex-gold-text" : ""}`}><InkWords text={block.headline} /></h1>
            <Flourish color={palette.accent} />
            {block.subheadline && <p className="mt-3 text-balance text-lg opacity-80">{block.subheadline}</p>}
          </div>
          {showScrollHint && (
            <ChevronDown className="absolute bottom-6 h-7 w-7 animate-bounce opacity-60" aria-hidden="true" />
          )}
        </section>
      );

    case "interaction":
      return (
        <section className="relative flex min-h-[100cqh] flex-col items-center justify-center py-12 text-center">
          <Interaction
            kind={block.kind}
            prompt={block.prompt}
            revealText={block.revealText}
            palette={palette}
            onComplete={onGateComplete}
          />
        </section>
      );

    case "message":
      return (
        <section className="py-12" {...gateAttr}>
          <Reveal>
          <article
            className="rounded-3xl p-6 text-left shadow-xl sm:p-8"
            style={{ background: palette.surface, border: `1px solid ${palette.accentSoft}` }}
          >
            <p className="whitespace-pre-line text-lg leading-relaxed">{block.body}</p>
            {block.signoff && <p className="ex-display mt-6 text-2xl">{block.signoff}</p>}
          </article>
          </Reveal>
        </section>
      );

    case "gallery": {
      const urls = block.assetIds.map((id) => assets[id]).filter((u): u is string => Boolean(u));
      if (urls.length === 0) return null;
      return (
        <section className="py-12" {...gateAttr}>
          <Reveal>
            <Photos urls={urls} layout={block.layout ?? "polaroid"} palette={palette} />
            {block.caption && <p className="mt-6 text-center opacity-80">{block.caption}</p>}
          </Reveal>
        </section>
      );
    }

    case "surprise":
      return <SurpriseView block={block} palette={palette} gateAttr={gateAttr} />;
  }
}

function SurpriseView({
  block, palette, gateAttr,
}: {
  block: Extract<Block, { type: "surprise" }>;
  palette: Palette;
  gateAttr: { "data-after-gate"?: string };
}) {
  const [shown, setShown] = useState(false);
  return (
    <section className="relative py-14 text-center" {...gateAttr}>
      {!shown ? (
        <button
          type="button"
          onClick={() => setShown(true)}
          className="min-h-12 rounded-full px-8 text-lg font-semibold shadow-lg transition-transform active:scale-95"
          style={{ background: palette.accent, color: onColor(palette.accent) }}
        >
          {block.buttonLabel}
        </button>
      ) : (
        <div className="relative flex flex-col items-center gap-6" aria-live="polite">
          <Burst radius={130} count={24} />
          <Scene name={block.scene} palette={palette} />
          <p className="ex-display text-balance text-3xl">{block.text}</p>
        </div>
      )}
    </section>
  );
}
