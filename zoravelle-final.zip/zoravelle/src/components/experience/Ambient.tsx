import type { CSSProperties, ReactNode } from "react";
import type { ExperienceConfig } from "@/lib/experience/schema";
import { mulberry32 } from "./random";

type Props = {
  effect: ExperienceConfig["ambient"]["effect"];
  intensity: number;
  /** Viewer motion level multiplier (Calm 0.4, Cinematic 1, Expressive 1.8). */
  scale?: number;
  palette: ExperienceConfig["theme"]["palette"];
};

const vars = (o: Record<string, string>) => o as unknown as CSSProperties;
const HEART = "M12 21s-7-4.6-9.3-9.2C1 8.3 3 5 6.3 5c1.9 0 3.4 1 4.2 2.4h1C12.3 6 13.8 5 15.7 5 19 5 21 8.3 19.3 11.8 17 16.4 12 21 12 21z";
const STAR4 = "M12 0l2.4 9.6L24 12l-9.6 2.4L12 24l-2.4-9.6L0 12l9.6-2.4z";
const PARTY = ["#fbbf24", "#34d399", "#60a5fa", "#fb7185", "#fde68a"];

type Anim = "ex-fall" | "ex-rise" | "ex-twinkle" | "ex-flutter";
/** A notched cherry-blossom petal. */
const SAKURA_PETAL = "M12 23 C4 17 1 9 5 2 L12 7 L19 2 C23 9 20 17 12 23 Z";

/** One falling / rising / twinkling particle. Negative delay = already mid-flight on load. */
function Particle({
  anim, left, top, dur, delay, sway = 0, spin = 360, children,
}: {
  anim: Anim; left: number; top?: number; dur: number; delay: number;
  sway?: number; spin?: number; children: ReactNode;
}) {
  return (
    <span
      className={`ex-p ${anim}`}
      style={{
        left: `${left}%`,
        ...(top !== undefined ? { top: `${top}%` } : {}),
        animationDuration: `${dur}s`,
        animationDelay: `${delay}s`,
        ...vars({ "--sway": `${sway}px`, "--spin": `${spin}deg` }),
      }}
    >
      {children}
    </span>
  );
}

function Bursts({ count, colors, size, blur }: { count: number; colors: string[]; size: number; blur: number }) {
  const rand = mulberry32(99);
  return (
    <>
      {Array.from({ length: count }, (_, b) => {
        const cx = 12 + rand() * 76;
        const cy = 10 + rand() * 45;
        const delay = -rand() * 4.5;
        const radius = 50 + rand() * 50;
        const color = colors[b % colors.length]!;
        return (
          <span key={b} className="absolute" style={{ left: `${cx}%`, top: `${cy}%` }}>
            {Array.from({ length: 14 }, (_, i) => {
              const a = (i / 14) * Math.PI * 2;
              return (
                <span
                  key={i}
                  className="ex-p ex-burst rounded-full"
                  style={{
                    width: size, height: size, background: color, filter: blur ? `blur(${blur}px)` : undefined,
                    boxShadow: `0 0 8px ${color}`,
                    animationDuration: "4.5s", animationDelay: `${delay}s`,
                    ...vars({ "--dx": `${Math.cos(a) * radius}px`, "--dy": `${Math.sin(a) * radius}px` }),
                  }}
                />
              );
            })}
          </span>
        );
      })}
    </>
  );
}

export function Ambient({ effect, intensity, scale = 1, palette }: Props) {
  if (effect === "none") return null;
  const n = Math.max(1, Math.min(5, intensity));
  const m = Math.max(0.2, scale); // viewer multiplier on particle counts
  const rand = mulberry32(effect.length * 131 + n);
  const R = (a: number, b: number) => a + rand() * (b - a);
  const { accent, accentSoft } = palette;

  let content: ReactNode = null;

  switch (effect) {
    case "confetti": {
      const colors = [accent, accentSoft, ...PARTY];
      content = Array.from({ length: Math.round(n * 8 * m) }, (_, i) => {
        const dur = R(7, 12);
        return (
          <Particle key={i} anim="ex-fall" left={R(0, 100)} dur={dur} delay={-R(0, dur)} sway={R(-40, 40)} spin={R(-720, 720)}>
            <span style={{ display: "block", width: R(6, 10), height: R(10, 16), background: colors[i % colors.length], borderRadius: 2 }} />
          </Particle>
        );
      });
      break;
    }
    case "snow": {
      content = Array.from({ length: Math.round(n * 10 * m) }, (_, i) => {
        const dur = R(9, 18);
        const s = R(3, 8);
        return (
          <Particle key={i} anim="ex-fall" left={R(0, 100)} dur={dur} delay={-R(0, dur)} sway={R(-30, 30)} spin={0}>
            <span style={{ display: "block", width: s, height: s, borderRadius: "50%", background: "#fff", opacity: 0.85, filter: s > 6 ? "blur(1px)" : undefined }} />
          </Particle>
        );
      });
      break;
    }
    case "floatingHearts": {
      content = Array.from({ length: Math.round(n * 4 * m) }, (_, i) => {
        const dur = R(9, 15);
        const s = R(14, 30);
        return (
          <Particle key={i} anim="ex-rise" left={R(0, 100)} dur={dur} delay={-R(0, dur)} sway={R(-30, 30)} spin={R(-30, 30)}>
            <svg width={s} height={s} viewBox="0 0 24 24" style={{ opacity: 0.55 }}>
              <path d={HEART} fill={i % 2 ? accent : accentSoft} />
            </svg>
          </Particle>
        );
      });
      break;
    }
    case "petals": {
      // Sakura: notched petals that tumble in 3D as they fall.
      content = Array.from({ length: Math.round(n * 5 * m) }, (_, i) => {
        const dur = R(11, 18);
        const s = R(12, 22);
        return (
          <Particle key={i} anim="ex-flutter" left={R(0, 100)} dur={dur} delay={-R(0, dur)} sway={R(-70, 70)} spin={R(-300, 300)}>
            <svg width={s} height={s} viewBox="0 0 24 24" style={{ display: "block", opacity: 0.8 }}>
              <path d={SAKURA_PETAL} fill={i % 3 ? accentSoft : accent} />
            </svg>
          </Particle>
        );
      });
      break;
    }
    case "lanterns": {
      content = Array.from({ length: Math.round((n * 2 + 2) * m) }, (_, i) => {
        const dur = R(14, 24);
        const s = R(16, 30);
        return (
          <Particle key={i} anim="ex-rise" left={R(2, 96)} dur={dur} delay={-R(0, dur)} sway={R(-25, 25)} spin={0}>
            <span style={{ display: "block", width: s, height: s * 1.3, borderRadius: "35% 35% 30% 30%", background: i % 2 ? "#fbbf24" : accent, boxShadow: `0 0 18px 4px ${i % 2 ? "#fbbf24" : accent}88`, opacity: 0.85 }} />
          </Particle>
        );
      });
      break;
    }
    case "fireflies":
    case "stars":
    case "sparkles": {
      content = Array.from({ length: Math.round(n * (effect === "stars" ? 9 : 6) * m) }, (_, i) => {
        const dur = R(2.5, 6);
        const s = effect === "stars" ? R(2, 4) : effect === "sparkles" ? R(10, 18) : R(4, 7);
        const glow = effect === "fireflies" ? "#ffd54a" : effect === "stars" ? "#fff" : accent;
        return (
          <Particle key={i} anim="ex-twinkle" left={R(0, 98)} top={R(0, 96)} dur={dur} delay={-R(0, dur)}>
            {effect === "sparkles" ? (
              <svg width={s} height={s} viewBox="0 0 24 24"><path d={STAR4} fill={glow} /></svg>
            ) : (
              <span style={{ display: "block", width: s, height: s, borderRadius: "50%", background: glow, boxShadow: `0 0 ${s * 2}px ${glow}` }} />
            )}
          </Particle>
        );
      });
      break;
    }
    case "fireworks":
      content = <Bursts count={Math.max(1, Math.round((n + 1) * m))} colors={["#fbbf24", "#fb7185", "#60a5fa", "#fde68a", accent]} size={4} blur={0} />;
      break;
    case "colorPowder":
      content = <Bursts count={Math.max(1, Math.round((n + 2) * m))} colors={["#ef4444", "#22c55e", "#3b82f6", "#f59e0b", "#f97316", accent]} size={14} blur={3} />;
      break;
  }

  return (
    <div className="ex-layer pointer-events-none absolute inset-0 overflow-hidden" aria-hidden="true">
      {content}
    </div>
  );
}
