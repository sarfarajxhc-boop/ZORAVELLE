import type { ExperienceConfig } from "@/lib/experience/schema";
import type { MotionLevel } from "./motion-level";
import { motifFor, type Motif } from "./Identity";

type Palette = ExperienceConfig["theme"]["palette"];
type Bg = ExperienceConfig["theme"]["background"];

const p = (background: string, surface: string, text: string, accent: string, accentSoft: string): Palette => ({
  background, surface, text, accent, accentSoft,
});

/** Calm: light, simple, peaceful. */
const CALM: Record<Motif, Palette> = {
  sakura: p("#fbefe4", "#ffffff", "#4a2a1f", "#e08a6f", "#f6cdbb"),
  sunTorii: p("#141a44", "#1d2658", "#f3ead8", "#e7b95a", "#3a4688"),
  moon: p("#ecd9c8", "#fbf3ea", "#3a2a3a", "#c9a15a", "#d9b79c"),
  chochin: p("#f8e3c4", "#fff6e6", "#5a2b12", "#c8782b", "#ecc48e"),
  snowPine: p("#e2e8f5", "#ffffff", "#243a63", "#5b7fbf", "#bcc9e6"),
  wave: p("#f8dccb", "#fff3ea", "#2d3560", "#e07a5f", "#f2b49c"),
};

/** Cinematic: dark, dramatic, glowing. */
const CINEMATIC: Record<Motif, Palette> = {
  sakura: p("#1a0d10", "#2a1419", "#f6e8cc", "#e0a45a", "#7a2430"),
  sunTorii: p("#070b24", "#101a45", "#f6e8cc", "#f0c15a", "#2a3a7a"),
  moon: p("#07142a", "#0f2447", "#f6e8cc", "#f2c66a", "#1d3c6a"),
  chochin: p("#1c0c04", "#2d1608", "#f8e6c4", "#f0a53a", "#6a2a0c"),
  snowPine: p("#08162b", "#10264a", "#f2ead6", "#d9b46a", "#1f4a6a"),
  wave: p("#1a0d1a", "#2a1426", "#f8e4cc", "#f08a4b", "#6a2b3a"),
};

/** Expensive: black and gold, for every occasion. */
const EXPENSIVE: Palette = p("#0a0908", "#15110c", "#e9c978", "#c9a24a", "#6b5421");

const CINEMATIC_BG: Record<Motif, Bg> = {
  sakura: "bokeh", sunTorii: "nightSky", moon: "nightSky", chochin: "bokeh", snowPine: "nightSky", wave: "bokeh",
};

export type Look = { palette: Palette; background: Bg; gold: boolean; frame: boolean; image?: string };

/**
 * Occasions that have a full designed background picture per look (public/looks/<occasion>-<look>.webp).
 * Colours are the lettering and card colours that read well on that picture.
 */
const IMAGE_COLOURS: Record<string, Record<MotionLevel, Palette>> = {
  birthday: {
    calm: p("#fbe3cf", "#fffaf3", "#4a2a1f", "#c9694f", "#f1c9b3"),
    cinematic: p("#120808", "#1c1010", "#f0d29a", "#e2b25f", "#5a2a24"),
    expensive: p("#0a0908", "#14100b", "#e6bf6e", "#c9a24a", "#6b5421"),
  },
  "new-year": {
    calm: p("#141a44", "#1b2456", "#f3ead8", "#e7b95a", "#3a4688"),
    cinematic: p("#070b24", "#0f1840", "#f6e2b4", "#f0c15a", "#2a3a7a"),
    expensive: p("#0a0908", "#14100b", "#e6bf6e", "#c9a24a", "#6b5421"),
  },
  eid: {
    calm: p("#e9cdb8", "#fbf1e7", "#3d2733", "#b98a4a", "#d9b79c"),
    cinematic: p("#07142a", "#0e2142", "#f3dfae", "#f2c66a", "#1d3c6a"),
    expensive: p("#0a0908", "#14100b", "#e6bf6e", "#c9a24a", "#6b5421"),
  },
  diwali: {
    calm: p("#f7dfbd", "#fff6e6", "#5a2b12", "#c8782b", "#ecc48e"),
    cinematic: p("#150a04", "#24120a", "#f6dca6", "#f0a53a", "#6a2a0c"),
    expensive: p("#0a0908", "#14100b", "#e6bf6e", "#c9a24a", "#6b5421"),
  },
  christmas: {
    calm: p("#dfe5f3", "#ffffff", "#223a66", "#5b7fbf", "#bcc9e6"),
    cinematic: p("#08162b", "#0e2244", "#f3e6c4", "#d9b46a", "#1f4a6a"),
    expensive: p("#0a0908", "#14100b", "#e6bf6e", "#c9a24a", "#6b5421"),
  },
  friendship: {
    calm: p("#f1cdbd", "#fff5ef", "#2c2f55", "#e07a5f", "#f2b49c"),
    cinematic: p("#1a0e12", "#261418", "#f6dcae", "#f08a4b", "#6a2b3a"),
    expensive: p("#0a0908", "#14100b", "#e6bf6e", "#c9a24a", "#6b5421"),
  },
};

export function lookFor(level: MotionLevel, occasion: string): Look {
  const motif = motifFor(occasion);
  const pic = IMAGE_COLOURS[occasion]?.[level];
  if (pic) {
    return {
      palette: pic,
      background: "solid",
      gold: level === "expensive",
      frame: false,
      image: `/looks/${occasion}-${level}.webp`,
    };
  }
  switch (level) {
    case "calm":
      return { palette: CALM[motif], background: "paperTexture", gold: false, frame: false };
    case "expensive":
      return { palette: EXPENSIVE, background: "solid", gold: true, frame: true };
    case "cinematic":
    default:
      return { palette: CINEMATIC[motif], background: CINEMATIC_BG[motif], gold: false, frame: false };
  }
}
