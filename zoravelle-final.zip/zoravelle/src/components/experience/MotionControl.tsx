"use client";

import { MOTION_LEVELS, type MotionLevel } from "./motion-level";

const LABEL: Record<MotionLevel, string> = { calm: "Calm", cinematic: "Cinematic", expensive: "Expensive" };

/** Small viewer control: how much the greeting should move. */
export function MotionControl({ level, onChange }: { level: MotionLevel; onChange: (l: MotionLevel) => void }) {
  return (
    <div
      role="group"
      aria-label="Greeting style"
      className="absolute right-3 top-3 z-20 flex rounded-full bg-black/45 p-0.5 text-[0.7rem] font-semibold text-white backdrop-blur-md"
    >
      {MOTION_LEVELS.map((l) => (
        <button
          key={l}
          type="button"
          aria-pressed={level === l}
          onClick={() => onChange(l)}
          className={`min-h-9 rounded-full px-3 transition-colors ${level === l ? "bg-white text-black" : "text-white/80 hover:text-white"}`}
        >
          {LABEL[l]}
        </button>
      ))}
    </div>
  );
}
