import type { CSSProperties } from "react";

/** Thin gold double border with corner flourishes, for the Expensive look. */
export function GoldFrame({ color }: { color: string }) {
  const corner = (rot: number, x: number, y: number) => (
    <g transform={`translate(${x} ${y}) rotate(${rot})`} fill="none" stroke={color} strokeWidth="1.2">
      <path d="M0 40 V10 Q0 0 10 0 H40" />
      <path d="M10 40 V18 Q10 10 18 10 H40" opacity="0.5" />
      <path d="M-2 -2 l5 5 l-5 5 l-5 -5 Z" fill={color} transform="translate(14 14) scale(0.7)" />
    </g>
  );
  return (
    <svg className="pointer-events-none absolute inset-0 z-[5] h-full w-full" viewBox="0 0 400 800" preserveAspectRatio="none" aria-hidden="true" focusable="false">
      <rect x="10" y="10" width="380" height="780" rx="22" fill="none" stroke={color} strokeOpacity="0.55" strokeWidth="1.2" vectorEffect="non-scaling-stroke" />
      <g style={{ filter: `drop-shadow(0 0 4px ${color}88)` } as CSSProperties}>
        {corner(0, 22, 22)}{corner(90, 378, 22)}{corner(180, 378, 778)}{corner(270, 22, 778)}
      </g>
    </svg>
  );
}

/** Line, diamond, line: sits under the headline. */
export function Flourish({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 160 14" className="mx-auto mt-4 h-3.5 w-40" aria-hidden="true" focusable="false">
      <path d="M0 7 H62 M98 7 H160" stroke={color} strokeWidth="1" strokeOpacity="0.8" />
      <path d="M80 1 L86 7 L80 13 L74 7 Z" fill={color} />
      <circle cx="66" cy="7" r="1.6" fill={color} />
      <circle cx="94" cy="7" r="1.6" fill={color} />
    </svg>
  );
}

/** Small crown that sits above the headline in the Expensive look. */
export function Crown({ color }: { color: string }) {
  return (
    <svg viewBox="0 0 64 40" className="mx-auto mb-3 h-9 w-14" aria-hidden="true" focusable="false">
      <path d="M6 32 L10 10 L22 22 L32 6 L42 22 L54 10 L58 32 Z" fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
      <path d="M8 36 H56" stroke={color} strokeWidth="2.4" strokeLinecap="round" />
      {[[10, 8], [32, 4], [54, 8]].map(([x = 0, y = 0]) => <circle key={x} cx={x} cy={y} r="2.6" fill={color} />)}
    </svg>
  );
}
