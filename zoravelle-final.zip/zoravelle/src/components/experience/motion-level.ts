"use client";

import { useCallback, useEffect, useState } from "react";

/** The viewer's "look": Calm (light, simple), Cinematic (dark, dramatic), Expensive (black and gold). */
export type MotionLevel = "calm" | "cinematic" | "expensive";
export const MOTION_LEVELS: readonly MotionLevel[] = ["calm", "cinematic", "expensive"];

/** Particle-count multiplier per level. */
export const LEVEL_SCALE: Record<MotionLevel, number> = { calm: 0.4, cinematic: 1, expensive: 1.2 };

const KEY = "zoravelle.motion";

/**
 * The viewer's motion level. Defaults to the creator's pick (else "cinematic"), or "calm" when the device asks for
 * reduced motion. The choice is remembered in this browser only (storage may be unavailable).
 */
export function useMotionLevel(initial: MotionLevel = "cinematic", force?: MotionLevel) {
  const [level, setLevelState] = useState<MotionLevel>(initial);
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const apply = () => {
      setReduced(mq.matches);
      if (mq.matches) return setLevelState("calm");
      try {
        const saved = window.localStorage.getItem(KEY);
        if (saved && (MOTION_LEVELS as readonly string[]).includes(saved)) setLevelState(saved as MotionLevel);
      } catch { /* storage blocked: keep the default */ }
    };
    apply();
    mq.addEventListener("change", apply);
    return () => mq.removeEventListener("change", apply);
  }, []);

  // The creator's preview forces the look being edited; it ignores what this browser remembered.
  useEffect(() => {
    if (force && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) setLevelState(force);
  }, [force]);

  const setLevel = useCallback((l: MotionLevel) => {
    setLevelState(l);
    try { window.localStorage.setItem(KEY, l); } catch { /* ignore */ }
  }, []);

  return { level, setLevel, reduced };
}
