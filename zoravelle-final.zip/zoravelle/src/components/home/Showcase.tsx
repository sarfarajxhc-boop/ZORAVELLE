"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { Container } from "@/components/ui/Container";
import { WishStage } from "./WishStage";

type Demo = "birthday" | "diwali" | "newyear";

function Diya({ lit, onToggle, label }: { lit: boolean; onToggle: () => void; label: string }) {
  const reduce = useReducedMotion();
  return (
    <button
      type="button"
      onClick={onToggle}
      aria-pressed={lit}
      aria-label={label}
      className="p-1"
    >
      <svg viewBox="0 0 80 76" className="h-20 w-20 overflow-visible sm:h-24 sm:w-24" aria-hidden="true">
        <motion.circle
          cx="40" cy="26" r="34" fill="#e0b25a"
          animate={{ opacity: lit ? 0.25 : 0 }}
          transition={{ duration: 0.4 }}
        />
        <path d="M6 44Q40 84 74 44Z" fill="#b4531a" />
        <ellipse cx="40" cy="44" rx="34" ry="6" fill="#d9792b" />
        <AnimatePresence>
          {lit && (
            <motion.path
              d="M40 42C31 33 34 21 40 8 46 21 49 33 40 42Z"
              fill="#e0b25a"
              style={{ transformBox: "fill-box", transformOrigin: "50% 100%" }}
              initial={{ scaleY: 0, opacity: 0 }}
              animate={reduce ? { scaleY: 1, opacity: 1 } : { scaleY: [1, 1.12, 0.94, 1.06, 1], opacity: 1 }}
              transition={{ duration: 1.2, repeat: reduce ? 0 : Infinity, ease: "easeInOut" }}
              exit={{ opacity: 0, scaleY: 0.2, transition: { duration: 0.2 } }}
            />
          )}
        </AnimatePresence>
      </svg>
    </button>
  );
}

function DiwaliDemo() {
  const [lit, setLit] = useState<boolean[]>([false, false, false, false, false]);
  const count = lit.filter(Boolean).length;
  const done = count === lit.length;
  return (
    <div className="text-center">
      <div className="flex flex-wrap justify-center gap-1 sm:gap-3">
        {lit.map((on, i) => (
          <Diya
            key={i}
            lit={on}
            label={`Diya ${i + 1} of ${lit.length}, ${on ? "lit" : "unlit"}`}
            onToggle={() => setLit((l) => l.map((v, j) => (j === i ? !v : v)))}
          />
        ))}
      </div>
      <div className="mt-6 min-h-16" aria-live="polite">
        {done ? (
          <>
            <p className="font-display text-2xl font-semibold tracking-tight">Shubh Diwali, Priya.</p>
            <p className="mt-1 text-sm text-paper/70">May the year ahead glow. With love, Rohan.</p>
          </>
        ) : (
          <p className="text-paper/80">Tap each diya to light it ({count} of {lit.length})</p>
        )}
      </div>
    </div>
  );
}

const BURST_COLORS = ["#e0b25a", "#b51224", "#ffffff", "#d4af6a", "#f5efe3"];

function NewYearDemo() {
  const [count, setCount] = useState<number | null>(null);
  const reduce = useReducedMotion();

  useEffect(() => {
    if (count === null || count <= 0) return;
    const t = setTimeout(() => setCount((c) => (c === null ? c : c - 1)), 900);
    return () => clearTimeout(t);
  }, [count]);

  return (
    <div className="text-center">
      <div className="relative mx-auto grid h-40 place-items-center sm:h-48" aria-live="polite">
        {count === null && (
          <button
            type="button"
            onClick={() => setCount(3)}
            className="rounded-full bg-crimson px-7 py-3 text-base font-semibold text-white hover:bg-crimson-dark"
          >
            Start the countdown
          </button>
        )}
        {count !== null && count > 0 && (
          <motion.span
            key={count}
            className="text-8xl font-bold tabular-nums"
            initial={reduce ? false : { scale: 0.6, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.35 }}
          >
            {count}
          </motion.span>
        )}
        {count === 0 && (
          <>
            {!reduce &&
              Array.from({ length: 18 }, (_, i) => {
                const a = (i / 18) * Math.PI * 2;
                return (
                  <motion.span
                    key={i}
                    aria-hidden="true"
                    className="absolute h-2 w-2 rounded-full"
                    style={{ background: BURST_COLORS[i % BURST_COLORS.length] }}
                    initial={{ x: 0, y: 0, opacity: 1 }}
                    animate={{ x: Math.cos(a) * 110, y: Math.sin(a) * 110, opacity: 0 }}
                    transition={{ duration: 1.1, ease: "easeOut" }}
                  />
                );
              })}
            <div>
              <p className="font-display text-3xl font-semibold tracking-tight sm:text-4xl">Happy New Year, Dev.</p>
              <p className="mt-1 text-sm text-paper/70">Here&apos;s to a brilliant one. With love, Sana.</p>
            </div>
          </>
        )}
      </div>
      {count === 0 && (
        <button
          type="button"
          onClick={() => setCount(null)}
          className="mt-4 text-sm font-medium text-paper/80 underline underline-offset-4 hover:text-paper"
        >
          Play it again
        </button>
      )}
    </div>
  );
}

export function Showcase() {
  const [demo, setDemo] = useState<Demo>("birthday");
  const tabs: { id: Demo; label: string }[] = [
    { id: "birthday", label: "Birthday" },
    { id: "diwali", label: "Diwali" },
    { id: "newyear", label: "New Year" },
  ];

  return (
    <section id="demo" className="scroll-mt-20 bg-night text-paper" aria-labelledby="showcase-title">
      <Container className="py-16 md:py-24">
        <p className="text-xs font-semibold uppercase tracking-[0.28em] text-gold-bright">Experience it</p>
        <h2 id="showcase-title" className="mt-3 max-w-[18ch] text-balance text-3xl font-semibold sm:text-5xl">
          Try one yourself
        </h2>
        <p className="mt-4 max-w-[44ch] text-paper/75">
          These are three of the greetings your recipients can open. Every occasion gets its own scene and its own way to play.
        </p>

        <div role="tablist" aria-label="Example greetings" className="mt-8 inline-flex rounded-full bg-paper/10 p-1">
          {tabs.map((t) => (
            <button
              key={t.id}
              role="tab"
              type="button"
              id={`tab-${t.id}`}
              aria-selected={demo === t.id}
              aria-controls="showcase-panel"
              onClick={() => setDemo(t.id)}
              className={`min-h-10 rounded-full px-5 text-sm font-semibold transition-colors ${
                demo === t.id ? "bg-paper text-ink" : "text-paper/80 hover:text-paper"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div
          id="showcase-panel"
          role="tabpanel"
          aria-labelledby={`tab-${demo}`}
          className="mt-8 rounded-[2rem] border border-gold/25 bg-paper/[0.03] px-5 py-10 sm:py-14"
        >
          {demo === "birthday" ? (
            <div className="mx-auto max-w-md"><WishStage /></div>
          ) : demo === "diwali" ? (
            <DiwaliDemo />
          ) : (
            <NewYearDemo />
          )}
        </div>
      </Container>
    </section>
  );
}
