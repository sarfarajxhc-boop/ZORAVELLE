"use client";

import { motion, useReducedMotion } from "motion/react";
import Image from "next/image";
import { ArrowUpRight, Globe, Mail } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { InstagramIcon } from "@/components/ui/InstagramIcon";
import { CREATOR } from "@/lib/creator";

const INTRO: string[] = [
  "Just a simple 19-year-old boy from a small town called Murshidabad, West Bengal.",
  "Well, I don't want to make this sound like some formal introduction, so let's talk like friends!",
  "I believe every special moment deserves something more than an ordinary greeting. Sometimes, a small surprise, a few heartfelt words, or a little creative effort can bring the biggest smile to someone's face.",
  "And honestly, that's what inspired me to create ZORAVELLE.",
  "I always felt that expressing our feelings shouldn't be limited to just sending a simple text or wishing someone with a few ordinary words. The people we care about deserve something a little more special, don't they?",
  "That's where the idea of ZORAVELLE came from.",
  "I wanted to create a place where emotions could turn into experiences — where a simple greeting could become a beautiful surprise, where creativity could speak when words fall short, and where people could make their loved ones feel truly special.",
  "For me, ZORAVELLE isn't just about creating digital greetings. It's about the smiles behind the screen, the unexpected happiness, the little moments of surprise, and the memories people might carry with them for years.",
  "And you know what? There's something genuinely special about knowing that something I created might become a small part of someone's beautiful memory.",
  "That's something I'm genuinely proud of.",
  "I'm young, and I know I still have a lot to learn. But I also believe that age doesn't have to define the size of your dreams or the value of your ideas.",
  "I'm not building ZORAVELLE just to say I created a website. I want to build something people genuinely enjoy using, something that stands out, and something that leaves a little happiness behind.",
  "I have big ambitions for this project, and I'm willing to put in the work to make them real.",
  "I know there will be mistakes, challenges, and plenty of things to improve. I'm not afraid of that. Every successful creation starts somewhere, and I'm ready to learn, experiment, improve, and keep moving forward.",
  "ZORAVELLE is still growing. My vision is bigger than what you see on this website today. And honestly, this is just the beginning.",
];

const NOTE: string[] = [
  "If you've made it this far, first of all, thank you for taking the time to know a little about me!",
  "And if you ever have an idea, suggestion, feedback, or even find something that isn't working properly, please feel free to reach out.",
  "Seriously, don't hesitate!",
  "I'm always open to learning from others. Whether it's a small suggestion, honest criticism, or a completely new idea, I'd genuinely love to hear it.",
  "I may not be able to implement every suggestion immediately, but I'll always appreciate the time you took to share it.",
  "After all, a project becomes better not just because of the person who builds it, but also because of the people who support it, use it, and share their thoughts.",
  "Thank you for being here, for exploring ZORAVELLE, and perhaps for becoming a small part of this journey. It means more than you might think. ❤️",
];

/** Fades and lifts into view once. With reduced motion it renders plainly. */
function Reveal({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const reduce = useReducedMotion();
  if (reduce) return <div className={className}>{children}</div>;
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.7, delay, ease: "easeOut" }}
    >
      {children}
    </motion.div>
  );
}

const card =
  "group relative flex min-h-24 items-center gap-4 rounded-3xl border border-ink/15 bg-white p-5 text-ink " +
  "transition duration-300 hover:-translate-y-1 hover:border-rose/60 hover:shadow-xl focus-visible:-translate-y-1";
const iconWrap =
  "grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-ink text-paper transition duration-300 group-hover:bg-rose";

export function CreatorVision() {
  return (
    <section aria-labelledby="creator-vision-title" className="relative overflow-hidden border-t border-ink/10">
      {/* soft background glow, decorative */}
      <div aria-hidden="true" className="pointer-events-none absolute -left-32 top-24 h-96 w-96 rounded-full bg-marigold/20 blur-3xl" />
      <div aria-hidden="true" className="pointer-events-none absolute -right-32 bottom-40 h-96 w-96 rounded-full bg-gold/10 blur-3xl" />

      <Container className="relative py-16 md:py-28">
        <Reveal>
          <p className="text-sm font-semibold uppercase tracking-[0.2em] text-rose">From the person behind it</p>
          <h2 id="creator-vision-title" className="mt-3 text-4xl font-bold tracking-tight sm:text-6xl">
            Creator Vision
          </h2>
        </Reveal>

        {/* 1. Introduction */}
        <div className="mt-12 grid gap-10 lg:grid-cols-[1fr_1.2fr] lg:gap-16">
          <Reveal className="lg:sticky lg:top-10 lg:self-start">
            <figure>
              <div className="group relative rounded-[1.75rem] bg-white p-2.5 shadow-xl ring-1 ring-ink/10 transition duration-500 hover:shadow-2xl sm:p-3">
                <Image
                  src="/creator-vision.webp"
                  alt="Black and white portrait of Sarfaraj, resting his chin on his arm and looking into the camera"
                  width={1080}
                  height={606}
                  sizes="(min-width: 1024px) 480px, 100vw"
                  className="h-auto w-full rounded-[1.25rem]"
                />
              </div>
              <figcaption className="mt-4 text-sm text-ink-soft">
                {CREATOR.name}, 19, Murshidabad, West Bengal
              </figcaption>
            </figure>
          </Reveal>

          <div>
            <Reveal>
              <p className="text-2xl font-semibold sm:text-3xl">
                Hiiii! <span aria-hidden="true">👋❤️</span>
              </p>
              <p className="mt-3 text-3xl sm:text-4xl">
                I&apos;m <span className="font-bold text-rose">{CREATOR.name}</span>.
              </p>
            </Reveal>
            <div className="mt-6 max-w-[62ch] space-y-5 text-lg leading-[1.8] text-ink-soft">
              {INTRO.map((p) => (
                <Reveal key={p}>
                  <p>{p}</p>
                </Reveal>
              ))}
            </div>
          </div>
        </div>

        {/* 2. A little note */}
        <Reveal className="mt-20">
          <div className="relative overflow-hidden rounded-[2rem] bg-ink p-7 text-paper shadow-2xl sm:p-12">
            <div aria-hidden="true" className="pointer-events-none absolute -right-20 -top-20 h-64 w-64 rounded-full bg-rose/30 blur-3xl" />
            <div className="relative max-w-[62ch]">
              <h3 className="text-2xl font-bold tracking-tight sm:text-4xl">
                A Little Note From My Heart <span aria-hidden="true">💌</span>
              </h3>
              <div className="mt-6 space-y-4 text-lg leading-[1.8] text-paper/85">
                {NOTE.map((p) => (
                  <p key={p}>{p}</p>
                ))}
              </div>
            </div>
          </div>
        </Reveal>

        {/* 3. Connect */}
        <Reveal className="mt-20">
          <h3 className="text-2xl font-bold tracking-tight sm:text-4xl">
            Let&apos;s Connect! <span aria-hidden="true">🌐</span>
          </h3>
          <ul className="mt-8 grid gap-4 md:grid-cols-3">
            <li>
              <a href={CREATOR.instagram} target="_blank" rel="noopener noreferrer" className={card}>
                <span className={iconWrap}><InstagramIcon className="h-6 w-6" /></span>
                <span className="min-w-0">
                  <span className="block text-sm text-ink-soft">Instagram</span>
                  <span className="block truncate font-semibold">{CREATOR.instagramHandle}</span>
                  <span className="sr-only">(opens in a new tab)</span>
                </span>
                <ArrowUpRight className="ml-auto h-5 w-5 shrink-0 text-ink-soft transition group-hover:text-rose" aria-hidden="true" />
              </a>
            </li>
            <li>
              <a href={`mailto:${CREATOR.email}`} className={card}>
                <span className={iconWrap}><Mail className="h-6 w-6" aria-hidden="true" /></span>
                <span className="min-w-0">
                  <span className="block text-sm text-ink-soft">Email</span>
                  <span className="block truncate font-semibold">{CREATOR.email}</span>
                </span>
                <ArrowUpRight className="ml-auto h-5 w-5 shrink-0 text-ink-soft transition group-hover:text-rose" aria-hidden="true" />
              </a>
            </li>
            <li>
              <a href={CREATOR.website} target="_blank" rel="noopener noreferrer" className={card}>
                <span className={iconWrap}><Globe className="h-6 w-6" aria-hidden="true" /></span>
                <span className="min-w-0">
                  <span className="block text-sm text-ink-soft">Portfolio</span>
                  <span className="block font-semibold">Visit My Portfolio</span>
                  <span className="sr-only">(opens in a new tab)</span>
                </span>
                <ArrowUpRight className="ml-auto h-5 w-5 shrink-0 text-ink-soft transition group-hover:text-rose" aria-hidden="true" />
              </a>
            </li>
          </ul>
        </Reveal>
      </Container>
    </section>
  );
}
