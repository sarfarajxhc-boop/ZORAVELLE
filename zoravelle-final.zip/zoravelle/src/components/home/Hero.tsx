import Link from "next/link";
import { ArrowRight, Play } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { BlossomBranch, GiftBoxArt, Pagoda, Petals } from "./art";

export function Hero() {
  return (
    <section
      className="relative isolate overflow-hidden bg-[#0a0a0a] text-white"
      style={{
        backgroundImage:
          "radial-gradient(70% 90% at 82% 28%, rgba(224,130,150,0.38), transparent 70%), linear-gradient(90deg, #0a0a0a 34%, #1b0b10 100%)",
      }}
    >
      <BlossomBranch className="pointer-events-none absolute -right-10 -top-4 z-0 w-[15rem] opacity-60 sm:w-[30rem] sm:opacity-95 lg:w-[36rem]" />
      <Pagoda className="pointer-events-none absolute bottom-16 right-0 z-0 hidden w-44 opacity-40 md:block lg:right-8 lg:w-56" />
      <Petals count={18} core={7} travel={860} className="z-10" />

      <Container className="relative z-10 grid gap-10 pb-28 pt-14 md:grid-cols-[1fr_1.05fr] md:items-center md:gap-6 md:pb-36 md:pt-20">
        <div>
          <p className="flex items-center gap-3 text-[0.7rem] font-semibold uppercase tracking-[0.3em] text-white/70">
            <span aria-hidden="true" className="h-px w-8 bg-white/40" />
            Interactive digital greetings
            <span aria-hidden="true" className="h-px w-8 bg-white/40" />
          </p>
          <h1 className="mt-6 text-balance text-6xl font-medium leading-[0.98] sm:text-7xl lg:text-8xl">
            Make every wish an <span className="italic text-[#d8333f]">experience.</span>
          </h1>
          <p className="mt-6 max-w-[40ch] text-lg leading-relaxed text-white/80">
            Create stunning, personalised greetings with animations, photos and AI-powered messages. Turn your
            feelings into unforgettable moments.
          </p>
          <div className="mt-9 flex flex-wrap items-center gap-4">
            <Link
              href="/create"
              className="inline-flex min-h-14 items-center gap-3 rounded-full bg-crimson px-8 text-base font-semibold text-white shadow-[0_10px_30px_-8px_rgba(181,18,36,0.8)] transition-colors hover:bg-crimson-dark"
            >
              Start Creating
              <ArrowRight className="h-5 w-5" aria-hidden="true" />
            </Link>
            <a href="#demo" className="group inline-flex min-h-14 items-center gap-3 rounded-full pr-4 text-base font-medium text-white/90">
              <span className="grid h-12 w-12 place-items-center rounded-full border border-white/40 transition-colors group-hover:border-white group-hover:bg-white/10">
                <Play className="h-4 w-4 fill-current" aria-hidden="true" />
              </span>
              Watch Demo
            </a>
          </div>
        </div>

        <GiftBoxArt className="mx-auto w-full max-w-[34rem] drop-shadow-[0_30px_60px_rgba(0,0,0,0.55)] md:max-w-none" />
      </Container>

      {/* fades into the white page below */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-x-0 bottom-0 z-10 h-28 bg-gradient-to-b from-transparent to-white" />
    </section>
  );
}
