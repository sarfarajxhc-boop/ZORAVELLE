import { Container } from "@/components/ui/Container";

const STEPS = [
  { title: "Pick an occasion", body: "Choose from birthdays to Diwali, or describe your own." },
  { title: "Add the details", body: "Names, a message and a few photos if you like. Tell the AI the mood you want." },
  { title: "Preview and adjust", body: "See the greeting as your recipient will, then edit the words or regenerate it." },
  { title: "Publish and share", body: "You get a link. Send it in any chat; it opens right in the browser." },
];

export function HowItWorks() {
  return (
    <section aria-labelledby="how-title" className="border-t border-ink/10">
      <Container className="grid gap-10 py-16 md:grid-cols-[0.8fr_1.2fr] md:gap-16 md:py-24">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.28em] text-gold">The process</p>
          <h2 id="how-title" className="mt-3 max-w-[14ch] text-balance text-3xl font-semibold sm:text-5xl">
            How it works
          </h2>
        </div>
        <ol className="divide-y divide-ink/10 border-y border-ink/10">
          {STEPS.map((s, i) => (
            <li key={s.title} className="grid grid-cols-[3rem_1fr] gap-4 py-6 sm:grid-cols-[4rem_1fr]">
              <span className="font-display text-4xl font-semibold tabular-nums text-gold sm:text-5xl">{String(i + 1).padStart(2, "0")}</span>
              <div>
                <h3 className="text-xl font-semibold">{s.title}</h3>
                <p className="mt-1 max-w-[46ch] text-ink-soft">{s.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </Container>
    </section>
  );
}
