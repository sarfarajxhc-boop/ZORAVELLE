"use client";

import { useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";

const CANDLES = [110, 160, 210];
const SPARKS = Array.from({ length: 12 }, (_, i) => ({
  x: (i - 5.5) * 14,
  y: -60 - ((i * 37) % 70),
  delay: (i % 4) * 0.04,
}));

/** The hero's one bold move: a birthday cake you can actually blow out. */
export function WishStage() {
  const [lit, setLit] = useState(true);
  const reduce = useReducedMotion();

  return (
    <div className="relative overflow-hidden rounded-[2rem] bg-night px-6 pb-7 pt-8 text-paper shadow-[0_30px_60px_-30px_rgba(0,0,0,0.6)] ring-1 ring-gold/25">
      <motion.div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-[18%] h-64 w-64 -translate-x-1/2 rounded-full bg-marigold blur-3xl"
        animate={{ opacity: lit ? 0.28 : 0.04 }}
        transition={{ duration: 0.6 }}
      />

      <button
        type="button"
        onClick={() => setLit((v) => !v)}
        aria-pressed={!lit}
        aria-label={lit ? "Blow out the candles" : "Light the candles again"}
        className="relative mx-auto block w-full max-w-sm"
      >
        <svg viewBox="0 0 320 300" className="w-full overflow-visible" aria-hidden="true">
          <ellipse cx="160" cy="268" rx="132" ry="14" fill="#1c1c1c" />
          <rect x="60" y="170" width="200" height="96" rx="18" fill="#b51224" />
          <path
            d="M60 188c0-14 10-22 22-22h156c12 0 22 8 22 22 0 12-8 16-14 16s-8-9-16-9-8 12-18 12-10-12-20-12-10 10-20 10-10-10-20-10-10 12-20 12-10-10-18-10-8 9-16 9-14-4-14-16Z"
            fill="#e8d9b5"
          />
          {CANDLES.map((x) => (
            <g key={x} transform={`translate(${x} 0)`}>
              <rect x="-5" y="128" width="10" height="42" rx="3" fill="#f5efe3" />
              <rect x="-5" y="140" width="10" height="5" fill="#e0b25a" opacity="0.8" />
              <rect x="-1" y="120" width="2" height="9" fill="#7a7a7a" />
              <AnimatePresence>
                {lit && (
                  <motion.path
                    d="M0 120C-9 110-7 96 0 82 7 96 9 110 0 120Z"
                    fill="#e0b25a"
                    style={{ transformBox: "fill-box", transformOrigin: "50% 100%" }}
                    initial={{ scaleY: 0, opacity: 0 }}
                    animate={
                      reduce
                        ? { scaleY: 1, opacity: 1 }
                        : { scaleY: [1, 1.14, 0.92, 1.08, 1], opacity: 1 }
                    }
                    transition={{ duration: 1.3, repeat: reduce ? 0 : Infinity, ease: "easeInOut" }}
                    exit={{ opacity: 0, scaleY: 0.2, transition: { duration: 0.25 } }}
                  />
                )}
              </AnimatePresence>
            </g>
          ))}
        </svg>

        {!lit && !reduce && (
          <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-[34%]">
            {SPARKS.map((s, i) => (
              <motion.span
                key={i}
                className="absolute h-1.5 w-1.5 rounded-full bg-marigold"
                initial={{ x: 0, y: 0, opacity: 1 }}
                animate={{ x: s.x, y: s.y, opacity: 0 }}
                transition={{ duration: 1.1, delay: s.delay, ease: "easeOut" }}
              />
            ))}
          </div>
        )}
      </button>

      <div className="relative mt-4 min-h-[4.5rem] text-center" aria-live="polite">
        {lit ? (
          <p className="text-base text-paper/80">Tap the cake to blow out the candles</p>
        ) : (
          <>
            <p className="font-display text-2xl font-semibold tracking-tight">Happy birthday, Maya.</p>
            <p className="mt-1 text-sm text-paper/70">Make a wish. With love, Arjun. Tap to light them again.</p>
          </>
        )}
      </div>
    </div>
  );
}
