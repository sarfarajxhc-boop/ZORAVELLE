import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { getOccasion } from "@/lib/occasions/registry";
import { OccasionArt } from "./art";

const FEATURED = [
  { id: "birthday", tagline: "Make it memorable" },
  { id: "anniversary", tagline: "Seal your love" },
  { id: "eid", tagline: "Share blessings" },
  { id: "diwali", tagline: "Spread joy" },
  { id: "christmas", tagline: "Share the warmth" },
  { id: "new-year", tagline: "Welcome the new" },
];

function FlowerMark() {
  return (
    <svg viewBox="-12 -12 24 24" className="h-5 w-5" aria-hidden="true">
      {[0, 72, 144, 216, 288].map((a) => (
        <ellipse key={a} cx="0" cy="-5.4" rx="3.8" ry="5.8" fill="#b51224" transform={`rotate(${a})`} />
      ))}
      <circle r="2.2" fill="#780d1b" />
    </svg>
  );
}

export function CelebrateOccasions() {
  return (
    <section aria-labelledby="occasions-title" className="bg-white">
      <Container className="pb-16 pt-6 text-center md:pb-24">
        <p className="inline-flex items-center gap-3 text-[0.7rem] font-semibold uppercase tracking-[0.3em] text-ink">
          <span aria-hidden="true" className="h-px w-8 bg-crimson" />
          Choose an
          <FlowerMark />
          occasion
          <span aria-hidden="true" className="h-px w-8 bg-crimson" />
        </p>
        <h2 id="occasions-title" className="mt-3 text-balance text-4xl font-semibold sm:text-6xl">
          Celebrate Every Special Moment
        </h2>

        <ul className="mt-10 grid grid-cols-2 gap-3 text-left sm:grid-cols-3 lg:grid-cols-6 lg:gap-4">
          {FEATURED.map(({ id, tagline }) => {
            const o = getOccasion(id);
            if (!o) return null;
            return (
              <li key={id}>
                <Link
                  href={`/create/${id}`}
                  className="group relative block aspect-[3/4] overflow-hidden rounded-2xl bg-night shadow-[0_18px_40px_-18px_rgba(0,0,0,0.6)] ring-1 ring-black/10 transition duration-300 hover:-translate-y-1.5 hover:shadow-[0_26px_50px_-18px_rgba(181,18,36,0.55)] focus-visible:-translate-y-1.5"
                >
                  <div className="absolute inset-x-0 top-0 bottom-20"><OccasionArt id={id} /></div>
                  <div aria-hidden="true" className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute inset-x-0 bottom-0 p-4">
                    <p className="font-display text-xl font-semibold leading-tight text-white sm:text-2xl">{o.title}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-xs text-white/75">
                      {tagline}
                      <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                    </p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>

        <Link href="/occasions" className="mt-10 inline-flex min-h-12 items-center gap-2 rounded-full border border-ink/25 px-7 font-semibold hover:border-crimson hover:text-crimson">
          See all occasions
          <ArrowRight className="h-4 w-4" aria-hidden="true" />
        </Link>
      </Container>
    </section>
  );
}
