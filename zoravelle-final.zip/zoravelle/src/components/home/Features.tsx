import Link from "next/link";
import { ArrowRight, ImagePlus, Play, Share2, Smartphone, WandSparkles } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { PolaroidCollage } from "./art";

const FEATURES = [
  { icon: WandSparkles, label: "AI Message Writer" },
  { icon: ImagePlus, label: "Upload & Customize Photos" },
  { icon: Play, label: "Stunning Animations" },
  { icon: Smartphone, label: "Mobile Preview" },
  { icon: Share2, label: "Easy Sharing" },
];

export function Features() {
  return (
    <section id="features" aria-labelledby="features-title" className="scroll-mt-20 bg-gradient-to-b from-white to-[#fbf4f4]">
      <Container className="grid items-center gap-10 py-16 md:grid-cols-[1fr_1.1fr] md:gap-14 md:py-24">
        <div className="relative mx-auto w-full max-w-[30rem]">
          <PolaroidCollage className="w-full drop-shadow-[0_24px_40px_rgba(0,0,0,0.25)]" />
          <span className="absolute left-0 top-6 inline-flex items-center gap-3 rounded-2xl bg-ink px-4 py-3 text-white shadow-xl">
            <WandSparkles className="h-5 w-5 text-gold-bright" aria-hidden="true" />
            <span>
              <span className="block text-sm font-semibold">Write with AI</span>
              <span className="block text-[0.7rem] leading-tight text-white/65">Turn your idea into a<br />beautiful message</span>
            </span>
          </span>
          <span className="absolute bottom-6 left-8 inline-flex items-center gap-2 rounded-2xl bg-ink px-4 py-3 text-sm font-semibold text-white shadow-xl">
            <ImagePlus className="h-4 w-4" aria-hidden="true" />
            Upload Photos
          </span>
        </div>

        <div>
          <p className="inline-flex items-center gap-3 text-[0.7rem] font-semibold uppercase tracking-[0.3em] text-crimson">
            <span aria-hidden="true" className="h-px w-8 bg-crimson" />
            Powerful features
          </p>
          <h2 id="features-title" className="mt-3 text-balance text-4xl font-semibold sm:text-6xl">
            Create. Personalise. Share.
          </h2>
          <p className="mt-3 text-lg text-ink-soft">A complete creative experience at your fingertips.</p>

          <ul className="mt-8 grid grid-cols-2 gap-5 sm:grid-cols-5">
            {FEATURES.map(({ icon: Icon, label }) => (
              <li key={label} className="text-center">
                <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-ink text-gold-bright shadow-md">
                  <Icon className="h-6 w-6" aria-hidden="true" />
                </span>
                <span className="mt-3 block text-sm font-medium leading-snug">{label}</span>
              </li>
            ))}
          </ul>

          <p className="mt-8 max-w-[48ch] text-sm text-ink-soft">
            Free to use. The person you send it to needs no account, no app and no payment. They just open the link.
          </p>
          <Link
            href="/create"
            className="mt-6 inline-flex min-h-12 items-center gap-2 rounded-full border border-crimson px-7 font-semibold text-crimson transition-colors hover:bg-crimson hover:text-white"
          >
            Start creating
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </div>
      </Container>
    </section>
  );
}
