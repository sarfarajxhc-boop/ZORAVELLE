import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { BlossomBranch, NightScene, Petals } from "./art";

export function CtaBand() {
  return (
    <section aria-labelledby="cta-title" className="relative isolate overflow-hidden bg-[#0a0a0a] text-white">
      <NightScene className="pointer-events-none absolute bottom-0 left-0 z-0 h-full w-[28rem] max-w-[60%] opacity-90" />
      <BlossomBranch className="pointer-events-none absolute -right-10 -top-6 z-0 hidden w-[26rem] opacity-80 md:block" />
      <Petals count={8} core={4} travel={360} className="z-10" />
      <Container className="relative z-10 py-14 text-center md:py-16">
        <p className="inline-flex items-center gap-3 font-display text-lg font-semibold tracking-[0.24em] text-white/90">
          <span aria-hidden="true" className="h-px w-8 bg-white/30" />
          ZORAVELLE
          <span aria-hidden="true" className="h-px w-8 bg-white/30" />
        </p>
        <h2 id="cta-title" className="mt-3 text-balance text-3xl font-medium sm:text-5xl">
          Ready to create something special?
        </h2>
        <p className="mt-2 text-white/75">Turn your thoughts into a beautiful greeting today.</p>
        <Link
          href="/create"
          className="mt-6 inline-flex min-h-14 items-center gap-3 rounded-full bg-crimson px-8 font-semibold text-white shadow-[0_10px_30px_-8px_rgba(181,18,36,0.8)] transition-colors hover:bg-crimson-dark"
        >
          Create Your Greeting
          <ArrowRight className="h-5 w-5" aria-hidden="true" />
        </Link>
        <p aria-hidden="true" className="mt-8 font-script text-3xl text-white/80 md:absolute md:bottom-6 md:right-8 md:mt-0 md:-rotate-6 md:text-4xl">
          Make Every Moment Special <span className="text-crimson">♡</span>
        </p>
      </Container>
    </section>
  );
}
