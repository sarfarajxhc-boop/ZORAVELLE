/**
 * Illustrations for the homepage, drawn as SVG so they stay sharp, tiny and free to use.
 * Everything here is decorative (aria-hidden); nothing is random, so server and browser render the same markup.
 */
import type { CSSProperties } from "react";

const PINKS = ["#f6c3cf", "#ee95aa", "#d9607f"] as const;

/** A five-petal blossom. */
function Flower({ x, y, s = 1, rot = 0, tone = 0 }: { x: number; y: number; s?: number; rot?: number; tone?: 0 | 1 | 2 }) {
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
      {[0, 72, 144, 216, 288].map((a) => (
        <ellipse key={a} cx="0" cy="-9" rx="6.5" ry="10" fill={PINKS[tone]} transform={`rotate(${a})`} />
      ))}
      <circle r="3.2" fill="#8c1230" />
      <circle r="1.4" fill="#e0b25a" />
    </g>
  );
}

const BLOSSOMS: Array<[number, number, number, number, 0 | 1 | 2]> = [
  [470, 46, 1.5, 10, 0], [420, 96, 1.2, 40, 1], [372, 62, 1.7, 80, 0], [330, 118, 1.3, 20, 2],
  [284, 92, 1.1, 60, 0], [236, 140, 1.5, 100, 1], [190, 118, 1.0, 30, 0], [148, 168, 1.3, 70, 1],
  [100, 150, 0.9, 10, 2], [440, 168, 1.0, 50, 0], [392, 192, 1.4, 90, 1], [506, 112, 1.1, 20, 0],
  [346, 30, 1.0, 40, 1], [268, 190, 0.9, 80, 0],
];

export function BlossomBranch({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 520 240" className={className} aria-hidden="true" focusable="false">
      <g fill="none" stroke="#2a130f" strokeLinecap="round">
        <path d="M530 24 C 470 40, 420 40, 370 78 S 270 120, 215 132 S 130 150, 90 165" strokeWidth="7" />
        <path d="M440 50 C 440 90, 455 120, 440 170" strokeWidth="4" />
        <path d="M372 78 C 380 120, 400 150, 392 195" strokeWidth="4" />
        <path d="M300 104 C 290 80, 300 50, 346 30" strokeWidth="3.5" />
        <path d="M236 134 C 250 160, 262 178, 268 192" strokeWidth="3" />
      </g>
      {BLOSSOMS.map(([x, y, s, r, t], i) => (
        <Flower key={i} x={x} y={y} s={s} rot={r} tone={t} />
      ))}
    </svg>
  );
}

/** Deterministic pseudo-random in [0,1) so markup is identical on server and client. */
const rnd = (i: number, salt: number) => {
  const v = Math.sin(i * 12.9898 + salt * 78.233) * 43758.5453;
  return v - Math.floor(v);
};

const PETAL_COLORS = ["#f0a3b5", "#d9607f", "#b51224", "#f6c3cf", "#e0b25a"];

/** Slowly falling petals. The first `core` are always shown; the rest only from the sm breakpoint up. */
export function Petals({ count = 16, core = 8, travel = 720, className = "" }: { count?: number; core?: number; travel?: number; className?: string }) {
  return (
    <div aria-hidden="true" className={`pointer-events-none absolute inset-0 overflow-hidden ${className}`}>
      {Array.from({ length: count }, (_, i) => {
        const size = 9 + rnd(i, 1) * 12;
        const style = {
          "--x": `${(rnd(i, 2) * 100).toFixed(1)}%`,
          "--s": `${size.toFixed(1)}px`,
          "--c": PETAL_COLORS[i % PETAL_COLORS.length],
          "--d": `${(11 + rnd(i, 3) * 9).toFixed(1)}s`,
          "--delay": `${(-rnd(i, 4) * 18).toFixed(1)}s`,
          "--drift": `${Math.round((rnd(i, 5) - 0.3) * 160)}px`,
          "--spin": `${Math.round(240 + rnd(i, 6) * 360)}deg`,
          "--travel": `${travel}px`,
        } as CSSProperties;
        return <span key={i} className={`petal ${i >= core ? "hidden sm:block" : ""}`} style={style} />;
      })}
    </div>
  );
}

function PagodaShapes({ lit = true }: { lit?: boolean }) {
  const tiers = [0, 1, 2, 3];
  return (
    <g fill="#1a090c">
      <rect x="86" y="10" width="28" height="4" />
      <rect x="98.5" y="0" width="3" height="14" />
      {tiers.map((t) => {
        const w = 44 + t * 26;
        const y = 40 + t * 62;
        return (
          <g key={t}>
            <path d={`M${100 - w} ${y + 14} Q ${100 - w * 0.55} ${y + 8} ${100 - w * 0.3} ${y - 14} L ${100 + w * 0.3} ${y - 14} Q ${100 + w * 0.55} ${y + 8} ${100 + w} ${y + 14} Z`} />
            <rect x={100 - w * 0.62} y={y + 14} width={w * 1.24} height="34" />
            {lit && (
              <g fill="#c8283b" opacity="0.85">
                <rect x={100 - w * 0.4} y={y + 22} width="8" height="14" />
                <rect x="96" y={y + 22} width="8" height="14" />
                <rect x={100 + w * 0.4 - 8} y={y + 22} width="8" height="14" />
              </g>
            )}
          </g>
        );
      })}
      <rect x="40" y="288" width="120" height="12" />
    </g>
  );
}

export function Pagoda({ className, lit = true }: { className?: string; lit?: boolean }) {
  return (
    <svg viewBox="0 0 200 300" className={className} aria-hidden="true" focusable="false">
      <PagodaShapes lit={lit} />
    </svg>
  );
}

const SPARKS: Array<[number, number, number]> = [
  [96, 150, 3], [150, 60, 2.4], [470, 90, 2.8], [520, 200, 2.2], [60, 300, 2.6], [500, 330, 3], [330, 20, 2], [250, 40, 2.4],
];

/** The hero picture: an opening gift box with photos and a note rising out of it. */
export function GiftBoxArt({ className }: { className?: string }) {
  const script = { fontFamily: "var(--font-dancing), cursive" } as CSSProperties;
  return (
    <svg viewBox="0 0 560 470" className={className} aria-hidden="true" focusable="false">
      <defs>
        <radialGradient id="gb-glow" cx="50%" cy="58%" r="55%">
          <stop offset="0" stopColor="#ffd98a" stopOpacity="0.95" />
          <stop offset="0.35" stopColor="#f08a3c" stopOpacity="0.4" />
          <stop offset="1" stopColor="#b51224" stopOpacity="0" />
        </radialGradient>
        <linearGradient id="gb-ray" x1="0" y1="1" x2="0" y2="0">
          <stop offset="0" stopColor="#ffe3a8" stopOpacity="0.7" />
          <stop offset="1" stopColor="#ffe3a8" stopOpacity="0" />
        </linearGradient>
        <linearGradient id="gb-box" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#2e0d14" />
          <stop offset="1" stopColor="#0c0405" />
        </linearGradient>
        <linearGradient id="gb-ribbon" x1="0" y1="0" x2="1" y2="0">
          <stop offset="0" stopColor="#8f0f20" />
          <stop offset="0.5" stopColor="#e0263a" />
          <stop offset="1" stopColor="#8f0f20" />
        </linearGradient>
        <linearGradient id="gb-sunset" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f2a76a" />
          <stop offset="0.6" stopColor="#c8523a" />
          <stop offset="1" stopColor="#3a1417" />
        </linearGradient>
        <linearGradient id="gb-night" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0f1a24" />
          <stop offset="1" stopColor="#2a2430" />
        </linearGradient>
        <linearGradient id="gb-roses" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#7a0c1c" />
          <stop offset="1" stopColor="#2a0409" />
        </linearGradient>
      </defs>

      <ellipse cx="280" cy="250" rx="270" ry="210" fill="url(#gb-glow)" className="glow-breathe" />
      <polygon points="215,290 345,290 500,0 60,0" fill="url(#gb-ray)" opacity="0.5" />

      {/* photo: sunset couple */}
      <g transform="rotate(-13 150 190)">
        <rect x="86" y="62" width="132" height="164" rx="3" fill="#f7f2ea" />
        <rect x="95" y="71" width="114" height="120" fill="url(#gb-sunset)" />
        <circle cx="152" cy="118" r="16" fill="#ffd28a" opacity="0.9" />
        <circle cx="140" cy="140" r="7" fill="#1a0c0e" />
        <circle cx="164" cy="141" r="7" fill="#1a0c0e" />
        <path d="M128 191 q0 -38 12 -43 q12 -3 12 43 Z" fill="#1a0c0e" />
        <path d="M152 191 q0 -38 12 -42 q12 -2 12 42 Z" fill="#1a0c0e" />
      </g>
      {/* photo: roses */}
      <g transform="rotate(6 280 150)">
        <rect x="214" y="30" width="132" height="164" rx="3" fill="#f7f2ea" />
        <rect x="223" y="39" width="114" height="120" fill="url(#gb-roses)" />
        {[[250, 85, 16], [284, 74, 18], [316, 92, 15], [270, 112, 17], [304, 124, 14]].map(([cx = 0, cy = 0, r = 0], i) => (
          <g key={i}>
            <circle cx={cx} cy={cy} r={r} fill="#b51224" />
            <circle cx={cx} cy={cy} r={r * 0.62} fill="#d4283b" />
            <circle cx={cx} cy={cy} r={r * 0.28} fill="#8c0f1f" />
          </g>
        ))}
      </g>
      {/* photo: moon */}
      <g transform="rotate(14 430 170)">
        <rect x="366" y="52" width="132" height="164" rx="3" fill="#f7f2ea" />
        <rect x="375" y="61" width="114" height="120" fill="url(#gb-night)" />
        <circle cx="440" cy="102" r="20" fill="#f3e7c9" />
        <circle cx="449" cy="96" r="18" fill="#17212b" />
        <circle cx="396" cy="84" r="1.6" fill="#f3e7c9" />
        <circle cx="414" cy="150" r="1.4" fill="#f3e7c9" />
        <path d="M375 181 L405 140 L430 165 L455 130 L489 181 Z" fill="#0b1118" />
      </g>

      {/* note */}
      <g transform="rotate(-3 290 190)">
        <rect x="204" y="118" width="172" height="132" rx="3" fill="#f4ebdc" />
        <text x="290" y="170" textAnchor="middle" fontSize="27" fill="#7f0d1c" style={script}>Because</text>
        <text x="290" y="204" textAnchor="middle" fontSize="27" fill="#7f0d1c" style={script}>you matter…</text>
        <path d="M290 238 c -14 -10 -20 -18 -12 -24 c 6 -4 11 0 12 4 c 1 -4 6 -8 12 -4 c 8 6 2 14 -12 24 Z" fill="none" stroke="#b51224" strokeWidth="1.6" />
      </g>

      {/* ribbon trailing off the left */}
      <path d="M130 372 C 60 380, 30 410, 60 440 S 120 440, 96 410" fill="none" stroke="url(#gb-ribbon)" strokeWidth="16" strokeLinecap="round" />

      {/* box */}
      <polygon points="108,282 282,282 252,238 70,224" fill="#1c070c" />
      <polygon points="452,282 278,282 308,238 490,224" fill="#1c070c" />
      <rect x="108" y="282" width="344" height="150" rx="5" fill="url(#gb-box)" />
      <ellipse cx="280" cy="284" rx="172" ry="18" fill="#ffd98a" opacity="0.85" />
      <rect x="252" y="282" width="56" height="150" fill="url(#gb-ribbon)" />
      <polygon points="252,282 280,282 266,238 246,240" fill="url(#gb-ribbon)" />
      <polygon points="308,282 280,282 294,238 314,240" fill="url(#gb-ribbon)" />
      <ellipse cx="258" cy="276" rx="26" ry="13" fill="#c91f33" transform="rotate(-14 258 276)" />
      <ellipse cx="302" cy="276" rx="26" ry="13" fill="#c91f33" transform="rotate(14 302 276)" />
      <circle cx="280" cy="278" r="9" fill="#8f0f20" />
      <rect x="108" y="282" width="344" height="3" fill="#e0b25a" opacity="0.5" />

      {SPARKS.map(([x = 0, y = 0, r = 0], i) => (
        <circle key={i} cx={x} cy={y} r={r} fill="#ffd98a" opacity="0.85" />
      ))}
    </svg>
  );
}

/** Small scenes for the occasion cards. Unknown occasions get a simple sparkle. */
export function OccasionArt({ id }: { id: string }) {
  const gold = "#e0b25a";
  const flame = (x: number, y: number, s = 1) => (
    <path d={`M${x} ${y} c ${-4 * s} ${-7 * s} ${0} ${-10 * s} ${0} ${-16 * s} c ${5 * s} ${5 * s} ${6 * s} ${11 * s} ${0} ${16 * s} Z`} fill="#ffcf6b" />
  );
  let art: React.ReactNode;
  switch (id) {
    case "birthday":
      art = (
        <>
          <ellipse cx="120" cy="214" rx="82" ry="10" fill="#000" opacity="0.4" />
          <rect x="62" y="168" width="116" height="42" rx="6" fill="#b51224" />
          <rect x="76" y="132" width="88" height="38" rx="6" fill="#f3ead9" />
          <path d="M76 140 q11 12 22 0 q11 12 22 0 q11 12 22 0 q11 12 22 0 v-8 h-88 Z" fill="#fff8ea" />
          {[96, 120, 144].map((x) => (
            <g key={x}>
              <rect x={x - 3} y="106" width="6" height="28" fill="#f7efe0" />
              {flame(x, 106, 1.3)}
              <circle cx={x} cy="92" r="14" fill="#ffcf6b" opacity="0.18" />
            </g>
          ))}
          <rect x="22" y="188" width="32" height="26" fill="#e0b25a" /><rect x="35" y="188" width="6" height="26" fill="#b51224" />
          <rect x="188" y="178" width="30" height="36" fill="#b51224" /><rect x="200" y="178" width="6" height="36" fill="#e0b25a" />
        </>
      );
      break;
    case "anniversary":
      art = (
        <>
          {[[84, 120, 30], [132, 104, 34], [168, 142, 28], [112, 160, 32]].map(([x = 0, y = 0, r = 0], i) => (
            <g key={i}>
              <circle cx={x} cy={y} r={r} fill="#a30f22" />
              <circle cx={x} cy={y} r={r * 0.72} fill="#c9192f" />
              <circle cx={x} cy={y} r={r * 0.46} fill="#a30f22" />
              <circle cx={x} cy={y} r={r * 0.2} fill="#7a0b19" />
            </g>
          ))}
          <path d="M60 200 q60 30 130 0 v30 h-130 Z" fill="#3a0a12" opacity="0.8" />
          <circle cx="104" cy="206" r="15" fill="none" stroke={gold} strokeWidth="4" />
          <circle cx="128" cy="206" r="15" fill="none" stroke="#f2d48a" strokeWidth="4" />
        </>
      );
      break;
    case "eid":
      art = (
        <>
          <circle cx="150" cy="86" r="30" fill="#f3e3b8" />
          <circle cx="163" cy="78" r="28" fill="#150c10" />
          <path d="M70 70 L80 70 L80 62 L100 62 L100 70 L110 70 L102 90 L78 90 Z" fill="#3a2410" />
          <rect x="76" y="90" width="30" height="82" rx="3" fill="#ffcf6b" opacity="0.95" />
          <rect x="76" y="90" width="30" height="82" rx="3" fill="none" stroke="#7a4a14" strokeWidth="4" />
          <path d="M91 90 v82 M76 131 h30" stroke="#7a4a14" strokeWidth="2.5" />
          <path d="M72 172 h38 l-6 14 h-26 Z" fill="#3a2410" />
          <circle cx="91" cy="130" r="48" fill="#ffcf6b" opacity="0.16" className="glow-breathe" />
          <path d="M40 232 q50 -34 100 0 q40 -22 80 0 v10 h-180 Z" fill="#0a0507" />
          {[[190, 50], [40, 60], [206, 120], [30, 130]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="1.8" fill="#f3e3b8" />)}
        </>
      );
      break;
    case "diwali":
      art = (
        <>
          {[[62, 190, 0.9], [120, 170, 1.2], [180, 192, 0.9]].map(([x = 0, y = 0, s = 1], i) => (
            <g key={i}>
              <circle cx={x} cy={y - 24 * s} r={34 * s} fill="#ffb347" opacity="0.22" className="glow-breathe" />
              <path d={`M${x - 30 * s} ${y} q${30 * s} ${26 * s} ${60 * s} 0 q${-6 * s} ${-12 * s} ${-30 * s} ${-12 * s} q${-24 * s} 0 ${-30 * s} ${12 * s} Z`} fill="#b4531a" />
              <path d={`M${x} ${y - 10 * s} c ${-8 * s} ${-12 * s} 0 ${-18 * s} 0 ${-30 * s} c ${10 * s} ${10 * s} ${12 * s} ${20 * s} 0 ${30 * s} Z`} fill="#ffcf6b" />
            </g>
          ))}
          {[[40, 60], [210, 90], [90, 40], [160, 56]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="2.2" fill="#ffcf6b" opacity="0.8" />)}
        </>
      );
      break;
    case "christmas":
      art = (
        <>
          <polygon points="120,40 82,104 158,104" fill="#12452c" />
          <polygon points="120,76 70,150 170,150" fill="#16573a" />
          <polygon points="120,112 58,200 182,200" fill="#1b6b46" />
          <rect x="112" y="200" width="16" height="22" fill="#4a2a12" />
          <polygon points="120,22 125,36 140,37 128,46 132,60 120,52 108,60 112,46 100,37 115,36" fill="#ffcf6b" />
          {[[96, 140], [140, 128], [108, 178], [150, 176]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="5" fill={i % 2 ? "#e0b25a" : "#b51224"} />)}
          <rect x="30" y="196" width="34" height="28" fill="#b51224" /><rect x="44" y="196" width="6" height="28" fill="#f3ead9" />
          <rect x="178" y="202" width="32" height="22" fill="#e0b25a" />
          {[[40, 50], [200, 60], [60, 100], [190, 130], [30, 150], [215, 180]].map(([x, y], i) => <circle key={i} cx={x} cy={y} r="2" fill="#fff" opacity="0.85" />)}
        </>
      );
      break;
    case "new-year":
      art = (
        <>
          {[[90, 84, 40, "#ffcf6b"], [160, 60, 30, "#e24455"], [130, 128, 26, "#f3ead9"]].map(([cx, cy, r, c], i) => (
            <g key={i} stroke={c as string} strokeWidth="2.4" strokeLinecap="round">
              {Array.from({ length: 12 }, (_, k) => {
                const a = (k * Math.PI) / 6;
                return <line key={k} x1={(cx as number) + Math.cos(a) * 8} y1={(cy as number) + Math.sin(a) * 8} x2={(cx as number) + Math.cos(a) * (r as number)} y2={(cy as number) + Math.sin(a) * (r as number)} />;
              })}
              <circle cx={cx as number} cy={cy as number} r="3" fill={c as string} stroke="none" />
            </g>
          ))}
          <path d="M0 232 V196 h22 V176 h16 V204 h20 V156 h8 V204 h24 V186 h18 V212 h22 V168 h14 V212 h26 V190 h20 V232 Z" fill="#0a0507" />
          <path d="M148 196 V150 l5 -14 l5 14 V196 Z" fill="#150b0e" />
        </>
      );
      break;
    default:
      art = <path d="M120 70 l12 38 l38 12 l-38 12 l-12 38 l-12 -38 l-38 -12 l38 -12 Z" fill={gold} opacity="0.9" />;
  }
  return (
    <svg viewBox="0 0 240 260" className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false">
      <defs>
        <radialGradient id={`oa-${id}`} cx="50%" cy="42%" r="70%">
          <stop offset="0" stopColor="#3b1219" />
          <stop offset="0.6" stopColor="#1a0a0e" />
          <stop offset="1" stopColor="#0a0405" />
        </radialGradient>
      </defs>
      <rect width="240" height="260" fill={`url(#oa-${id})`} />
      {art}
    </svg>
  );
}

/** Two polaroids and a note, for the features section. */
export function PolaroidCollage({ className }: { className?: string }) {
  const script = { fontFamily: "var(--font-dancing), cursive" } as CSSProperties;
  return (
    <svg viewBox="0 0 520 440" className={className} aria-hidden="true" focusable="false">
      <defs>
        <linearGradient id="pc-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#f4b27a" />
          <stop offset="0.55" stopColor="#d4633f" />
          <stop offset="1" stopColor="#4a1a1c" />
        </linearGradient>
      </defs>
      <g transform="rotate(-7 190 220)">
        <rect x="40" y="50" width="290" height="330" rx="6" fill="#f8f3ec" />
        <rect x="56" y="66" width="258" height="250" fill="url(#pc-sky)" />
        <circle cx="200" cy="170" r="34" fill="#ffd9a0" opacity="0.9" />
        <path d="M56 316 L56 270 Q 120 240 180 262 Q 240 240 314 268 L314 316 Z" fill="#2a0f12" />
        <circle cx="158" cy="232" r="14" fill="#14090b" />
        <circle cx="198" cy="236" r="14" fill="#14090b" />
        <path d="M140 296 q0 -52 18 -58 q18 -2 18 58 Z" fill="#14090b" />
        <path d="M180 296 q0 -52 18 -56 q18 -2 18 56 Z" fill="#14090b" />
        <text x="185" y="352" textAnchor="middle" fontSize="22" fill="#7f0d1c" style={script}>our little forever</text>
      </g>
      <g transform="rotate(8 400 230)">
        <rect x="290" y="80" width="190" height="290" rx="6" fill="#161012" stroke="#e0b25a" strokeOpacity="0.5" />
        <text x="385" y="200" textAnchor="middle" fontSize="38" fill="#f6efe4" style={script}>Always</text>
        <text x="385" y="248" textAnchor="middle" fontSize="38" fill="#f6efe4" style={script}>together</text>
        <path d="M385 322 c -22 -16 -32 -30 -20 -40 c 10 -6 18 0 20 7 c 2 -7 10 -13 20 -7 c 12 10 2 24 -20 40 Z" fill="none" stroke="#f6efe4" strokeWidth="2" />
      </g>
      {[[470, 60, 4], [60, 30, 3], [500, 380, 3], [30, 400, 4]].map(([x = 0, y = 0, r = 0], i) => <circle key={i} cx={x} cy={y} r={r} fill="#e0b25a" opacity="0.8" />)}
    </svg>
  );
}

/** Moon, hills and a pagoda for the call-to-action band. */
export function NightScene({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 420 200" className={className} preserveAspectRatio="xMinYMax slice" aria-hidden="true" focusable="false">
      <defs>
        <radialGradient id="ns-moon" cx="50%" cy="50%" r="50%">
          <stop offset="0" stopColor="#fff1d0" />
          <stop offset="0.7" stopColor="#f3cf9a" />
          <stop offset="1" stopColor="#f3cf9a" stopOpacity="0" />
        </radialGradient>
      </defs>
      <circle cx="110" cy="70" r="52" fill="url(#ns-moon)" opacity="0.5" />
      <circle cx="110" cy="70" r="32" fill="#f6dfb4" />
      <path d="M0 200 V150 Q60 110 120 140 T240 130 T420 150 V200 Z" fill="#150a0d" />
      <path d="M0 200 V172 Q80 140 170 170 T330 164 T420 176 V200 Z" fill="#0b0507" />
      <g transform="translate(300 34) scale(0.46)">
        <PagodaShapes />
      </g>
    </svg>
  );
}
