"use client";

import { useState } from "react";

const REASONS: Array<[string, string]> = [
  ["harassment", "Harassment or bullying"],
  ["hate", "Hateful content"],
  ["sexual", "Sexual content"],
  ["scam", "Scam or spam"],
  ["privacy", "Shares private information"],
  ["other", "Something else"],
];

/** Colours are fixed (not the greeting's palette) so the form stays readable on any theme. */
export function ReportButton({ slug }: { slug: string }) {
  const [reason, setReason] = useState("harassment");
  const [details, setDetails] = useState("");
  const [state, setState] = useState<"idle" | "sending" | "sent" | "error">("idle");
  const [message, setMessage] = useState("");

  async function send(e: React.FormEvent) {
    e.preventDefault();
    setState("sending");
    try {
      const res = await fetch("/api/report", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ slug, reason, details: details.trim() || undefined }),
      });
      const body = (await res.json().catch(() => ({}))) as { error?: string };
      if (res.ok) setState("sent");
      else { setMessage(body.error ?? "Couldn't send the report."); setState("error"); }
    } catch {
      setMessage("Couldn't send the report. Check your connection.");
      setState("error");
    }
  }

  return (
    <details className="mx-auto mt-2 max-w-sm text-center text-sm">
      <summary className="min-h-11 cursor-pointer py-2 underline underline-offset-4 opacity-80">Report this greeting</summary>
      {state === "sent" ? (
        <p role="status" className="rounded-2xl bg-white p-4 font-medium text-black">Thanks. We&apos;ll review it.</p>
      ) : (
        <form onSubmit={send} className="space-y-3 rounded-2xl bg-white p-4 text-left text-black">
          <div>
            <label htmlFor="rp-reason" className="block font-semibold">What&apos;s wrong?</label>
            <select id="rp-reason" value={reason} onChange={(e) => setReason(e.target.value)} className="mt-1 w-full rounded-xl border border-black/25 bg-white px-3 py-2.5 text-base">
              {REASONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="rp-details" className="block font-semibold">Details (optional)</label>
            <textarea id="rp-details" value={details} maxLength={500} onChange={(e) => setDetails(e.target.value)} className="mt-1 min-h-20 w-full rounded-xl border border-black/25 bg-white px-3 py-2 text-base" />
          </div>
          {state === "error" && <p role="alert" className="font-medium text-[#B51224]">{message}</p>}
          <button disabled={state === "sending"} className="min-h-11 rounded-full bg-black px-6 font-semibold text-white disabled:opacity-60">
            {state === "sending" ? "Sending…" : "Send report"}
          </button>
        </form>
      )}
    </details>
  );
}
