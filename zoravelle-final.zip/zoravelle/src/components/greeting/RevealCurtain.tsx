"use client";

import { useEffect, useRef, useState } from "react";

type Props = {
  /** Colours taken from the greeting itself, so each occasion opens in its own mood. */
  accent: string;
  accentSoft: string;
  /** "fixed" covers the page; "contain" covers the nearest positioned box (the preview frame). */
  mode?: "fixed" | "contain";
  onDone?: () => void;
};

/**
 * Cinematic reveal: a gold light blooms, then two velvet curtains part to show the greeting.
 * Pure CSS; with reduced motion it is a short fade. It ignores pointer events so it never traps taps.
 */
export function RevealCurtain({ accent, accentSoft, mode = "fixed", onDone }: Props) {
  const [gone, setGone] = useState(false);
  // Kept in a ref so a parent that re-renders can never restart the timer.
  const done = useRef(onDone);
  done.current = onDone;
  useEffect(() => {
    const t = window.setTimeout(() => { setGone(true); done.current?.(); }, 3600);
    return () => window.clearTimeout(t);
  }, []);
  if (gone) return null;

  const velvet = `linear-gradient(180deg, #2a0a12, #5a0d1c 55%, #1a0509)`;
  return (
    <div
      aria-hidden="true"
      className={`zv-reveal pointer-events-none ${mode === "fixed" ? "fixed" : "absolute"} inset-0 z-50 overflow-hidden`}
    >
      <div className="zv-curtain-l absolute inset-y-0 left-0 w-1/2 border-r border-[#c9a860]/60" style={{ backgroundImage: velvet }} />
      <div className="zv-curtain-r absolute inset-y-0 right-0 w-1/2 border-l border-[#c9a860]/60" style={{ backgroundImage: velvet }} />
      <div
        className="zv-burst absolute left-1/2 top-1/2 h-[60vmin] w-[60vmin] -translate-x-1/2 -translate-y-1/2 rounded-full"
        style={{ background: `radial-gradient(closest-side, ${accentSoft}, ${accent}66 55%, transparent)` }}
      />
    </div>
  );
}
