"use client";

import { useCallback, useEffect, useRef, useState, type MouseEvent as ReactMouseEvent } from "react";
import { Check, Share, SquarePlus, X, Smartphone } from "lucide-react";

/** Chrome's install prompt event. Not in the standard DOM types. */
type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

type Platform = "ios" | "android" | "desktop";
type Note = { tone: "ok" | "info"; text: string } | null;

function detectPlatform(): { platform: Platform; inApp: boolean; safari: boolean } {
  const ua = navigator.userAgent;
  const iPadOS = /Macintosh/.test(ua) && navigator.maxTouchPoints > 1;
  const ios = /iPhone|iPad|iPod/.test(ua) || iPadOS;
  const android = /Android/.test(ua);
  // In-app browsers (Instagram, Facebook, WhatsApp, Line…) can't add to the home screen.
  const inApp = /FBAN|FBAV|Instagram|Line\/|WhatsApp|Snapchat|MicroMessenger|TikTok/i.test(ua);
  const safari = ios && /Safari/.test(ua) && !/CriOS|FxiOS|EdgiOS|OPiOS/.test(ua);
  return { platform: ios ? "ios" : android ? "android" : "desktop", inApp, safari };
}

function isStandalone(): boolean {
  return (
    window.matchMedia?.("(display-mode: standalone)").matches ||
    (navigator as Navigator & { standalone?: boolean }).standalone === true
  );
}

/**
 * "Add the Timer to My Screen". This adds a SHORTCUT (a web app icon) that opens this greeting's countdown.
 * It is not a native widget and it says so. Where the browser offers a real install prompt (Chrome and
 * Edge on Android) the button opens it; everywhere else it shows the exact steps for that browser.
 */
export function InstallTimerButton({ slug }: { slug: string }) {
  const [ready, setReady] = useState(false);
  const [info, setInfo] = useState<ReturnType<typeof detectPlatform> | null>(null);
  const [standalone, setStandalone] = useState(false);
  const [added, setAdded] = useState(false);
  const [note, setNote] = useState<Note>(null);
  const [sheet, setSheet] = useState(false);
  const deferred = useRef<InstallPromptEvent | null>(null);
  const [canPrompt, setCanPrompt] = useState(false);
  const closeBtn = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    setInfo(detectPlatform());
    setStandalone(isStandalone());
    setReady(true);

    // The service worker lets the countdown open offline and makes the site installable.
    if ("serviceWorker" in navigator) {
      navigator.serviceWorker.register("/sw.js").catch(() => undefined);
    }

    const onPrompt = (e: Event) => {
      e.preventDefault(); // keep it until the person taps the button
      deferred.current = e as InstallPromptEvent;
      setCanPrompt(true);
    };
    const onInstalled = () => {
      deferred.current = null;
      setCanPrompt(false);
      setAdded(true);
      setNote({ tone: "ok", text: "Added. Look for the ZORAVELLE icon on your home screen." });
    };
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  useEffect(() => {
    if (!sheet) return;
    closeBtn.current?.focus();
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setSheet(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [sheet]);

  const onClick = useCallback(async () => {
    setNote(null);
    const ev = deferred.current;
    if (!ev) return setSheet(true);
    try {
      await ev.prompt();
      const { outcome } = await ev.userChoice;
      deferred.current = null; // an install prompt can be used once
      setCanPrompt(false);
      if (outcome === "accepted") {
        setAdded(true);
        setNote({ tone: "ok", text: "Added. Look for the ZORAVELLE icon on your home screen." });
      } else {
        setNote({ tone: "info", text: "No problem. You can add it any time with the steps below." });
        setSheet(true);
      }
    } catch {
      setSheet(true);
    }
  }, []);

  // Already running as the home-screen app, or nothing to render before we know the browser.
  if (!ready) return <div className="h-12" aria-hidden="true" />;
  if (standalone) {
    return (
      <p className="inline-flex items-center gap-2 text-sm text-[#e6cf94]">
        <Check className="h-4 w-4" aria-hidden="true" />
        Opened from your home screen. This timer will open the greeting by itself.
      </p>
    );
  }

  const platform = info?.platform ?? "desktop";

  return (
    <div className="flex flex-col items-center">
      <button
        type="button"
        onClick={() => void onClick()}
        className="inline-flex min-h-12 items-center gap-2 rounded-full border border-[#c9a860] bg-gradient-to-b from-[#c9a860]/20 to-[#c9a860]/5 px-6 text-sm font-semibold text-[#f3e3b3] transition-colors hover:bg-[#c9a860]/25"
      >
        <Smartphone className="h-4 w-4" aria-hidden="true" />
        {added ? "Timer added to your screen" : "Add the Timer to My Screen"}
      </button>

      {note && (
        <p role="status" className={`mt-3 max-w-[34ch] text-sm ${note.tone === "ok" ? "text-[#e6cf94]" : "text-[#f6efe2]/75"}`}>
          {note.text}
        </p>
      )}
      <p className="mt-2 max-w-[38ch] text-xs text-[#f6efe2]/50">
        Adds a shortcut icon that opens this countdown. It is a shortcut, not a phone widget.
      </p>

      {sheet && (
        <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 p-0 sm:items-center sm:p-6" onClick={() => setSheet(false)}>
          <div
            role="dialog"
            aria-modal="true"
            aria-labelledby={`zv-add-${slug}`}
            onClick={(e: ReactMouseEvent) => e.stopPropagation()}
            className="max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-[#c9a860]/40 bg-[#100709] p-6 text-left text-[#f6efe2] sm:rounded-3xl"
          >
            <div className="flex items-start justify-between gap-4">
              <h2 id={`zv-add-${slug}`} className="font-display text-2xl font-semibold text-[#f3e3b3]">
                Add the timer to your screen
              </h2>
              <button ref={closeBtn} type="button" onClick={() => setSheet(false)} aria-label="Close" className="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-[#c9a860]/40">
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
            </div>

            {info?.inApp && (
              <p className="mt-4 rounded-2xl bg-[#5a0d1c]/50 p-3 text-sm">
                You&apos;re inside another app&apos;s browser, which can&apos;t add shortcuts. Open this link in {platform === "ios" ? "Safari" : "Chrome"} first (use the ⋯ or share menu, then &quot;Open in browser&quot;).
              </p>
            )}

            {platform === "ios" ? (
              <>
                {!info?.safari && !info?.inApp && (
                  <p className="mt-4 rounded-2xl bg-[#5a0d1c]/50 p-3 text-sm">For the most reliable result on iPhone, do this in Safari.</p>
                )}
                <ol className="mt-5 space-y-4 text-sm">
                  <li className="flex gap-3"><Share className="mt-0.5 h-5 w-5 shrink-0 text-[#e6cf94]" aria-hidden="true" /><span>Tap the <b>Share</b> button (the square with an arrow) at the bottom or top of Safari.</span></li>
                  <li className="flex gap-3"><SquarePlus className="mt-0.5 h-5 w-5 shrink-0 text-[#e6cf94]" aria-hidden="true" /><span>Scroll down and tap <b>Add to Home Screen</b>.</span></li>
                  <li className="flex gap-3"><Check className="mt-0.5 h-5 w-5 shrink-0 text-[#e6cf94]" aria-hidden="true" /><span>Tap <b>Add</b>. Open the new icon any time to see the countdown.</span></li>
                </ol>
              </>
            ) : platform === "android" ? (
              <ol className="mt-5 list-decimal space-y-3 pl-5 text-sm">
                <li>Tap the <b>⋮</b> menu in your browser (top right).</li>
                <li>Tap <b>Add to Home screen</b> or <b>Install app</b>.</li>
                <li>Confirm. The icon opens this countdown.</li>
                <li className="text-[#f6efe2]/70">Firefox: <b>⋮ → Install</b>. Samsung Internet: <b>≡ → Add page to → Home screen</b>.</li>
              </ol>
            ) : (
              <ol className="mt-5 list-decimal space-y-3 pl-5 text-sm">
                <li>In Chrome or Edge, click the <b>install</b> icon at the right of the address bar (or <b>⋮ → Cast, save and share → Install page as app</b>).</li>
                <li>On Safari for Mac: <b>File → Add to Dock</b>.</li>
                <li className="text-[#f6efe2]/70">Firefox on desktop can&apos;t install web apps. Bookmark this page instead (Ctrl/⌘ + D).</li>
              </ol>
            )}

            <p className="mt-6 text-xs text-[#f6efe2]/55">
              This saves a shortcut to this exact greeting. It shows the countdown, never the greeting itself, until the unlock time. If your browser can&apos;t add it, bookmarking this page works the same way.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
