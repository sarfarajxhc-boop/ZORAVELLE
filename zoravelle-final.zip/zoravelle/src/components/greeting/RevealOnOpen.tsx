"use client";

import { useEffect, useState } from "react";
import { RevealCurtain } from "./RevealCurtain";
import { revealFlagKey } from "./LockedScreen";

/**
 * Plays the reveal once, only when this page just changed from locked to open in this tab
 * (the countdown leaves a one-time flag). Opening the link later, or on another device, shows the
 * greeting directly, as it should.
 */
export function RevealOnOpen({ slug, accent, accentSoft }: { slug: string; accent: string; accentSoft: string }) {
  const [play, setPlay] = useState(false);
  useEffect(() => {
    try {
      if (window.sessionStorage.getItem(revealFlagKey(slug)) === "1") {
        window.sessionStorage.removeItem(revealFlagKey(slug));
        setPlay(true);
      }
    } catch { /* no storage: no reveal, the greeting is simply there */ }
  }, [slug]);
  return play ? <RevealCurtain accent={accent} accentSoft={accentSoft} onDone={() => setPlay(false)} /> : null;
}
