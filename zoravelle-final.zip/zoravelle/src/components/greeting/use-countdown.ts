"use client";

import { useCallback, useEffect, useRef, useState } from "react";

export type CountdownPhase = "counting" | "opening" | "gone";

type Opts = {
  slug: string;
  /** Unlock instant (UTC ms) and the server clock (UTC ms) the page was rendered with. */
  unlockMs: number;
  serverMs: number;
  /** Called once when the SERVER confirms the greeting is open. */
  onOpen: () => void;
  /** Preview mode: no network, no storage. Just counts down to unlockMs on the device clock. */
  preview?: boolean;
};

const store = (slug: string) => `zv.timer.${slug}`;

function readSaved(slug: string): { offset: number } | null {
  try {
    const raw = window.localStorage.getItem(store(slug));
    if (!raw) return null;
    const v = JSON.parse(raw) as { serverMs?: number; deviceMs?: number };
    if (typeof v.serverMs !== "number" || typeof v.deviceMs !== "number") return null;
    return { offset: v.serverMs - v.deviceMs };
  } catch {
    return null;
  }
}

/**
 * Countdown driven by the SERVER's clock.
 *
 * - "now" is the server time from the last sync plus time elapsed on the monotonic performance clock,
 *   so changing the device's date or time while the page is open changes nothing.
 * - It resyncs on start, every minute, when the tab becomes visible, on focus and when the network returns.
 * - At zero it keeps asking the server until the server says "open"; only then does it call onOpen().
 * - Offline, it keeps counting from the last known server offset and says so; it never opens by itself.
 */
export function useServerCountdown({ slug, unlockMs: initialUnlock, serverMs, onOpen, preview = false }: Opts) {
  const [unlockMs, setUnlockMs] = useState(initialUnlock);
  const [remainingMs, setRemainingMs] = useState(() => Math.max(0, initialUnlock - serverMs));
  const [phase, setPhase] = useState<CountdownPhase>("counting");
  const [online, setOnline] = useState(true);
  const [synced, setSynced] = useState(false);

  const base = useRef({ serverMs, perf: typeof performance !== "undefined" ? performance.now() : 0 });
  const unlockRef = useRef(initialUnlock);
  const opened = useRef(false);
  const onOpenRef = useRef(onOpen);
  onOpenRef.current = onOpen;

  const nowServer = useCallback(() => {
    if (preview) return Date.now();
    return base.current.serverMs + (performance.now() - base.current.perf);
  }, [preview]);

  const fire = useCallback(() => {
    if (opened.current) return;
    opened.current = true;
    onOpenRef.current();
  }, []);

  const sync = useCallback(async (): Promise<"locked" | "open" | "gone" | "offline"> => {
    if (preview) return "locked";
    const t0 = performance.now();
    try {
      const res = await fetch(`/api/greeting/${slug}/status`, { cache: "no-store", headers: { accept: "application/json" } });
      const t1 = performance.now();
      if (res.status === 404) { setPhase("gone"); return "gone"; }
      if (!res.ok) throw new Error(String(res.status));
      const body = (await res.json()) as { state: string; unlockAt?: string; serverNow: string };
      const server = Date.parse(body.serverNow);
      if (!Number.isFinite(server)) throw new Error("bad time");
      // Server time at the moment the response was produced, plus half the round trip.
      base.current = { serverMs: server + (t1 - t0) / 2, perf: t1 };
      setOnline(true);
      setSynced(true);
      try {
        window.localStorage.setItem(store(slug), JSON.stringify({ serverMs: server, deviceMs: Date.now() }));
      } catch { /* storage unavailable: fine */ }
      if (body.state === "open") return "open";
      if (body.state === "locked" && body.unlockAt) {
        const u = Date.parse(body.unlockAt);
        if (Number.isFinite(u)) { unlockRef.current = u; setUnlockMs(u); } // follows a creator who moved the time
      }
      return "locked";
    } catch {
      setOnline(false);
      return "offline";
    }
  }, [preview, slug]);

  // 1) first sync (and offline fallback when the page came from the cache)
  useEffect(() => {
    if (preview) return;
    let cancelled = false;
    (async () => {
      const r = await sync();
      if (cancelled) return;
      if (r === "open") return fire();
      if (r === "offline") {
        const saved = readSaved(slug);
        // The page may be a cached copy with an old server time: use the last known server/device offset instead.
        base.current = { serverMs: Date.now() + (saved?.offset ?? 0), perf: performance.now() };
      }
    })();
    return () => { cancelled = true; };
  }, [preview, sync, fire, slug]);

  // 2) tick
  useEffect(() => {
    const id = window.setInterval(() => {
      const left = unlockRef.current - nowServer();
      setRemainingMs(Math.max(0, left));
      if (left <= 0) setPhase((p) => (p === "gone" ? p : "opening"));
      else setPhase((p) => (p === "opening" ? "counting" : p));
    }, 250);
    return () => window.clearInterval(id);
  }, [nowServer]);

  // 3) periodic and event-driven resync
  useEffect(() => {
    if (preview) return;
    const again = async () => {
      const r = await sync();
      if (r === "open") fire();
    };
    const every = window.setInterval(again, 60_000);
    const onVisible = () => { if (document.visibilityState === "visible") void again(); };
    window.addEventListener("online", again);
    window.addEventListener("focus", again);
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      window.clearInterval(every);
      window.removeEventListener("online", again);
      window.removeEventListener("focus", again);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [preview, sync, fire]);

  // 4) at zero: confirm with the server, retrying gently until it says open
  useEffect(() => {
    if (preview || phase !== "opening") return;
    let stop = false;
    let wait = 1200;
    let timer = 0;
    const poll = async () => {
      if (stop) return;
      const r = await sync();
      if (stop) return;
      if (r === "open") return fire();
      if (r === "gone") return;
      wait = Math.min(wait * 1.5, 6000);
      timer = window.setTimeout(poll, wait);
    };
    void poll();
    return () => { stop = true; window.clearTimeout(timer); };
  }, [preview, phase, sync, fire]);

  return { remainingMs, unlockMs, phase, online, synced };
}
