"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { CloudOff, Lock } from "lucide-react";
import { formatInZone, splitRemaining } from "@/lib/schedule/time";
import { useServerCountdown } from "./use-countdown";
import { InstallTimerButton } from "./InstallTimerButton";

type Props = {
  slug: string;
  /** UTC instants (ISO). `serverNow` is the server clock at render time. */
  unlockAt: string;
  serverNow: string;
  /** The zone the creator chose, used only to show the time the way they meant it. */
  unlockTimezone: string;
  /** Creator preview: counts down to `unlockAt` on this device's clock, with no network or storage. */
  preview?: boolean;
  /** Smaller type for the phone frame in the publish step. */
  compact?: boolean;
};

export const revealFlagKey = (slug: string) => `zv.reveal.${slug}`;

const DUST = Array.from({ length: 16 }, (_, i) => ({
  left: (i * 37 + 11) % 100,
  size: 2 + ((i * 5) % 4),
  dur: 9 + ((i * 7) % 9),
  delay: -((i * 3) % 12),
  dx: ((i % 2 ? 1 : -1) * (10 + ((i * 13) % 40))),
}));

function Unit({ value, label, compact }: { value: number; label: string; compact: boolean }) {
  const text = String(value).padStart(2, "0");
  return (
    <div className="flex min-w-0 flex-1 flex-col items-center">
      <div
        className={`relative w-full overflow-hidden rounded-2xl border border-[#c9a860]/35 bg-gradient-to-b from-[#1a0a0e] to-[#0b0507] text-center shadow-[inset_0_1px_0_rgba(230,207,148,0.18),0_12px_30px_-12px_rgba(0,0,0,0.8)] ${compact ? "py-2" : "py-4 sm:py-6"}`}
      >
        <span
          key={text}
          className={`zv-tick block font-display font-semibold tabular-nums text-[#f3e3b3] ${compact ? "text-3xl" : "text-5xl sm:text-7xl"}`}
        >
          {text}
        </span>
        <span aria-hidden="true" className="absolute inset-x-0 top-1/2 h-px bg-black/50" />
      </div>
      <span className={`mt-2 font-medium uppercase tracking-[0.24em] text-[#c9a860] ${compact ? "text-[0.5rem]" : "text-[0.65rem] sm:text-xs"}`}>
        {label}
      </span>
    </div>
  );
}

/**
 * The premium countdown a recipient sees while the greeting is locked. It holds no greeting content:
 * only the unlock time. At zero it asks the SERVER whether the greeting is open and, when it is,
 * refreshes the page so the server renders the real greeting.
 */
export function LockedScreen({ slug, unlockAt, serverNow, unlockTimezone, preview = false, compact = false }: Props) {
  const router = useRouter();
  const unlockMs = useMemo(() => Date.parse(unlockAt), [unlockAt]);
  const serverMs = useMemo(() => Date.parse(serverNow), [serverNow]);

  const { remainingMs, unlockMs: liveUnlockMs, phase, online, synced } = useServerCountdown({
    slug,
    unlockMs,
    serverMs,
    preview,
    onOpen: () => {
      try { window.sessionStorage.setItem(revealFlagKey(slug), "1"); } catch { /* the reveal is optional */ }
      router.refresh();
    },
  });

  // Dates are formatted after mount so the server's time zone can't cause a hydration mismatch.
  const [when, setWhen] = useState<{ creator: string; local: string | null } | null>(null);
  useEffect(() => {
    const creator = formatInZone(liveUnlockMs, unlockTimezone);
    const local = formatInZone(liveUnlockMs, undefined);
    setWhen({ creator, local: local === creator ? null : local });
  }, [liveUnlockMs, unlockTimezone]);

  const t = splitRemaining(remainingMs);
  const opening = phase === "opening";
  const gone = phase === "gone";

  return (
    <div
      data-zv-state="locked"
      className={`relative isolate flex flex-col items-center justify-center overflow-hidden bg-[#070506] text-[#f6efe2] ${compact ? "min-h-[34rem] px-4 py-8" : "min-h-dvh px-5 py-12"}`}
      style={{ containerType: "size" }}
    >
      <div aria-hidden="true" className="zv-glow absolute left-1/2 top-[38%] -z-10 h-[34rem] w-[34rem] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[radial-gradient(closest-side,rgba(122,18,38,0.65),rgba(90,13,28,0.25)_55%,transparent)]" />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-[radial-gradient(120%_80%_at_50%_120%,rgba(201,168,96,0.12),transparent_60%)]" />
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
        {DUST.map((d, i) => (
          <span
            key={i}
            className="zv-dust absolute bottom-0 rounded-full bg-[#e6cf94]"
            style={{ left: `${d.left}%`, width: d.size, height: d.size, ["--dur" as string]: `${d.dur}s`, ["--delay" as string]: `${d.delay}s`, ["--dx" as string]: `${d.dx}px` } as React.CSSProperties}
          />
        ))}
      </div>

      <div className="mx-auto flex w-full max-w-2xl flex-col items-center text-center">
        <p className="inline-flex items-center gap-3 font-display text-sm font-semibold tracking-[0.34em] text-[#c9a860]">
          <span aria-hidden="true" className="h-px w-8 bg-[#c9a860]/50" />
          ZORAVELLE
          <span aria-hidden="true" className="h-px w-8 bg-[#c9a860]/50" />
        </p>

        <span className={`mt-8 grid place-items-center rounded-full border border-[#c9a860]/50 bg-[#1a0a0e] text-[#e6cf94] ${compact ? "h-10 w-10" : "h-14 w-14"}`}>
          <Lock className={compact ? "h-4 w-4" : "h-6 w-6"} aria-hidden="true" />
        </span>

        <h1 className={`mt-6 text-balance font-display font-medium leading-tight text-[#f6efe2] ${compact ? "text-2xl" : "text-4xl sm:text-6xl"}`}>
          {gone ? "This greeting is no longer available." : "Someone has prepared something special for you."}
        </h1>

        {!gone && (
          <>
            <p className={`mt-3 max-w-[40ch] text-[#f6efe2]/70 ${compact ? "text-xs" : "text-base sm:text-lg"}`}>
              {opening ? "It's time. Opening your greeting…" : "It will open by itself when the countdown reaches zero."}
            </p>

            <div
              role="timer"
              aria-live="off"
              aria-label={`${t.days} days, ${t.hours} hours, ${t.minutes} minutes, ${t.seconds} seconds left`}
              className={`mt-8 flex w-full items-start gap-2 sm:gap-4 ${compact ? "max-w-xs" : "max-w-xl"}`}
            >
              <Unit value={t.days} label="Days" compact={compact} />
              <Unit value={t.hours} label="Hours" compact={compact} />
              <Unit value={t.minutes} label="Minutes" compact={compact} />
              <Unit value={t.seconds} label="Seconds" compact={compact} />
            </div>

            <div className={`mt-6 text-[#f6efe2]/75 ${compact ? "text-xs" : "text-sm"}`} role="status">
              {when ? (
                <>
                  <p>Opens {when.creator}</p>
                  {when.local && <p className="mt-0.5 text-[#c9a860]">That is {when.local} where you are</p>}
                </>
              ) : (
                <p className="h-5" />
              )}
            </div>

            {!preview && !online && (
              <p role="status" className="mt-5 inline-flex items-center gap-2 rounded-full border border-[#c9a860]/40 bg-[#1a0a0e] px-4 py-2 text-sm text-[#e6cf94]">
                <CloudOff className="h-4 w-4" aria-hidden="true" />
                {synced
                  ? "You're offline. The countdown keeps going, and your greeting opens once you're back online."
                  : "Couldn't reach the server. The countdown is using the last time we knew."}
              </p>
            )}

            {opening && !preview && online && (
              <p role="status" className="mt-5 text-sm text-[#e6cf94]">Checking with the server…</p>
            )}

            {!preview && (
              <div className="mt-8">
                <InstallTimerButton slug={slug} />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
