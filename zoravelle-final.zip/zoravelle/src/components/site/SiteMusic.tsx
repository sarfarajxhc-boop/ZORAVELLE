"use client";

import { useEffect, useState } from "react";
import { Volume2, VolumeX } from "lucide-react";

export const MUSIC_SRC = "/audio/romantic-piano.mp3";
const PREF_KEY = "zoravelle.music"; // "off" once the visitor mutes it
const POS_KEY = "zoravelle.music.pos"; // where the song was, so a reload doesn't restart it
const VOLUME = 0.5;

type State = "idle" | "playing" | "paused" | "failed";

/*
 * One player for the whole site. It lives in the root layout, so it keeps playing while the visitor
 * moves between pages and is the same on the homepage, the create flow, the countdown and the greeting.
 * The audio object is module-level on purpose: it survives React re-mounts.
 *
 * Browsers only allow sound after the visitor has touched the page, so on load it tries to start at
 * once (allowed when the browser has seen the visitor engage with the site before) and otherwise starts
 * with the first tap or key press. A button turns it off and on; "off" is remembered on this device.
 * It pauses when the tab is hidden and never needs the network again once it is playing.
 */
let player: HTMLAudioElement | null = null;
let fader: ReturnType<typeof setInterval> | null = null;
const listeners = new Set<(s: State) => void>();
let current: State = "idle";
const set = (s: State) => {
  current = s;
  listeners.forEach((l) => l(s));
};

const read = (k: string): string | null => {
  try {
    return sessionStorage.getItem(k) ?? localStorage.getItem(k);
  } catch {
    return null;
  }
};
const remember = (v: "on" | "off") => {
  try {
    localStorage.setItem(PREF_KEY, v);
  } catch {
    /* private mode: the choice just isn't remembered */
  }
};

function audio(): HTMLAudioElement {
  if (!player) {
    const a = new Audio();
    a.preload = "none";
    a.loop = true;
    a.src = MUSIC_SRC;
    a.addEventListener("error", () => set("failed"));
    const resume = Number(read(POS_KEY));
    if (Number.isFinite(resume) && resume > 0) a.currentTime = resume;
    player = a;
  }
  return player;
}

function stopFade() {
  if (fader) clearInterval(fader);
  fader = null;
}

async function start(): Promise<void> {
  const a = audio();
  stopFade();
  a.volume = 0;
  try {
    await a.play();
  } catch (e) {
    set(e instanceof DOMException && e.name === "NotAllowedError" ? "paused" : "failed"); // paused = waiting for a tap
    return;
  }
  set("playing");
  fader = setInterval(() => {
    if (!player) return stopFade();
    player.volume = Math.min(VOLUME, player.volume + 0.05);
    if (player.volume >= VOLUME) stopFade();
  }, 120);
}

function pause() {
  stopFade();
  player?.pause();
  if (current !== "failed") set("paused");
}

export function SiteMusic() {
  const [state, setState] = useState<State>(current);

  useEffect(() => {
    listeners.add(setState);
    setState(current);

    const wantsMusic = () => {
      try {
        return localStorage.getItem(PREF_KEY) !== "off";
      } catch {
        return true;
      }
    };

    // 1) try straight away; 2) otherwise the first tap or key press starts it
    let armed = false;
    const events = ["pointerdown", "click", "keydown", "touchend"] as const;
    const disarm = () => events.forEach((e) => window.removeEventListener(e, go, true));
    function go() {
      if (!armed) return;
      armed = false;
      disarm();
      if (wantsMusic() && current !== "playing" && current !== "failed") void start();
    }
    if (current === "idle" && wantsMusic()) {
      void start().then(() => {
        if (current === "paused") {
          armed = true;
          events.forEach((e) => window.addEventListener(e, go, true));
        }
      });
    }

    const wasPlaying = { v: false };
    const onVis = () => {
      if (!player) return;
      if (document.hidden) {
        wasPlaying.v = !player.paused;
        if (!player.paused) player.pause();
      } else if (wasPlaying.v) {
        wasPlaying.v = false;
        void player.play().catch(() => set("paused"));
      }
    };
    const save = () => {
      try {
        if (player && player.currentTime > 0) sessionStorage.setItem(POS_KEY, String(Math.floor(player.currentTime)));
      } catch {
        /* nothing to save */
      }
    };
    document.addEventListener("visibilitychange", onVis);
    window.addEventListener("pagehide", save);
    return () => {
      listeners.delete(setState);
      disarm();
      document.removeEventListener("visibilitychange", onVis);
      window.removeEventListener("pagehide", save);
    };
  }, []);

  if (state === "failed") return null;
  const on = state === "playing";
  return (
    <button
      type="button"
      aria-pressed={on}
      aria-label={on ? "Turn background music off" : "Turn background music on"}
      title={on ? "Music on" : "Music off. Tap to play"}
      data-music={state}
      onClick={() => {
        if (on) {
          remember("off");
          pause();
        } else {
          remember("on");
          void start();
        }
      }}
      className="fixed bottom-4 left-4 z-[70] inline-flex h-11 w-11 items-center justify-center rounded-full border border-white/15 bg-black/55 text-white shadow-lg backdrop-blur-md hover:bg-black/70"
    >
      {on ? <Volume2 className="h-5 w-5" aria-hidden="true" /> : <VolumeX className="h-5 w-5" aria-hidden="true" />}
    </button>
  );
}
