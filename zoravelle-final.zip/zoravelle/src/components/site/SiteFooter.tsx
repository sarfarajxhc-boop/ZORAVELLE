import Link from "next/link";
import { Globe, Mail } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { InstagramIcon } from "@/components/ui/InstagramIcon";
import { Logo } from "./Logo";
import { CREATOR } from "@/lib/creator";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/occasions", label: "Occasions" },
  { href: "/about", label: "About" },
  { href: "/#features", label: "Features" },
  { href: "/create", label: "Create" },
  { href: "/privacy", label: "Privacy" },
];

const iconCls = "grid h-10 w-10 place-items-center rounded-full border border-white/25 text-white/85 transition-colors hover:border-gold-bright hover:text-gold-bright";

export function SiteFooter() {
  return (
    <footer className="bg-[#0a0a0a] text-paper">
      <Container className="flex flex-col gap-8 py-10 md:flex-row md:items-center md:justify-between">
        <div className="space-y-2">
          <Logo inverted tagline />
        </div>
        <nav aria-label="Footer" className="flex flex-wrap gap-x-6 gap-y-1 text-sm">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className="py-2 text-paper/80 hover:text-paper">{l.label}</Link>
          ))}
        </nav>
        <div className="flex gap-3">
          <a href={CREATOR.instagram} target="_blank" rel="noopener noreferrer" aria-label="Instagram" className={iconCls}>
            <InstagramIcon className="h-4 w-4" />
          </a>
          <a href={`mailto:${CREATOR.email}`} aria-label="Email" className={iconCls}>
            <Mail className="h-4 w-4" aria-hidden="true" />
          </a>
          <a href={CREATOR.website} target="_blank" rel="noopener noreferrer" aria-label="Portfolio" className={iconCls}>
            <Globe className="h-4 w-4" aria-hidden="true" />
          </a>
        </div>
      </Container>
      <Container className="border-t border-paper/10 py-5 text-center text-xs text-paper/60">
        © {new Date().getFullYear()} ZORAVELLE. Free to use. Created with{" "}
        <span role="img" aria-label="love">❤️</span> by{" "}
        <a href={CREATOR.website} target="_blank" rel="noopener noreferrer" className="font-semibold text-paper/90 underline underline-offset-4 hover:text-paper">
          {CREATOR.name}
        </a>
        .
      </Container>
    </footer>
  );
}
