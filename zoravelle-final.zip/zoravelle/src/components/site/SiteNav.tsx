import Link from "next/link";
import { ArrowRight, Menu, Sparkles } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Logo } from "./Logo";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/occasions", label: "Occasions" },
  { href: "/about", label: "About" },
  { href: "/#features", label: "Features" },
  { href: "/create", label: "Create" },
];

const linkCls = "rounded-full px-3 py-2 text-sm font-medium text-white/75 transition-colors hover:text-white";

export function SiteNav() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/10 bg-[#0a0a0a]/95 backdrop-blur-md">
      <Container className="relative flex h-[4.5rem] items-center justify-between gap-4">
        <Logo inverted tagline />

        <nav aria-label="Main" className="hidden items-center gap-2 md:flex lg:gap-5">
          {LINKS.map((l) => (
            <Link key={l.href} href={l.href} className={linkCls}>{l.label}</Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <Link
            href="/create"
            className="hidden min-h-11 items-center gap-2 rounded-full border border-crimson bg-crimson/15 px-5 text-sm font-semibold text-white transition-colors hover:bg-crimson sm:inline-flex"
          >
            <Sparkles className="h-4 w-4" aria-hidden="true" />
            Create a Greeting
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>

          {/* Mobile menu: a plain disclosure, so it works without JavaScript. */}
          <details className="group md:hidden">
            <summary className="grid h-11 w-11 cursor-pointer list-none place-items-center rounded-full border border-white/20 text-white [&::-webkit-details-marker]:hidden">
              <Menu className="h-5 w-5" aria-hidden="true" />
              <span className="sr-only">Menu</span>
            </summary>
            <nav aria-label="Mobile" className="absolute left-0 right-0 top-full border-b border-white/10 bg-[#0a0a0a] px-4 pb-4 pt-2">
              <ul>
                {LINKS.map((l) => (
                  <li key={l.href}>
                    <Link href={l.href} className="block border-b border-white/10 py-3.5 text-lg font-medium text-white">{l.label}</Link>
                  </li>
                ))}
              </ul>
              <Link href="/create" className="mt-4 flex min-h-12 items-center justify-center rounded-full bg-crimson font-semibold text-white">
                Create a Greeting
              </Link>
            </nav>
          </details>
        </div>
      </Container>
    </header>
  );
}
