import Link from "next/link";

/** Blossom mark + wordmark. Use `inverted` on dark backgrounds. */
export function Logo({ inverted = false, tagline = false }: { inverted?: boolean; tagline?: boolean }) {
  return (
    <Link href="/" className="inline-flex items-center gap-3" aria-label="ZORAVELLE home">
      <svg viewBox="-14 -14 28 28" className="h-8 w-8 shrink-0" aria-hidden="true">
        {[0, 72, 144, 216, 288].map((a) => (
          <ellipse key={a} cx="0" cy="-6.2" rx="4.4" ry="6.6" fill="#b51224" transform={`rotate(${a})`} />
        ))}
        <circle r="2.6" fill="#780d1b" />
        <circle r="1.1" fill="#e0b25a" />
      </svg>
      <span className="flex flex-col leading-none">
        <span className={`font-display text-[1.6rem] font-semibold tracking-[0.16em] ${inverted ? "text-white" : "text-ink"}`}>
          ZORAVELLE
        </span>
        {tagline && (
          <span className={`mt-1 hidden text-[0.5rem] font-medium uppercase tracking-[0.34em] sm:block ${inverted ? "text-white/60" : "text-ink-soft"}`}>
            Make every moment special
          </span>
        )}
      </span>
    </Link>
  );
}
