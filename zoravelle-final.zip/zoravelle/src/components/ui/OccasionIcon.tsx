import {
  Baby, Cake, Flame, Flower2, Gem, GraduationCap, HandHeart, Heart, HeartHandshake,
  HeartPulse, Medal, Moon, MoonStar, Palette, PartyPopper, Plane, Sparkle, Sparkles,
  Sunrise, TreePine, Trophy, Users, WandSparkles, type LucideIcon,
} from "lucide-react";

// Registry stores icon names as strings (so it stays plain data); resolve them here.
const ICONS: Record<string, LucideIcon> = {
  Baby, Cake, Flame, Flower2, Gem, GraduationCap, HandHeart, Heart, HeartHandshake,
  HeartPulse, Medal, Moon, MoonStar, Palette, PartyPopper, Plane, Sparkle, Sparkles,
  Sunrise, TreePine, Trophy, Users, Wand2: WandSparkles,
};

export function OccasionIcon({ name, className }: { name: string; className?: string }) {
  const Icon = ICONS[name] ?? Sparkles;
  return <Icon className={className} aria-hidden="true" />;
}
