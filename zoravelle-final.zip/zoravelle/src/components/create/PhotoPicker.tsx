"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { ImagePlus, RefreshCw, X } from "lucide-react";
import { prepareImage } from "@/lib/client/compress-image";
import { UploadError, uploadPhotoWithRetry, type UploadCredentials } from "@/lib/client/upload-photo";

export type Photo = { id: string; url: string };
export type { UploadCredentials };

const MAX_PHOTOS = 6;

type Pending = {
  key: string;
  name: string;
  /** Local preview of the chosen file, shown while it uploads. */
  preview: string;
  status: "waiting" | "preparing" | "uploading" | "error";
  progress: number;
  error?: string;
  retryable?: boolean;
  /** The resized file, kept so "Try again" doesn't need the person to pick it again. */
  prepared?: File;
  original: File;
  /** Set when this upload replaces an existing photo. */
  replaceId?: string;
};

type Props = {
  photos: Photo[];
  onAdd: (p: Photo) => void;
  /** Swap one photo for another in the same position. */
  onReplace: (oldId: string, p: Photo) => void;
  onRemove: (id: string) => void;
  /** Creates the draft on first use (uploads need one) and returns its credentials. */
  ensureDraft: () => Promise<UploadCredentials | null>;
  onSessionExpired: () => void;
};

let seq = 0;

export function PhotoPicker({ photos, onAdd, onReplace, onRemove, ensureDraft, onSessionExpired }: Props) {
  const [pending, setPending] = useState<Pending[]>([]);
  const [notice, setNotice] = useState<string | null>(null);
  const aborts = useRef(new Map<string, AbortController>());
  const chain = useRef<Promise<void>>(Promise.resolve());
  const latest = useRef(pending);
  latest.current = pending;
  const addInput = useRef<HTMLInputElement>(null);
  const replaceInput = useRef<HTMLInputElement>(null);
  const replaceTarget = useRef<string | null>(null);

  const patch = useCallback((key: string, p: Partial<Pending>) => {
    setPending((list) => list.map((x) => (x.key === key ? { ...x, ...p } : x)));
  }, []);
  const drop = useCallback((key: string) => {
    setPending((list) => {
      const gone = list.find((x) => x.key === key);
      if (gone) URL.revokeObjectURL(gone.preview);
      return list.filter((x) => x.key !== key);
    });
  }, []);

  // Leaving the page cancels anything still uploading.
  useEffect(() => () => { aborts.current.forEach((c) => c.abort()); }, []);

  const run = useCallback(async (key: string) => {
    const item = latest.current.find((x) => x.key === key);
    if (!item) return; // dismissed while waiting

    try {
      let file = item.prepared;
      if (!file) {
        patch(key, { status: "preparing", progress: 0, error: undefined });
        file = await prepareImage(item.original);
        patch(key, { prepared: file });
      }
      const creds = await ensureDraft();
      if (!creds) {
        return patch(key, { status: "error", error: "Go back and enter who the greeting is for and your name first.", retryable: false });
      }
      const ctl = new AbortController();
      aborts.current.set(key, ctl);
      patch(key, { status: "uploading", progress: 0, error: undefined });
      const r = await uploadPhotoWithRetry(creds, file, (progress) => patch(key, { progress }), ctl.signal);
      const photo = { id: r.assetId, url: r.url ?? item.preview };
      if (item.replaceId) onReplace(item.replaceId, photo);
      else onAdd(photo);
      // Keep the local preview alive: it is the photo's picture when the server gave no URL.
      setPending((list) => list.filter((x) => x.key !== key));
      setNotice(item.replaceId ? "Photo replaced." : "Photo added.");
    } catch (e) {
      if (e instanceof DOMException && e.name === "AbortError") return drop(key);
      if (e instanceof UploadError && e.sessionExpired) onSessionExpired();
      patch(key, {
        status: "error",
        error: e instanceof Error ? e.message : "Upload failed. Try again.",
        retryable: e instanceof UploadError ? e.retryable : false,
      });
    } finally {
      aborts.current.delete(key);
    }
  }, [ensureDraft, onAdd, onReplace, onSessionExpired, patch, drop]);

  const enqueue = useCallback((files: File[], replaceId?: string) => {
    setNotice(null);
    const room = MAX_PHOTOS - photos.length - latest.current.filter((x) => !x.replaceId && x.status !== "error").length;
    const take = replaceId ? files.slice(0, 1) : files.slice(0, Math.max(0, room));
    if (!replaceId && files.length > take.length) setNotice(`You can add up to ${MAX_PHOTOS} photos. ${take.length ? "The rest were skipped." : ""}`.trim());
    const items: Pending[] = take.map((f) => ({
      key: `p${++seq}`, name: f.name || "photo", preview: URL.createObjectURL(f), status: "waiting", progress: 0, original: f, replaceId,
    }));
    if (items.length === 0) return;
    latest.current = [...latest.current, ...items]; // visible to run() before React re-renders
    setPending((l) => [...l, ...items]);
    for (const it of items) chain.current = chain.current.then(() => run(it.key));
  }, [photos.length, run]);

  const retry = (key: string) => {
    patch(key, { status: "waiting", error: undefined });
    chain.current = chain.current.then(() => run(key));
  };
  const cancel = (key: string) => {
    const c = aborts.current.get(key);
    if (c) c.abort(); else drop(key);
  };

  const adding = pending.filter((x) => !x.replaceId && x.status !== "error").length;
  const full = photos.length + adding >= MAX_PHOTOS;
  const replacing = (id: string) => pending.some((x) => x.replaceId === id && x.status !== "error");

  return (
    <div>
      <p className="text-base font-semibold">Photos (optional)</p>
      <p className="mt-0.5 text-sm text-ink-soft">
        Add up to {MAX_PHOTOS}. They appear in the greeting as a photo collage. Location data is removed from every photo.
      </p>

      {(photos.length > 0 || pending.length > 0) && (
        <ul className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3">
          {photos.map((p, i) => (
            <li key={p.id} className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-ink/15 bg-white">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={p.url} alt={`Photo ${i + 1}`} referrerPolicy="no-referrer" className={`h-full w-full object-cover ${replacing(p.id) ? "opacity-40" : ""}`} />
              <button
                type="button" onClick={() => onRemove(p.id)} aria-label={`Remove photo ${i + 1}`}
                className="absolute right-1.5 top-1.5 grid h-9 w-9 place-items-center rounded-full bg-ink/80 text-paper hover:bg-ink"
              >
                <X className="h-4 w-4" aria-hidden="true" />
              </button>
              <button
                type="button" disabled={replacing(p.id)}
                onClick={() => { replaceTarget.current = p.id; replaceInput.current?.click(); }}
                aria-label={`Replace photo ${i + 1}`}
                className="absolute bottom-1.5 left-1.5 inline-flex min-h-9 items-center gap-1.5 rounded-full bg-ink/80 px-3 text-xs font-semibold text-paper hover:bg-ink disabled:opacity-60"
              >
                <RefreshCw className="h-3.5 w-3.5" aria-hidden="true" />
                Replace
              </button>
            </li>
          ))}

          {pending.map((x) => (
            <li key={x.key} className="relative aspect-[4/5] overflow-hidden rounded-2xl border border-ink/15 bg-ink/5">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={x.preview} alt="" className={`h-full w-full object-cover ${x.status === "error" ? "opacity-30" : "opacity-60"}`} />
              <div className="absolute inset-0 flex flex-col items-center justify-end gap-2 bg-gradient-to-t from-black/70 via-black/20 to-transparent p-3 text-center text-white">
                {x.status === "error" ? (
                  <>
                    <p role="alert" className="text-xs font-medium leading-snug">{x.error}</p>
                    <div className="flex gap-2">
                      {x.retryable && (
                        <button type="button" onClick={() => retry(x.key)} className="min-h-9 rounded-full bg-white px-3 text-xs font-semibold text-ink">
                          Try again
                        </button>
                      )}
                      <button type="button" onClick={() => drop(x.key)} className="min-h-9 rounded-full border border-white/60 px-3 text-xs font-semibold">
                        Dismiss
                      </button>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="text-xs font-semibold">
                      {x.status === "waiting" ? "Waiting…" : x.status === "preparing" ? "Preparing…" : `Uploading ${x.progress}%`}
                    </p>
                    <div
                      role="progressbar" aria-label={`Uploading ${x.name}`} aria-valuemin={0} aria-valuemax={100}
                      aria-valuenow={x.status === "uploading" ? x.progress : 0}
                      className="h-1.5 w-full overflow-hidden rounded-full bg-white/30"
                    >
                      <div className="h-full rounded-full bg-gold-bright transition-[width] duration-200" style={{ width: `${x.status === "uploading" ? x.progress : x.status === "preparing" ? 8 : 0}%` }} />
                    </div>
                    <button type="button" onClick={() => cancel(x.key)} className="min-h-9 rounded-full border border-white/60 px-3 text-xs font-semibold">
                      Cancel
                    </button>
                  </>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}

      <label
        className={`mt-3 inline-flex min-h-12 cursor-pointer items-center gap-2 rounded-full border border-ink/25 bg-white px-5 font-semibold focus-within:outline focus-within:outline-[3px] focus-within:outline-offset-2 focus-within:outline-rose ${
          full ? "pointer-events-none opacity-60" : "hover:bg-ink/5"
        }`}
      >
        <ImagePlus className="h-5 w-5" aria-hidden="true" />
        {full ? "Photo limit reached" : photos.length + pending.length ? "Add more photos" : "Add photos"}
        <input
          ref={addInput} type="file" accept="image/jpeg,image/png,image/webp,image/heic" multiple disabled={full} className="sr-only"
          onChange={(e) => { const f = Array.from(e.currentTarget.files ?? []) as File[]; e.currentTarget.value = ""; enqueue(f); }}
        />
      </label>
      <input
        ref={replaceInput} type="file" accept="image/jpeg,image/png,image/webp,image/heic" className="sr-only" tabIndex={-1} aria-hidden="true"
        onChange={(e) => {
          const f = Array.from(e.currentTarget.files ?? []) as File[]; e.currentTarget.value = "";
          const target = replaceTarget.current; replaceTarget.current = null;
          if (target && f.length) enqueue(f, target);
        }}
      />

      <p role="status" aria-live="polite" className="mt-3 text-sm font-medium text-ink-soft">{notice}</p>
    </div>
  );
}
