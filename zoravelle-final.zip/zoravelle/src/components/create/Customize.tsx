"use client";

import { AMBIENT_EFFECTS, GALLERY_LAYOUTS, LOOKS, type ExperienceConfig } from "@/lib/experience/schema";

type Look = (typeof LOOKS)[number];
type Layout = (typeof GALLERY_LAYOUTS)[number];
type Effect = (typeof AMBIENT_EFFECTS)[number];

const LOOK_INFO: Record<Look, { name: string; note: string; swatch: string }> = {
  calm: { name: "Calm", note: "Light and soft", swatch: "linear-gradient(135deg,#fbefe4,#f6cdbb)" },
  cinematic: { name: "Cinematic", note: "Dark and dramatic", swatch: "linear-gradient(135deg,#1a0d10,#7a2430)" },
  expensive: { name: "Expensive", note: "Black and gold", swatch: "linear-gradient(135deg,#0a0908,#c9a24a)" },
};
const LAYOUT_INFO: Record<Layout, { name: string; note: string }> = {
  polaroid: { name: "Polaroids", note: "Tilted prints" },
  grid: { name: "Grid", note: "Clean squares" },
  filmstrip: { name: "Filmstrip", note: "Swipe sideways" },
  spotlight: { name: "Spotlight", note: "One big, rest small" },
};
const EFFECT_NAME: Record<Effect, string> = {
  none: "None", confetti: "Confetti", snow: "Snow", floatingHearts: "Floating hearts", fireflies: "Fireflies",
  stars: "Stars", sparkles: "Sparkles", petals: "Petals", lanterns: "Lanterns", fireworks: "Fireworks", colorPowder: "Colour powder",
};

type Props = {
  config: ExperienceConfig;
  /** Applies at once to the preview; the parent saves it. */
  onChange: (next: ExperienceConfig) => void;
  status: string | null;
};

/**
 * Creator choices that change how the greeting looks, all of them validated like any other config
 * (fixed lists, no free-form CSS). The text itself is edited in "Edit the text".
 */
export function Customize({ config, onChange, status }: Props) {
  const look: Look = config.look ?? "cinematic";
  const gallery = config.blocks.find((b) => b.type === "gallery");
  const layout: Layout = gallery?.type === "gallery" ? (gallery.layout ?? "polaroid") : "polaroid";

  const setLayout = (l: Layout) =>
    onChange({ ...config, blocks: config.blocks.map((b) => (b.type === "gallery" ? { ...b, layout: l } : b)) });

  return (
    <div className="space-y-6 rounded-3xl border border-ink/15 bg-white/60 p-5">
      <fieldset>
        <legend className="font-semibold">Look</legend>
        <p className="mt-0.5 text-sm text-ink-soft">What your recipient sees first. They can still switch it.</p>
        <div className="mt-3 grid grid-cols-3 gap-2">
          {LOOKS.map((l) => (
            <label key={l} className={`cursor-pointer rounded-2xl border-2 p-2 text-center ${look === l ? "border-crimson" : "border-ink/15"}`}>
              <input type="radio" name="cz-look" className="sr-only" checked={look === l} onChange={() => onChange({ ...config, look: l })} />
              <span className="mx-auto block h-9 rounded-lg" style={{ background: LOOK_INFO[l].swatch }} aria-hidden="true" />
              <span className="mt-1.5 block text-sm font-semibold">{LOOK_INFO[l].name}</span>
              <span className="block text-xs text-ink-soft">{LOOK_INFO[l].note}</span>
            </label>
          ))}
        </div>
      </fieldset>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor="cz-effect" className="block font-semibold">Falling effect</label>
          <select
            id="cz-effect"
            className="mt-1.5 w-full rounded-2xl border border-ink/20 bg-white px-4 py-3 text-base"
            value={config.ambient.effect}
            onChange={(e) => onChange({ ...config, ambient: { ...config.ambient, effect: e.target.value as Effect } })}
          >
            {AMBIENT_EFFECTS.map((e) => <option key={e} value={e}>{EFFECT_NAME[e]}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="cz-intensity" className="block font-semibold">Amount: {config.ambient.intensity} of 5</label>
          <input
            id="cz-intensity"
            type="range" min={1} max={5} step={1}
            className="mt-3 w-full accent-crimson"
            disabled={config.ambient.effect === "none"}
            value={config.ambient.intensity}
            onChange={(e) => onChange({ ...config, ambient: { ...config.ambient, intensity: Number(e.target.value) } })}
          />
        </div>
      </div>

      {gallery && (
        <fieldset>
          <legend className="font-semibold">Photo layout</legend>
          <div className="mt-3 grid grid-cols-2 gap-2 sm:grid-cols-4">
            {GALLERY_LAYOUTS.map((l) => (
              <label key={l} className={`cursor-pointer rounded-2xl border-2 p-3 text-center ${layout === l ? "border-crimson" : "border-ink/15"}`}>
                <input type="radio" name="cz-layout" className="sr-only" checked={layout === l} onChange={() => setLayout(l)} />
                <span className="block text-sm font-semibold">{LAYOUT_INFO[l].name}</span>
                <span className="block text-xs text-ink-soft">{LAYOUT_INFO[l].note}</span>
              </label>
            ))}
          </div>
        </fieldset>
      )}

      <p role="status" className="text-sm text-ink-soft">{status}</p>
    </div>
  );
}
