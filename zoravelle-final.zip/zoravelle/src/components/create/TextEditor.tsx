"use client";

import { useState } from "react";
import type { ExperienceConfig } from "@/lib/experience/schema";

type Props = {
  config: ExperienceConfig;
  saving: boolean;
  /** Returns an error message, or null when saved. */
  onSave: (next: ExperienceConfig) => Promise<string | null>;
};

const inputCls =
  "w-full rounded-2xl border border-ink/20 bg-white px-4 py-3 text-base text-ink placeholder:text-ink-soft/70";

/** Edits plain text only. Scenes, colours and layout stay as generated. */
export function TextEditor({ config, saving, onSave }: Props) {
  const hero = config.blocks.find((b) => b.type === "hero");
  const msg = config.blocks.find((b) => b.type === "message");

  const [headline, setHeadline] = useState(hero?.type === "hero" ? hero.headline : "");
  const [sub, setSub] = useState(hero?.type === "hero" ? (hero.subheadline ?? "") : "");
  const [body, setBody] = useState(msg?.type === "message" ? msg.body : "");
  const [signoff, setSignoff] = useState(msg?.type === "message" ? (msg.signoff ?? "") : "");
  const [status, setStatus] = useState<{ kind: "ok" | "error"; text: string } | null>(null);

  async function save() {
    if (!headline.trim()) return setStatus({ kind: "error", text: "The headline can't be empty." });
    if (!body.trim()) return setStatus({ kind: "error", text: "The message can't be empty." });

    const next: ExperienceConfig = {
      ...config,
      blocks: config.blocks.map((b) => {
        if (b.type === "hero") return { ...b, headline: headline.trim(), subheadline: sub.trim() || undefined };
        if (b.type === "message") return { ...b, body: body.trim(), signoff: signoff.trim() || undefined };
        return b;
      }),
    };
    const error = await onSave(next);
    setStatus(error ? { kind: "error", text: error } : { kind: "ok", text: "Saved. The preview is updated." });
  }

  return (
    <form
      className="space-y-4 rounded-3xl border border-ink/15 bg-white/60 p-5"
      onSubmit={(e) => { e.preventDefault(); void save(); }}
      noValidate
    >
      <div>
        <label htmlFor="ed-headline" className="block font-semibold">Headline</label>
        <input id="ed-headline" className={`${inputCls} mt-1.5`} value={headline} maxLength={80} onChange={(e) => setHeadline(e.target.value)} />
      </div>
      <div>
        <label htmlFor="ed-sub" className="block font-semibold">Line under the headline (optional)</label>
        <input id="ed-sub" className={`${inputCls} mt-1.5`} value={sub} maxLength={160} onChange={(e) => setSub(e.target.value)} />
      </div>
      <div>
        <label htmlFor="ed-body" className="block font-semibold">Message</label>
        <textarea id="ed-body" className={`${inputCls} mt-1.5 min-h-40`} value={body} maxLength={1200} onChange={(e) => setBody(e.target.value)} />
        <p className="mt-1 text-right text-xs text-ink-soft">{body.length} / 1200</p>
      </div>
      <div>
        <label htmlFor="ed-sign" className="block font-semibold">Sign-off (optional)</label>
        <input id="ed-sign" className={`${inputCls} mt-1.5`} value={signoff} maxLength={60} onChange={(e) => setSignoff(e.target.value)} />
      </div>
      <div className="flex flex-wrap items-center gap-3">
        <button
          type="submit"
          disabled={saving}
          className="min-h-12 rounded-full bg-crimson px-6 font-semibold text-white hover:bg-crimson-dark disabled:opacity-60"
        >
          {saving ? "Saving…" : "Save changes"}
        </button>
        <p role="status" className={`text-sm font-medium ${status?.kind === "error" ? "text-[#B51224]" : "text-ink-soft"}`}>
          {status?.text}
        </p>
      </div>
    </form>
  );
}
