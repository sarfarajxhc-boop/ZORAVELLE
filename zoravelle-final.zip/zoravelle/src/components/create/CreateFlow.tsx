"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import Link from "next/link";
import {
  generateGreeting, publishGreeting, removePhoto, resumeDraft, saveEdits, startDraft,
  type DraftCredentials, type PublishResult,
} from "@/app/(site)/create/[occasion]/actions";
import type { ExperienceConfig } from "@/lib/experience/schema";
import { saveGreeting } from "@/lib/client/my-greetings";
import { OccasionIcon } from "@/components/ui/OccasionIcon";
import { ExperienceRenderer } from "@/components/experience/ExperienceRenderer";
import { PhotoPicker, type Photo } from "./PhotoPicker";
import { TextEditor } from "./TextEditor";
import { WriteWithAI } from "./WriteWithAI";
import { Customize } from "./Customize";
import { clearDraft, isWorthResuming, loadDraft, saveDraft, type SavedDraft } from "@/lib/client/draft-store";
import { ShareCard } from "./ShareCard";
import { PublishOptions, buildSchedule, type Delivery } from "./PublishOptions";

export type OccasionProps = {
  id: string;
  label: string;
  title: string;
  blurb: string;
  icon: string;
  isCustom: boolean;
  background: string;
  text: string;
};

type Form = {
  customOccasionLabel: string;
  recipientName: string;
  senderName: string;
  relationship: string;
  message: string;
  extraInstructions: string;
  themeHint: string;
  colorHint: string;
};

const EMPTY: Form = {
  customOccasionLabel: "", recipientName: "", senderName: "", relationship: "",
  message: "", extraInstructions: "", themeHint: "", colorHint: "",
};

type Meta = { provider: string; usedFallback: boolean };
type Published = Extract<PublishResult, { ok: true }>;

const STEP_TITLES = ["Who is it for?", "Say it your way", "Pick the style"];
const STYLES = ["Soft and warm", "Bold and bright", "Elegant", "Playful"];
const COLORS = ["Gold", "Crimson", "Black", "Blue", "Green", "Sunset"];

const inputCls =
  "w-full rounded-2xl border border-ink/20 bg-white px-4 py-3 text-base text-ink placeholder:text-ink-soft/70";

function Field({
  id, label, hint, error, children,
}: { id: string; label: string; hint?: string; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={id} className="block text-base font-semibold">{label}</label>
      {hint && <p id={`${id}-hint`} className="mt-0.5 text-sm text-ink-soft">{hint}</p>}
      <div className="mt-2">{children}</div>
      {error && <p id={`${id}-error`} role="alert" className="mt-1.5 text-sm font-medium text-[#B51224]">{error}</p>}
    </div>
  );
}

function Chips({
  options, value, onChange, label,
}: { options: string[]; value: string; onChange: (v: string) => void; label: string }) {
  return (
    <div role="group" aria-label={label} className="flex flex-wrap gap-2">
      {options.map((o) => (
        <button
          key={o}
          type="button"
          aria-pressed={value === o}
          onClick={() => onChange(value === o ? "" : o)}
          className={`min-h-11 rounded-full border px-4 text-sm font-semibold transition-colors ${
            value === o ? "border-crimson bg-crimson text-white" : "border-ink/25 bg-white text-ink hover:bg-ink/5"
          }`}
        >
          {o}
        </button>
      ))}
    </div>
  );
}

function ErrorBanner({ message }: { message: string | null }) {
  if (!message) return null;
  return (
    <p role="alert" className="mt-4 rounded-2xl bg-[#fbeaec] p-4 text-sm font-medium text-[#780D1B]">
      {message}
    </p>
  );
}

export function CreateFlow({ occasion, needsDatabase = false }: { occasion: OccasionProps; needsDatabase?: boolean }) {
  const [step, setStep] = useState(0);
  const [form, setForm] = useState<Form>(EMPTY);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  // The draft is created the first time it is needed (first photo or first generation).
  const [draft, setDraft] = useState<DraftCredentials | null>(null);
  const draftRequest = useRef<Promise<DraftCredentials | null> | null>(null);
  const [photos, setPhotos] = useState<Photo[]>([]);

  const [config, setConfig] = useState<ExperienceConfig | null>(null);
  const [meta, setMeta] = useState<Meta | null>(null);
  const [assetUrls, setAssetUrls] = useState<Record<string, string>>({});
  const [previewKey, setPreviewKey] = useState(0);
  const [published, setPublished] = useState<Published | null>(null);
  const [delivery, setDelivery] = useState<Delivery>({ mode: "now" });

  // ---- Saved draft: survives a refresh or a closed tab (this browser only) ----
  const [resumable, setResumable] = useState<SavedDraft | null>(null);
  const [draftState, setDraftState] = useState<"idle" | "saved" | "unavailable">("idle");
  const [resumeNote, setResumeNote] = useState<string | null>(null);
  const [customStatus, setCustomStatus] = useState<string | null>(null);
  const checkedSaved = useRef(false);
  useEffect(() => {
    if (checkedSaved.current) return;
    checkedSaved.current = true;
    const d = loadDraft(occasion.id);
    if (d && isWorthResuming(d)) setResumable(d);
  }, [occasion.id]);

  const [generating, startGenerate] = useTransition();
  const [publishing, startPublish] = useTransition();
  const [saving, startSave] = useTransition();

  const set = (k: keyof Form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));
  const onInput = (k: keyof Form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    set(k)(e.target.value);

  useEffect(() => {
    if (resumable || published || !checkedSaved.current) return;
    const has = Boolean(config || draft || Object.values(form).some((v) => v.trim()));
    if (!has) return;
    const t = setTimeout(() => {
      const ok = saveDraft(occasion.id, { step, form: { ...form }, draft, config, meta });
      setDraftState(ok ? "saved" : "unavailable");
    }, 600);
    return () => clearTimeout(t);
  }, [form, step, draft, config, meta, resumable, published, occasion.id]);

  async function continueSaved() {
    const d = resumable;
    if (!d) return;
    setResumable(null);
    setForm({ ...EMPTY, ...Object.fromEntries(Object.entries(d.form).filter(([k]) => k in EMPTY)) } as Form);
    setStep(d.step);
    if (!d.draft) return;
    const r = await resumeDraft(d.draft);
    if (!r.ok || r.published) {
      clearDraft(occasion.id);
      setResumeNote(r.ok ? "That greeting was already published, so we started a new one with your details." : "Your details are back. The photos and preview couldn't be restored, so add the photos again and generate once more.");
      setStep(Math.min(d.step, 1));
      return;
    }
    setDraft(d.draft);
    setPhotos(r.assetIds.map((id) => ({ id, url: r.assetUrls[id] ?? "" })));
    setAssetUrls(r.assetUrls);
    if (d.config && d.meta) {
      setConfig(d.config);
      setMeta(d.meta);
      setPreviewKey((k) => k + 1);
    }
  }

  function startFresh() {
    clearDraft(occasion.id);
    setResumable(null);
  }

  // Look, effect and photo layout changes show at once; they are saved a moment after the last change.
  const customTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  function customise(next: ExperienceConfig) {
    setConfig(next);
    setCustomStatus("Saving…");
    if (customTimer.current) clearTimeout(customTimer.current);
    customTimer.current = setTimeout(async () => {
      if (!draft) return setCustomStatus("Your session expired. Please create the greeting again.");
      const r = await saveEdits(draft, next);
      if (r.ok) setCustomStatus("Saved.");
      else if (r.draftExpired) sessionExpired(r.message);
      else setCustomStatus(r.message);
    }, 700);
  }

  function validateStep0() {
    const e: Record<string, string> = {};
    if (occasion.isCustom && !form.customOccasionLabel.trim()) e.customOccasionLabel = "Name your occasion.";
    if (!form.recipientName.trim()) e.recipientName = "Enter who this is for.";
    if (!form.senderName.trim()) e.senderName = "Enter your name.";
    setErrors(e);
    return Object.keys(e).length === 0;
  }

  function next() {
    if (step === 0 && !validateStep0()) return;
    setStep((s) => Math.min(s + 1, 2));
  }

  /** The server rejected our edit token (expired or removed): drop local state tied to it. */
  function sessionExpired(message = "Your session expired, so your photos were cleared. Add them again to continue.") {
    setDraft(null);
    draftRequest.current = null;
    setPhotos([]);
    setAssetUrls({});
    setError(message);
  }

  function ensureDraft(): Promise<DraftCredentials | null> {
    if (draft) return Promise.resolve(draft);
    draftRequest.current ??= startDraft({
      occasion: occasion.id,
      recipientName: form.recipientName.trim(),
      senderName: form.senderName.trim(),
    }).then((r) => {
      if (r.ok) {
        setDraft(r.draft);
        return r.draft;
      }
      setError(r.message);
      draftRequest.current = null;
      return null;
    });
    return draftRequest.current;
  }

  async function removeOnePhoto(id: string) {
    if (!draft) return;
    const r = await removePhoto(draft, id);
    if (r.ok) setPhotos((p) => p.filter((x) => x.id !== id));
    else if (r.draftExpired) sessionExpired();
    else setError(r.message);
  }

  /** After a replace the new photo is already in place; this only frees the old one on the server. */
  async function removePhotoQuietly(id: string) {
    if (!draft) return;
    const r = await removePhoto(draft, id);
    if (!r.ok && r.draftExpired) sessionExpired();
  }

  function buildInput() {
    const opt = (v: string) => (v.trim() ? v.trim() : undefined);
    return {
      occasion: occasion.id,
      customOccasionLabel: occasion.isCustom ? opt(form.customOccasionLabel) : undefined,
      recipientName: form.recipientName.trim(),
      senderName: form.senderName.trim(),
      relationship: opt(form.relationship),
      message: opt(form.message),
      extraInstructions: opt(form.extraInstructions),
      themeHint: opt(form.themeHint),
      colorHint: opt(form.colorHint),
      assetIds: photos.map((p) => p.id),
    };
  }

  function generate() {
    if (!validateStep0()) { setStep(0); return; }
    setError(null);
    startGenerate(async () => {
      const r = await generateGreeting(buildInput(), draft ?? undefined);
      if (!r.ok) {
        setErrors(r.fieldErrors);
        if (r.draftExpired) sessionExpired(r.message);
        else setError(r.message);
        if (Object.keys(r.fieldErrors).length) { setConfig(null); setStep(0); }
        return;
      }
      setErrors({});
      setDraft(r.draft);
      setConfig(r.config);
      setMeta({ provider: r.provider, usedFallback: r.usedFallback });
      setAssetUrls(r.assetUrls);
      setPreviewKey((k) => k + 1);
    });
  }

  async function saveText(next: ExperienceConfig): Promise<string | null> {
    if (!draft) return "Your session expired. Please create the greeting again.";
    return new Promise((resolve) => {
      startSave(async () => {
        const r = await saveEdits(draft, next);
        if (r.ok) {
          setConfig(r.config);
          setPreviewKey((k) => k + 1);
          resolve(null);
        } else {
          if (r.draftExpired) sessionExpired(r.message);
          resolve(r.message);
        }
      });
    });
  }

  function publish() {
    if (!draft) return;
    setError(null);
    // Same rule the server applies, so a past or invalid time is caught before anything is sent.
    const built = buildSchedule(delivery);
    if (!built.ok) return setError(built.message);
    startPublish(async () => {
      const r = await publishGreeting(draft, built.input);
      if (!r.ok) {
        if (r.draftExpired) sessionExpired(r.message);
        else setError(r.message);
        return;
      }
      setPublished(r);
      clearDraft(occasion.id);
      saveGreeting({
        id: draft.id,
        token: draft.token,
        slug: r.slug,
        label: `${occasion.label} for ${form.recipientName.trim()}`,
        createdAt: new Date().toISOString(),
      });
    });
  }

  // ---- Published: share ----
  if (published) {
    return (
      <div>
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">
          {published.unlockAt ? "Your greeting is scheduled" : "Your greeting is live"}
        </h1>
        <p className="mt-3 max-w-[50ch] text-ink-soft">
          {published.unlockAt
            ? "The link works now. Until the unlock time it shows only a countdown."
            : "Anyone with the link can open it. They don't need an account or an app."}
        </p>
        <div className="mt-8">
          <ShareCard
            url={published.url}
            manageUrl={published.manageUrl}
            persistent={published.persistent}
            unlockAt={published.unlockAt}
            unlockTimezone={published.unlockTimezone}
            recipientName={form.recipientName.trim()}
          />
        </div>
        <div className="mt-10">
          <Link
            href="/create"
            className="inline-flex min-h-12 items-center rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5"
          >
            Create another greeting
          </Link>
        </div>
      </div>
    );
  }

  // ---- Result: preview, edit, publish ----
  if (config && meta) {
    return (
      <div>
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Your greeting is ready</h1>
        <p role="status" className="mt-1 text-xs text-ink-soft">{draftState === "saved" ? "Draft saved on this device" : ""}</p>
        <p className="mt-3 max-w-[50ch] text-ink-soft">
          This is how your recipient will see it. Tap through it to try it out.
        </p>
        <div className="mx-auto mt-8 w-full max-w-sm overflow-hidden rounded-[2rem] border-[6px] border-ink shadow-xl">
          <ExperienceRenderer key={previewKey} config={config} assets={assetUrls} mode="embedded" forceLook={config.look ?? "cinematic"} />
        </div>
        <p className="mt-4 max-w-[56ch] text-sm text-ink-soft">
          {meta.usedFallback
            ? "The AI service didn't respond, so a built-in template wrote this greeting. Try Regenerate in a moment."
            : meta.provider === "mock"
              ? "A built-in template wrote this greeting (demo mode, no AI service is configured)."
              : "Written by AI. Read it through before you publish."}
        </p>

        <PublishOptions value={delivery} onChange={setDelivery} config={config} assetUrls={assetUrls} />

        <ErrorBanner message={error} />

        <div className="mt-6 flex flex-wrap gap-3">
          <button
            type="button"
            onClick={publish}
            disabled={publishing || generating}
            className="min-h-12 rounded-full bg-crimson px-8 font-semibold text-white hover:bg-crimson-dark disabled:opacity-60"
          >
            {publishing ? "Publishing…" : delivery.mode === "lock" ? "Publish and lock" : "Publish"}
          </button>
          <button
            type="button"
            onClick={() => setPreviewKey((k) => k + 1)}
            className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5"
          >
            Replay
          </button>
          <button
            type="button"
            onClick={generate}
            disabled={generating || publishing}
            className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5 disabled:opacity-60"
          >
            {generating ? "Regenerating…" : "Regenerate"}
          </button>
          <button
            type="button"
            onClick={() => { setConfig(null); setMeta(null); setStep(0); }}
            className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5"
          >
            Edit details
          </button>
        </div>

        <details className="mt-8 group" open>
          <summary className="min-h-11 cursor-pointer py-2 text-base font-semibold">Customise the look</summary>
          <div className="mt-3">
            <Customize config={config} onChange={customise} status={customStatus} />
          </div>
        </details>

        <details className="mt-4 group">
          <summary className="min-h-11 cursor-pointer py-2 text-base font-semibold">Edit the text</summary>
          <div className="mt-3">
            {/* key: a regenerated greeting starts with fresh field values */}
            <TextEditor key={`${draft?.id}-${previewKey}-${meta.provider}`} config={config} saving={saving} onSave={saveText} />
          </div>
        </details>
      </div>
    );
  }

  // ---- Form view ----
  return (
    <div>
      <div className="flex items-center gap-3">
        <span className="grid h-11 w-11 place-items-center rounded-full bg-ink text-gold-bright">
          <OccasionIcon name={occasion.icon} className="h-6 w-6" />
        </span>
        <div>
          <p className="font-semibold">{occasion.title}</p>
          <Link href="/create" className="text-sm text-ink-soft underline underline-offset-4 hover:text-ink">
            Change occasion
          </Link>
        </div>
      </div>

      {needsDatabase && (
        <p role="note" className="mt-6 rounded-2xl bg-[#f7f0e1] p-4 text-sm font-medium text-[#6b5420]">
          Setup needed: no database is connected to this site yet, so photos and publishing can fail at random. The
          site owner needs to connect Supabase (see DEPLOY.md).
        </p>
      )}

      {resumable && (
        <div role="region" aria-label="Saved draft" className="mt-6 rounded-2xl border border-gold/60 bg-[#fbf6ec] p-4">
          <p className="font-semibold">Continue where you left off?</p>
          <p className="mt-0.5 text-sm text-ink-soft">
            You have an unfinished greeting{resumable.form["recipientName"] ? ` for ${resumable.form["recipientName"]}` : ""}, saved on this device {new Date(resumable.savedAt).toLocaleString()}.
          </p>
          <div className="mt-3 flex flex-wrap gap-3">
            <button type="button" onClick={() => void continueSaved()} className="min-h-11 rounded-full bg-crimson px-5 font-semibold text-white hover:bg-crimson-dark">Continue</button>
            <button type="button" onClick={startFresh} className="min-h-11 rounded-full border border-ink/25 px-5 font-semibold hover:bg-ink/5">Start fresh</button>
          </div>
        </div>
      )}
      {resumeNote && <p role="note" className="mt-4 rounded-2xl bg-[#f7f0e1] p-3 text-sm font-medium text-[#6b5420]">{resumeNote}</p>}

      <p className="mt-8 text-sm font-medium text-ink-soft">
        Step {step + 1} of 3
        <span className="ml-3 font-normal" role="status">
          {draftState === "saved" ? "Draft saved on this device" : draftState === "unavailable" ? "This browser can't save drafts" : ""}
        </span>
      </p>
      <div className="mt-2 flex gap-1.5" aria-hidden="true">
        {STEP_TITLES.map((_, i) => (
          <span key={i} className={`h-1.5 flex-1 rounded-full ${i <= step ? "bg-ink" : "bg-ink/15"}`} />
        ))}
      </div>
      <h1 className="mt-4 text-4xl font-bold tracking-tight sm:text-5xl">{STEP_TITLES[step]}</h1>

      <ErrorBanner message={error} />

      <form
        className="mt-8 space-y-6"
        noValidate
        onSubmit={(e) => { e.preventDefault(); step < 2 ? next() : generate(); }}
      >
        {step === 0 && (
          <>
            {occasion.isCustom && (
              <Field id="customOccasionLabel" label="What's the occasion?" hint="For example: Retirement, New home, Driving test." error={errors.customOccasionLabel}>
                <input id="customOccasionLabel" className={inputCls} value={form.customOccasionLabel} onChange={onInput("customOccasionLabel")} maxLength={40} autoComplete="off" />
              </Field>
            )}
            <Field id="recipientName" label="Who is it for?" error={errors.recipientName}>
              <input id="recipientName" className={inputCls} value={form.recipientName} onChange={onInput("recipientName")} maxLength={60} autoComplete="off" aria-invalid={!!errors.recipientName} />
            </Field>
            <Field id="senderName" label="Your name" hint="Shown as the sender." error={errors.senderName}>
              <input id="senderName" className={inputCls} value={form.senderName} onChange={onInput("senderName")} maxLength={60} autoComplete="name" aria-invalid={!!errors.senderName} />
            </Field>
            <Field id="relationship" label="Your relationship (optional)" hint="For example: sister, best friend, manager. It helps the tone." error={errors.relationship}>
              <input id="relationship" className={inputCls} value={form.relationship} onChange={onInput("relationship")} maxLength={60} autoComplete="off" />
            </Field>
          </>
        )}

        {step === 1 && (
          <>
            <Field id="message" label="Your message (optional)" hint="Write it yourself, or leave it empty and the AI will draft one." error={errors.message}>
              <textarea id="message" className={`${inputCls} min-h-36`} value={form.message} onChange={onInput("message")} maxLength={1200} />
              <p className="mt-1 text-right text-xs text-ink-soft">{form.message.length} / 1200</p>
            </Field>
            <WriteWithAI
              occasion={occasion.id}
              customOccasionLabel={form.customOccasionLabel}
              recipientName={form.recipientName}
              senderName={form.senderName}
              relationship={form.relationship}
              current={form.message}
              onInsert={(message) => setForm((f) => ({ ...f, message }))}
            />
            <Field id="extraInstructions" label="Anything else? (optional)" hint="For example: mention our trip to Goa, keep it funny." error={errors.extraInstructions}>
              <textarea id="extraInstructions" className={`${inputCls} min-h-24`} value={form.extraInstructions} onChange={onInput("extraInstructions")} maxLength={400} />
            </Field>
            <PhotoPicker
              photos={photos}
              onAdd={(p) => { setPhotos((x) => [...x, p]); setAssetUrls((u) => ({ ...u, [p.id]: p.url })); }}
              onReplace={(oldId, p) => { setPhotos((x) => x.map((q) => (q.id === oldId ? p : q))); setAssetUrls((u) => ({ ...u, [p.id]: p.url })); void removePhotoQuietly(oldId); }}
              onRemove={(id) => void removeOnePhoto(id)}
              ensureDraft={ensureDraft}
              onSessionExpired={() => sessionExpired()}
            />
          </>
        )}

        {step === 2 && (
          <>
            <div>
              <p className="text-base font-semibold">Style</p>
              <p className="mt-0.5 mb-2 text-sm text-ink-soft">Leave this empty to let the AI choose.</p>
              <Chips label="Style" options={STYLES} value={form.themeHint} onChange={set("themeHint")} />
            </div>
            <div>
              <p className="text-base font-semibold">Colours</p>
              <p className="mt-0.5 mb-2 text-sm text-ink-soft">Optional. Leave empty to use the occasion&apos;s default colours.</p>
              <Chips label="Colours" options={COLORS} value={form.colorHint} onChange={set("colorHint")} />
            </div>
          </>
        )}

        <div className="flex flex-wrap gap-3 pt-2">
          {step > 0 && (
            <button
              type="button"
              onClick={() => setStep((s) => s - 1)}
              className="min-h-12 rounded-full border border-ink/25 px-6 font-semibold hover:bg-ink/5"
            >
              Back
            </button>
          )}
          {step < 2 ? (
            <button type="submit" className="min-h-12 rounded-full bg-crimson px-8 font-semibold text-white hover:bg-crimson-dark">
              Next
            </button>
          ) : (
            <button
              type="submit"
              disabled={generating}
              className="min-h-12 rounded-full bg-crimson px-8 font-semibold text-white hover:bg-crimson-dark disabled:opacity-60"
            >
              {generating ? "Creating your greeting…" : "Create my greeting"}
            </button>
          )}
        </div>
      </form>
    </div>
  );
}
