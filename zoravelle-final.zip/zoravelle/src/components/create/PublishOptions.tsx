"use client";

import { useEffect, useMemo, useState } from "react";
import { CalendarClock, Rocket } from "lucide-react";
import { ExperienceRenderer } from "@/components/experience/ExperienceRenderer";
import type { ExperienceConfig } from "@/lib/experience/schema";
import { LockedScreen } from "@/components/greeting/LockedScreen";
import { RevealCurtain } from "@/components/greeting/RevealCurtain";
import {
  COMMON_ZONES, DEFAULT_TIMEZONE, UNLOCK_PROBLEM_TEXT, checkUnlock, formatInZone, isValidTimeZone,
  todayInZone, zonedWallToUtc,
} from "@/lib/schedule/time";
import type { ScheduleInput } from "@/lib/greetings/schedule-input";

export type Delivery =
  | { mode: "now" }
  | { mode: "lock"; date: string; time: string; tz: string };

/** Tomorrow, 9:00 in India time: a sensible starting point for a surprise. */
export function defaultLock(now = new Date()): Extract<Delivery, { mode: "lock" }> {
  return { mode: "lock", date: todayInZone(DEFAULT_TIMEZONE, new Date(now.getTime() + 24 * 3600_000)), time: "09:00", tz: DEFAULT_TIMEZONE };
}

type Built = { ok: true; input: ScheduleInput; unlockAt: Date } | { ok: false; message: string };

/** Turn the form into what the server accepts, applying the same rule the server applies. */
export function buildSchedule(d: Delivery, now = new Date()): Built {
  if (d.mode === "now") return { ok: true, input: { mode: "now" }, unlockAt: now };
  if (!d.date || !d.time) return { ok: false, message: "Pick a date and a time." };
  if (!isValidTimeZone(d.tz)) return { ok: false, message: "Pick a time zone." };
  const at = zonedWallToUtc(d.date, d.time, d.tz);
  if (!at) return { ok: false, message: "That time doesn't exist in this time zone (clocks skip it). Pick another." };
  const problem = checkUnlock(at, now);
  if (problem) return { ok: false, message: UNLOCK_PROBLEM_TEXT[problem] };
  return { ok: true, input: { mode: "lock", unlockAt: at.toISOString(), timezone: d.tz }, unlockAt: at };
}

const fieldCls = "w-full rounded-2xl border border-ink/20 bg-white px-4 py-3 text-base text-ink";

/** Date, time and zone inputs with live validation. Also used on the manage page to move the time. */
export function ScheduleFields({
  value, onChange, idPrefix = "lock",
}: { value: Extract<Delivery, { mode: "lock" }>; onChange: (v: Extract<Delivery, { mode: "lock" }>) => void; idPrefix?: string }) {
  const [deviceZone, setDeviceZone] = useState<string | null>(null);
  useEffect(() => {
    try {
      const z = Intl.DateTimeFormat().resolvedOptions().timeZone;
      if (z && isValidTimeZone(z) && !COMMON_ZONES.some((c) => c.id === z)) setDeviceZone(z);
    } catch { /* keep the list */ }
  }, []);

  const built = buildSchedule(value);
  const set = (patch: Partial<typeof value>) => onChange({ ...value, ...patch });

  return (
    <div className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label htmlFor={`${idPrefix}-date`} className="block text-sm font-semibold">Unlock date</label>
          <input
            id={`${idPrefix}-date`} type="date" className={`${fieldCls} mt-1.5`} value={value.date}
            min={todayInZone(value.tz)} onChange={(e) => set({ date: e.target.value })}
          />
        </div>
        <div>
          <label htmlFor={`${idPrefix}-time`} className="block text-sm font-semibold">Unlock time</label>
          <input
            id={`${idPrefix}-time`} type="time" className={`${fieldCls} mt-1.5`} value={value.time}
            onChange={(e) => set({ time: e.target.value })}
          />
        </div>
      </div>
      <div>
        <label htmlFor={`${idPrefix}-tz`} className="block text-sm font-semibold">Time zone</label>
        <select id={`${idPrefix}-tz`} className={`${fieldCls} mt-1.5`} value={value.tz} onChange={(e) => set({ tz: e.target.value })}>
          {COMMON_ZONES.map((z) => <option key={z.id} value={z.id}>{z.label}</option>)}
          {deviceZone && <option value={deviceZone}>Your device ({deviceZone})</option>}
        </select>
        <p className="mt-1 text-sm text-ink-soft">India time is selected by default. The recipient sees the time in their own zone as well.</p>
      </div>
      {built.ok ? (
        <p role="status" className="rounded-2xl bg-[#f7f0e1] p-3 text-sm font-medium text-[#6b5420]">
          Opens {formatInZone(built.unlockAt.getTime(), value.tz)}
        </p>
      ) : (
        <p role="alert" className="rounded-2xl bg-[#fbeaec] p-3 text-sm font-medium text-[#780D1B]">{built.message}</p>
      )}
    </div>
  );
}

function Frame({ children }: { children: React.ReactNode }) {
  return <div className="relative mx-auto w-full max-w-[19rem] overflow-hidden rounded-[2rem] border-[6px] border-ink shadow-xl">{children}</div>;
}

function Choice({
  selected, onSelect, icon, title, text,
}: { selected: boolean; onSelect: () => void; icon: React.ReactNode; title: string; text: string }) {
  return (
    <button
      type="button" role="radio" aria-checked={selected} onClick={onSelect}
      className={`flex min-h-[5.5rem] flex-1 items-start gap-3 rounded-3xl border-2 p-4 text-left transition-colors ${
        selected ? "border-crimson bg-[#fbeaec]" : "border-ink/15 bg-white hover:border-ink/40"
      }`}
    >
      <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-full ${selected ? "bg-crimson text-white" : "bg-ink/8 text-ink"}`}>{icon}</span>
      <span>
        <span className="block text-base font-semibold">{title}</span>
        <span className="mt-0.5 block text-sm text-ink-soft">{text}</span>
      </span>
    </button>
  );
}

/** The final publishing choice: open now, or keep the contents locked until a date and time. */
export function PublishOptions({
  value, onChange, config, assetUrls,
}: {
  value: Delivery;
  onChange: (v: Delivery) => void;
  config: ExperienceConfig;
  assetUrls: Record<string, string>;
}) {
  const [tab, setTab] = useState<"before" | "after">("before");
  const [replay, setReplay] = useState(0);
  const lock = value.mode === "lock" ? value : null;
  const built = useMemo(() => (lock ? buildSchedule(lock) : null), [lock]);
  const p = config.theme.palette;

  return (
    <fieldset className="mt-8">
      <legend className="text-lg font-semibold">When should it open?</legend>
      <div role="radiogroup" aria-label="When should it open?" className="mt-3 flex flex-col gap-3 sm:flex-row">
        <Choice
          selected={value.mode === "now"} onSelect={() => onChange({ mode: "now" })}
          icon={<Rocket className="h-5 w-5" aria-hidden="true" />}
          title="Publish Immediately" text="The link opens the full greeting right away."
        />
        <Choice
          selected={value.mode === "lock"} onSelect={() => onChange(lock ?? defaultLock())}
          icon={<CalendarClock className="h-5 w-5" aria-hidden="true" />}
          title="Lock Greeting Until a Time & Date" text="Share the link now. It stays a countdown until the moment you choose."
        />
      </div>

      {lock && (
        <div className="mt-6 space-y-6 rounded-3xl border border-ink/15 bg-white/60 p-5">
          <p className="max-w-[60ch] text-sm text-ink-soft">
            Your greeting link is created the moment you publish, so you can send it today. Until the unlock time, anyone who opens
            it sees only a countdown. The greeting, its text and its photos stay locked on our server and are not sent to their
            device before then.
          </p>
          <ScheduleFields value={lock} onChange={onChange} />

          <div>
            <div role="tablist" aria-label="Recipient preview" className="flex gap-2">
              {(["before", "after"] as const).map((t) => (
                <button
                  key={t} type="button" role="tab" aria-selected={tab === t} onClick={() => setTab(t)}
                  className={`min-h-11 rounded-full px-5 text-sm font-semibold ${tab === t ? "bg-ink text-white" : "border border-ink/25 hover:bg-ink/5"}`}
                >
                  {t === "before" ? "Countdown preview" : "When it opens"}
                </button>
              ))}
            </div>

            <div className="mt-5">
              {tab === "before" ? (
                built?.ok ? (
                  <Frame>
                    <LockedScreen
                      key={built.unlockAt.toISOString()}
                      slug="preview" preview compact
                      unlockAt={built.unlockAt.toISOString()} serverNow={new Date().toISOString()} unlockTimezone={lock.tz}
                    />
                  </Frame>
                ) : (
                  <p className="text-sm text-ink-soft">Pick a valid future time to preview the countdown your recipient will see.</p>
                )
              ) : (
                <>
                  <Frame>
                    <div className="relative">
                      <ExperienceRenderer key={replay} config={config} assets={assetUrls} mode="embedded" forceLook={config.look ?? "cinematic"} />
                      <RevealCurtain key={`r${replay}`} mode="contain" accent={p.accent} accentSoft={p.accentSoft} />
                    </div>
                  </Frame>
                  <div className="mt-4 text-center">
                    <button type="button" onClick={() => setReplay((n) => n + 1)} className="min-h-11 rounded-full border border-ink/25 px-5 text-sm font-semibold hover:bg-ink/5">
                      Replay the reveal
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </fieldset>
  );
}
