"use client";

import { useEffect, useRef, useState } from "react";
import { Check, Copy, ExternalLink, Lock, Share2 } from "lucide-react";
import { formatInZone } from "@/lib/schedule/time";

type Props = {
  url: string;
  /** Private manage link. Omit when it isn't available (for example, on the manage page itself). */
  manageUrl?: string;
  /** False in demo mode: the greeting lives in server memory only. */
  persistent: boolean;
  recipientName?: string;
  /** UTC instant the greeting opens, when it is locked. */
  unlockAt?: string | null;
  unlockTimezone?: string | null;
};

function CopyRow({ id, label, value }: { id: string; label: string; value: string }) {
  const [copied, setCopied] = useState(false);
  const input = useRef<HTMLInputElement>(null);

  async function copy() {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      input.current?.select(); // clipboard blocked: select so the person can copy by hand
    }
  }

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-semibold">{label}</label>
      <div className="mt-1.5 flex gap-2">
        <input
          ref={input}
          id={id}
          readOnly
          value={value}
          onFocus={(e) => e.currentTarget.select()}
          className="min-w-0 flex-1 rounded-2xl border border-ink/20 bg-white px-4 py-3 text-base"
        />
        <button
          type="button"
          onClick={() => void copy()}
          className="inline-flex min-h-12 min-w-[7.5rem] items-center justify-center gap-2 rounded-full bg-crimson px-5 font-semibold text-white hover:bg-crimson-dark"
        >
          {copied ? <Check className="h-4 w-4" aria-hidden="true" /> : <Copy className="h-4 w-4" aria-hidden="true" />}
          {copied ? "Copied" : "Copy link"}
        </button>
      </div>
      <p role="status" className="sr-only">{copied ? "Link copied to clipboard" : ""}</p>
    </div>
  );
}

export function ShareCard({ url, manageUrl, persistent, recipientName, unlockAt, unlockTimezone }: Props) {
  const [canShare, setCanShare] = useState(false);
  useEffect(() => setCanShare(typeof navigator !== "undefined" && typeof navigator.share === "function"), []);

  const text = recipientName ? `I made a greeting for ${recipientName}:` : "I made you a greeting:";

  return (
    <div className="space-y-6">
      {!persistent && (
        <p role="note" className="rounded-2xl bg-[#f7f0e1] p-4 text-sm font-medium text-[#6b5420]">
          Demo mode: no database is connected, so this link only works on this server and stops working when it restarts. Connect Supabase to publish for real.
        </p>
      )}

      {unlockAt && Date.parse(unlockAt) > Date.now() && (
        <div role="note" className="flex gap-3 rounded-2xl bg-[#1a0a0e] p-4 text-[#f6efe2]">
          <Lock className="mt-0.5 h-5 w-5 shrink-0 text-[#e6cf94]" aria-hidden="true" />
          <p className="text-sm">
            <span className="font-semibold text-[#f3e3b3]">Locked until {formatInZone(Date.parse(unlockAt), unlockTimezone ?? undefined)}.</span>{" "}
            The link is ready to send now. Until then, whoever opens it sees only a countdown. The greeting itself stays on our server.
          </p>
        </div>
      )}

      <CopyRow id="share-url" label="Share this link" value={url} />

      <div className="flex flex-wrap gap-3">
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex min-h-12 items-center gap-2 rounded-full border border-ink/25 px-5 font-semibold hover:bg-ink/5"
        >
          <ExternalLink className="h-4 w-4" aria-hidden="true" />
          Open greeting
        </a>
        <a
          href={`https://wa.me/?text=${encodeURIComponent(`${text} ${url}`)}`}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex min-h-12 items-center rounded-full border border-ink/25 px-5 font-semibold hover:bg-ink/5"
        >
          Send on WhatsApp
        </a>
        {canShare && (
          <button
            type="button"
            onClick={() => void navigator.share({ title: "A greeting for you", text, url }).catch(() => undefined)}
            className="inline-flex min-h-12 items-center gap-2 rounded-full border border-ink/25 px-5 font-semibold hover:bg-ink/5"
          >
            <Share2 className="h-4 w-4" aria-hidden="true" />
            Share…
          </button>
        )}
      </div>

      {manageUrl && (
        <div className="rounded-3xl border border-ink/15 bg-white/60 p-5">
          <h2 className="text-lg font-semibold">Keep your private manage link</h2>
          <p className="mt-1 max-w-[56ch] text-sm text-ink-soft">
            It&apos;s the only way to delete this greeting later. Anyone who has it can manage the greeting, so don&apos;t share it. We also remember it in this browser.
          </p>
          <div className="mt-4">
            <CopyRow id="manage-url" label="Manage link" value={manageUrl} />
          </div>
        </div>
      )}
    </div>
  );
}
