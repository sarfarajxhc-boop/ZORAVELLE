"use client";

import { useId, useRef, useState } from "react";
import { Check, Copy, Sparkles } from "lucide-react";
import { writeMessage } from "@/app/(site)/create/[occasion]/actions";

const TONES = ["warm", "heartfelt", "funny", "formal", "short and sweet"] as const;
const LENGTHS = ["short", "medium", "long"] as const;
const MAX = 1200;
const selectCls = "w-full rounded-2xl border border-ink/20 bg-white px-4 py-3 text-base text-ink";

type Props = {
  occasion: string;
  customOccasionLabel?: string;
  recipientName: string;
  senderName: string;
  relationship?: string;
  /** What is in the message box right now. Never changed except by an explicit Insert, which only adds. */
  current: string;
  onInsert: (next: string) => void;
};

export function WriteWithAI({ occasion, customOccasionLabel, recipientName, senderName, relationship, current, onInsert }: Props) {
  const uid = useId();
  const [open, setOpen] = useState(false);
  const [idea, setIdea] = useState("");
  const [tone, setTone] = useState<(typeof TONES)[number]>("warm");
  const [length, setLength] = useState<(typeof LENGTHS)[number]>("medium");
  const [busy, setBusy] = useState(false);
  const [draft, setDraft] = useState<{ text: string; source: "ai" | "template" } | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const attempt = useRef(0);

  async function generate(again: boolean) {
    if (busy) return;
    setBusy(true);
    setNotice(null);
    attempt.current = again ? attempt.current + 1 : 0;
    try {
      const r = await writeMessage({
        occasion, customOccasionLabel: customOccasionLabel || undefined, recipientName, senderName,
        relationship: relationship || undefined, idea: idea || undefined, tone, length, attempt: attempt.current,
      });
      if (r.ok) setDraft({ text: r.text, source: r.source });
      else setNotice(r.message);
    } catch {
      setNotice("We couldn't reach the writer. Check your connection and try again.");
    } finally {
      setBusy(false);
    }
  }

  async function copy() {
    if (!draft) return;
    try {
      await navigator.clipboard.writeText(draft.text);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      setNotice("Copying isn't allowed here. Select the text and copy it by hand.");
    }
  }

  function insert() {
    if (!draft) return;
    const next = current.trim() ? `${current.replace(/\s+$/, "")}\n\n${draft.text}` : draft.text;
    if (next.length > MAX) {
      setNotice(`That would make your message longer than ${MAX} characters. Pick a shorter length or shorten your own text first. Your text was not changed.`);
      return;
    }
    onInsert(next);
    setNotice(current.trim() ? "Added below your text." : "Added to your message.");
  }

  const ready = recipientName.trim() && senderName.trim();

  return (
    <div className="rounded-3xl border border-gold/50 bg-white/70 p-5">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls={`${uid}-panel`}
        className="flex min-h-11 w-full items-center gap-2 text-left font-semibold text-crimson"
      >
        <Sparkles className="h-5 w-5" aria-hidden="true" />
        Write with AI
        <span className="ml-auto text-sm font-normal text-ink-soft">{open ? "Hide" : "Need help with the words?"}</span>
      </button>

      {open && (
        <div id={`${uid}-panel`} className="mt-4 space-y-4">
          <div>
            <label htmlFor={`${uid}-idea`} className="block text-sm font-semibold">What should it say? (optional)</label>
            <textarea
              id={`${uid}-idea`}
              className={`${selectCls} mt-1.5 min-h-20`}
              value={idea}
              onChange={(e) => setIdea(e.target.value)}
              maxLength={400}
              placeholder="For example: thank her for always being there, mention our Goa trip"
            />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <div>
              <label htmlFor={`${uid}-tone`} className="block text-sm font-semibold">Tone</label>
              <select id={`${uid}-tone`} className={`${selectCls} mt-1.5`} value={tone} onChange={(e) => setTone(e.target.value as (typeof TONES)[number])}>
                {TONES.map((t) => <option key={t} value={t}>{t[0]?.toUpperCase() + t.slice(1)}</option>)}
              </select>
            </div>
            <div>
              <label htmlFor={`${uid}-len`} className="block text-sm font-semibold">Length</label>
              <select id={`${uid}-len`} className={`${selectCls} mt-1.5`} value={length} onChange={(e) => setLength(e.target.value as (typeof LENGTHS)[number])}>
                {LENGTHS.map((t) => <option key={t} value={t}>{t[0]?.toUpperCase() + t.slice(1)}</option>)}
              </select>
            </div>
          </div>

          {!ready && <p className="text-sm text-ink-soft">Go back and fill in who it is for and your name first.</p>}

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              disabled={busy || !ready}
              onClick={() => void generate(false)}
              className="inline-flex min-h-12 items-center gap-2 rounded-full bg-crimson px-5 font-semibold text-white hover:bg-crimson-dark disabled:opacity-60"
            >
              <Sparkles className="h-4 w-4" aria-hidden="true" />
              {busy ? "Writing…" : draft ? "Start over" : "Generate"}
            </button>
            {draft && (
              <button
                type="button"
                disabled={busy}
                onClick={() => void generate(true)}
                className="inline-flex min-h-12 items-center rounded-full border border-ink/25 px-5 font-semibold hover:bg-ink/5 disabled:opacity-60"
              >
                Regenerate
              </button>
            )}
          </div>

          {draft && (
            <div>
              <p className="text-sm font-semibold">Suggestion</p>
              <div className="mt-1.5 whitespace-pre-wrap rounded-2xl border border-ink/15 bg-white p-4 text-base" data-testid="ai-draft">{draft.text}</div>
              <p className="mt-1 text-xs text-ink-soft">
                {draft.source === "ai"
                  ? "Written by an AI service. Read it and make it yours."
                  : `Quick draft from a built-in template (the AI writer isn't available right now).${idea.trim() ? " It can't use your idea, so add that in your own words after inserting." : ""} Read it and make it yours.`}
              </p>
              <div className="mt-3 flex flex-wrap gap-3">
                <button type="button" onClick={insert} className="inline-flex min-h-12 items-center rounded-full bg-ink px-5 font-semibold text-white hover:opacity-90">
                  {current.trim() ? "Insert below my text" : "Insert into message"}
                </button>
                <button type="button" onClick={() => void copy()} className="inline-flex min-h-12 items-center gap-2 rounded-full border border-ink/25 px-5 font-semibold hover:bg-ink/5">
                  {copied ? <Check className="h-4 w-4" aria-hidden="true" /> : <Copy className="h-4 w-4" aria-hidden="true" />}
                  {copied ? "Copied" : "Copy"}
                </button>
              </div>
            </div>
          )}

          <p role="status" className="text-sm text-ink-soft">{notice}</p>
          <p className="text-xs text-ink-soft">Your idea and the names above are sent to an AI service to write this. Don&apos;t include private details such as addresses or phone numbers.</p>
        </div>
      )}
    </div>
  );
}
