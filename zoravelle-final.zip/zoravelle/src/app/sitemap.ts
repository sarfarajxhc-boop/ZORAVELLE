import type { MetadataRoute } from "next";
import { OCCASIONS } from "@/lib/occasions/registry";

const site = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/+$/, "");

export default function sitemap(): MetadataRoute.Sitemap {
  const fixed = ["", "/occasions", "/create", "/about", "/privacy"].map((p) => ({ url: `${site}${p}` }));
  const occasions = OCCASIONS.map((o) => ({ url: `${site}/create/${o.id}` }));
  return [...fixed, ...occasions];
}
