import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { OccasionGrid } from "@/components/occasions/OccasionGrid";
import { OCCASIONS } from "@/lib/occasions/registry";

export const metadata: Metadata = { title: "Occasions" };

export default function OccasionsPage() {
  return (
    <main>
      <Container className="py-12 md:py-20">
        <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">All occasions</h1>
        <p className="mt-4 max-w-[44ch] text-lg text-ink-soft">
          {OCCASIONS.length} ways to say it. Pick one to start your greeting.
        </p>
        <div className="mt-10">
          <OccasionGrid />
        </div>
      </Container>
    </main>
  );
}
