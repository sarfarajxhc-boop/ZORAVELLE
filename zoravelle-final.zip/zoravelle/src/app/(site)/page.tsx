import { Hero } from "@/components/home/Hero";
import { CelebrateOccasions } from "@/components/home/CelebrateOccasions";
import { Features } from "@/components/home/Features";
import { Showcase } from "@/components/home/Showcase";
import { HowItWorks } from "@/components/home/HowItWorks";
import { CreatorVision } from "@/components/home/CreatorVision";
import { CtaBand } from "@/components/home/CtaBand";

export default function Home() {
  return (
    <main>
      <Hero />
      <CelebrateOccasions />
      <Features />
      <Showcase />
      <HowItWorks />
      <CreatorVision />
      <CtaBand />
    </main>
  );
}
