import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";

export const metadata: Metadata = { title: "Privacy" };

const sections: Array<{ title: string; body: React.ReactNode }> = [
  {
    title: "No accounts",
    body: (
      <p>
        You don&apos;t sign up to create a greeting, and the person you send it to doesn&apos;t sign up to
        open it. We don&apos;t ask for an email address or a phone number.
      </p>
    ),
  },
  {
    title: "What we store",
    body: (
      <ul className="list-disc space-y-1.5 pl-5">
        <li>The occasion, the recipient&apos;s name, your name, the greeting text and its look.</li>
        <li>
          Photos you add. Each photo is re-encoded on our server, which removes location and camera
          details embedded in the file.
        </li>
        <li>
          If you lock a greeting until a date and time: that moment (stored in UTC) and the time zone you
          picked, so the countdown can be shown correctly.
        </li>
        <li>A private edit code, stored only as a one-way hash, which lets you manage your greeting.</li>
        <li>
          A record of each AI attempt: which provider, whether it worked, and how long it took. It does not
          include what you wrote.
        </li>
        <li>Reports that people send about a greeting, if any.</li>
      </ul>
    ),
  },
  {
    title: "Who can see a greeting",
    body: (
      <p>
        Anyone who has the link. The link is long and random, and greeting pages ask search engines not to
        list them. Still, treat the link like a private message: if you post it publicly, anyone can open it.
        Don&apos;t put anything in a greeting that you wouldn&apos;t want its link-holders to see.
      </p>
    ),
  },
  {
    title: "Locked greetings",
    body: (
      <p>
        A locked greeting has a link straight away, but its message, photos and design stay on our server
        and are not sent to anyone until the unlock time, whatever the visitor&apos;s device clock says.
        Before then, the link shows only a countdown. If a visitor adds that countdown to their home
        screen, their device saves a shortcut to the link and a copy of the countdown page, which holds no
        part of the greeting.
      </p>
    ),
  },
  {
    title: "AI providers",
    body: (
      <p>
        When an AI provider is turned on, the text you enter (names, relationship, message, the idea you type
        into &quot;Write with AI&quot;, and style choices) is sent to that provider to write the greeting or
        the message. Photos are not sent. Some providers, including the free tier of Google Gemini, may use
        what they receive to improve their products, so don&apos;t put private details such as addresses or
        phone numbers in the idea box. Without a provider, a built-in template writes the text on our server
        and nothing is sent out.
      </p>
    ),
  },
  {
    title: "Managing and deleting",
    body: (
      <p>
        After you publish, you get a private manage link. Anyone who has it can delete the greeting and its
        photos, so keep it to yourself. We can&apos;t recover a lost manage link. Drafts that are never
        published are removed after 7 days. We may hide or delete a greeting that is reported and breaks our
        rules.
      </p>
    ),
  },
  {
    title: "Your device and our logs",
    body: (
      <ul className="list-disc space-y-1.5 pl-5">
        <li>
          Your browser remembers the greetings you made on this device, including their manage links, so you can
          find them again. While you are creating a greeting it also keeps an unfinished draft (your details,
          photos and its private edit code) for up to 7 days or until you publish. It also remembers whether
          you muted the background music and which look you picked. Clearing site data removes all of this.
        </li>
        <li>
          To limit abuse, we count requests per IP address. The counts are kept for up to a day. We use no
          advertising or analytics trackers, and visitors get no cookies.
        </li>
        <li>Our hosting and database providers keep their own operational logs.</li>
      </ul>
    ),
  },
];

export default function PrivacyPage() {
  return (
    <main>
      <Container className="max-w-3xl py-12 md:py-20">
        <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">Privacy</h1>
        <p className="mt-4 max-w-[60ch] text-ink-soft">
          This describes what ZORAVELLE does today, in plain words.
        </p>
        <div className="mt-10 space-y-10">
          {sections.map((s) => (
            <section key={s.title}>
              <h2 className="text-2xl font-semibold tracking-tight">{s.title}</h2>
              <div className="mt-3 max-w-[64ch] space-y-3 text-ink-soft">{s.body}</div>
            </section>
          ))}
        </div>
        <p className="mt-12 max-w-[64ch] rounded-2xl border border-ink/15 bg-white/60 p-5 text-sm text-ink-soft">
          Before you launch publicly, add your contact details and have this reviewed for the countries you
          serve. It is a description of the software, not legal advice.
        </p>
      </Container>
    </main>
  );
}
