import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { ManageClient } from "@/components/manage/ManageClient";

export const metadata: Metadata = {
  title: "Manage your greeting",
  robots: { index: false, follow: false },
  referrer: "no-referrer",
};

export default function ManagePage() {
  return (
    <main>
      <Container className="max-w-2xl py-12 md:py-20">
        <h1 className="text-4xl font-bold tracking-tight sm:text-5xl">Manage your greeting</h1>
        <div className="mt-8">
          <ManageClient />
        </div>
      </Container>
    </main>
  );
}
