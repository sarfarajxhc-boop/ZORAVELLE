"use server";

import { getStore, type OwnedExperience } from "@/lib/store";
import { getSiteUrl } from "@/lib/site-url";
import { parseCredentials } from "@/lib/greetings/credentials";
import { toUserError } from "@/lib/greetings/errors";
import { rateLimited } from "@/lib/greetings/guard";
import { parseSchedule } from "@/lib/greetings/schedule-input";

export type ManagedGreeting = OwnedExperience & { url: string; persistent: boolean };

export async function loadOwned(
  creds: unknown,
): Promise<{ ok: true; greeting: ManagedGreeting } | { ok: false; message: string }> {
  const c = parseCredentials(creds);
  if (!c) return { ok: false, message: "That manage link isn't valid." };
  const limited = await rateLimited("manage");
  if (limited) return { ok: false, message: limited };
  try {
    const store = getStore();
    const owned = await store.getOwned(c.id, c.token);
    return { ok: true, greeting: { ...owned, url: `${await getSiteUrl()}/w/${owned.slug}`, persistent: store.kind === "supabase" } };
  } catch (e) {
    const err = toUserError(e);
    return { ok: false, message: err.code === "forbidden" ? "That manage link isn't valid, or the greeting was already deleted." : err.message };
  }
}

export async function deleteOwned(creds: unknown): Promise<{ ok: true } | { ok: false; message: string }> {
  const c = parseCredentials(creds);
  if (!c) return { ok: false, message: "That manage link isn't valid." };
  const limited = await rateLimited("manage");
  if (limited) return { ok: false, message: limited };
  try {
    await getStore().deleteExperience(c.id, c.token);
    return { ok: true };
  } catch (e) {
    const err = toUserError(e);
    return { ok: false, message: err.code === "forbidden" ? "That manage link isn't valid, or the greeting was already deleted." : err.message };
  }
}

/**
 * Change when a still-locked greeting opens, or open it right now (`{ mode: "now" }`).
 * Refused once the greeting has already opened: it can't be locked again.
 */
export async function rescheduleOwned(
  creds: unknown,
  scheduleInput: unknown,
): Promise<{ ok: true; unlockAt: string | null; unlockTimezone: string | null } | { ok: false; message: string }> {
  const c = parseCredentials(creds);
  if (!c) return { ok: false, message: "That manage link isn't valid." };
  const schedule = parseSchedule(scheduleInput);
  if (schedule === "bad") return { ok: false, message: "That unlock time isn't valid. Pick it again." };
  const limited = await rateLimited("manage");
  if (limited) return { ok: false, message: limited };
  try {
    const r = await getStore().setSchedule(c.id, c.token, schedule);
    return { ok: true, ...r };
  } catch (e) {
    const err = toUserError(e);
    return { ok: false, message: err.code === "forbidden" ? "That manage link isn't valid, or the greeting was already deleted." : err.message };
  }
}
