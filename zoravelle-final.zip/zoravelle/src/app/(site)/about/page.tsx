import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { CREATOR } from "@/lib/creator";

export const metadata: Metadata = { title: "About" };

export default function AboutPage() {
  return (
    <main>
      <Container className="py-12 md:py-20">
        <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">About ZORAVELLE</h1>
        <div className="mt-8 max-w-[60ch] space-y-4 text-lg leading-relaxed text-ink-soft">
          <p>
            ZORAVELLE turns a wish into something a person can open, tap and play with. You pick an
            occasion, add a few details, and publish a greeting at its own link.
          </p>
          <p>
            It&apos;s free to use. Recipients never need an account, an app or a payment.
          </p>
          <p>
            AI helps write the words and choose the look, but it only picks from a fixed library of
            tested scenes. It doesn&apos;t write code that runs on anyone&apos;s phone.
          </p>
          <p>
            Created by{" "}
            <a
              href={CREATOR.website}
              target="_blank"
              rel="noopener noreferrer"
              className="font-semibold text-ink underline underline-offset-4"
            >
              {CREATOR.name}
            </a>
            , a student and content creator from West Bengal, India.
          </p>
        </div>
      </Container>
    </main>
  );
}
