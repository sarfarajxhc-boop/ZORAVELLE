import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Container } from "@/components/ui/Container";
import { CreateFlow } from "@/components/create/CreateFlow";
import { getOccasion, OCCASIONS } from "@/lib/occasions/registry";

export const dynamicParams = false;
// The generate action runs under this page's time budget; real AI calls can take 10 to 25 seconds.
export const maxDuration = 30;

export function generateStaticParams() {
  return OCCASIONS.map((o) => ({ occasion: o.id }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ occasion: string }>;
}): Promise<Metadata> {
  const { occasion } = await params;
  const def = getOccasion(occasion);
  return { title: def ? `Create a ${def.label} greeting` : "Create your greeting" };
}

export default async function CreateOccasionPage({
  params,
}: {
  params: Promise<{ occasion: string }>;
}) {
  const { occasion } = await params;
  const def = getOccasion(occasion);
  if (!def) notFound();

  // On Vercel the in-memory demo store can't work: requests land on different server copies.
  const needsDatabase =
    Boolean(process.env.VERCEL) && !(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);

  return (
    <main>
      <Container className="max-w-2xl py-10 md:py-16">
        <CreateFlow
          needsDatabase={needsDatabase}
          occasion={{
            id: def.id,
            label: def.label,
            title: def.title,
            blurb: def.blurb,
            icon: def.icon,
            isCustom: def.id === "custom",
            background: def.palette.background,
            text: def.palette.text,
          }}
        />
      </Container>
    </main>
  );
}
