"use server";

import { CreatorInputSchema, ExperienceConfigSchema, type ExperienceConfig } from "@/lib/experience/schema";
import { generateExperience } from "@/lib/ai/provider";
import { writeMessage as composeMessage, WriteInputSchema, type WriteResult } from "@/lib/ai/write-message";
import { contrastRatio } from "@/lib/experience/contrast";
import { getOccasion } from "@/lib/occasions/registry";
import { limit as hitLimit } from "@/lib/limiter";
import { clientIp } from "@/lib/request";
import { getStore } from "@/lib/store";
import { HOUR } from "@/lib/limits";
import { env } from "@/lib/env";
import { getSiteUrl } from "@/lib/site-url";
import { parseCredentials, type Credentials } from "@/lib/greetings/credentials";
import { toUserError } from "@/lib/greetings/errors";
import { rateLimited } from "@/lib/greetings/guard";
import { parseSchedule } from "@/lib/greetings/schedule-input";

const DAY = 24 * HOUR;

/** The pair the creator's browser keeps for one draft. The token is a bearer secret. */
export type DraftCredentials = Credentials;

export type GenerateResult =
  | {
      ok: true;
      config: ExperienceConfig;
      provider: string;
      usedFallback: boolean;
      draft: DraftCredentials;
      /** assetId -> short-lived image URL for the preview. */
      assetUrls: Record<string, string>;
    }
  | { ok: false; message: string; fieldErrors: Record<string, string>; draftExpired?: boolean };

const fail = (message: string, extra: Partial<Extract<GenerateResult, { ok: false }>> = {}): GenerateResult => ({
  ok: false, message, fieldErrors: {}, ...extra,
});

const messageOf = (config: ExperienceConfig): string | null => {
  const m = config.blocks.find((b) => b.type === "message");
  return m?.type === "message" ? m.body : null;
};

/**
 * "Write with AI": returns a suggested message for the creator to copy or insert. It never touches the
 * draft or the creator's own text. Falls back to an offline template on any AI problem.
 */
export async function writeMessage(
  input: unknown,
): Promise<({ ok: true } & WriteResult) | { ok: false; message: string }> {
  const parsed = WriteInputSchema.safeParse(input);
  if (!parsed.success) return { ok: false, message: parsed.error.issues[0]?.message ?? "Fill in the names first." };
  if (!getOccasion(parsed.data.occasion)) return { ok: false, message: "That occasion doesn't exist." };
  const limited = await rateLimited("write");
  if (limited) return { ok: false, message: limited };
  if (env.AI_PROVIDER !== "mock") {
    const global = await hitLimit("gen:all", env.AI_DAILY_GENERATION_CAP * 4, DAY);
    if (!global.ok) return { ok: false, message: "ZORAVELLE has reached its free daily AI limit. Please try again tomorrow." };
  }
  return { ok: true, ...(await composeMessage(parsed.data, env.AI_PROVIDER)) };
}

/**
 * Re-open a draft the creator's browser remembers: confirms the token, and returns the photos the draft
 * still owns with fresh short-lived URLs. Nothing else about the draft is returned.
 */
export async function resumeDraft(
  creds: unknown,
): Promise<
  | { ok: true; published: boolean; assetIds: string[]; assetUrls: Record<string, string> }
  | { ok: false; message: string }
> {
  const c = parseCredentials(creds);
  if (!c) return { ok: false, message: "That draft is no longer available." };
  const limited = await rateLimited("edit");
  if (limited) return { ok: false, message: limited };
  try {
    const store = getStore();
    const owned = await store.getOwned(c.id, c.token);
    if (owned.published) return { ok: true, published: true, assetIds: [], assetUrls: {} };
    const assetUrls = owned.assetIds.length > 0 ? await store.getAssetUrls(c.id, owned.assetIds) : {};
    return { ok: true, published: false, assetIds: owned.assetIds, assetUrls };
  } catch {
    return { ok: false, message: "That draft is no longer available." };
  }
}

/** Create a draft early (needed before photos can be uploaded). */
export async function startDraft(
  input: unknown,
): Promise<{ ok: true; draft: DraftCredentials } | { ok: false; message: string }> {
  const parsed = CreatorInputSchema.pick({ occasion: true, recipientName: true, senderName: true }).safeParse(input);
  if (!parsed.success || !getOccasion(parsed.data.occasion)) {
    return { ok: false, message: "Enter who the greeting is for and your name first." };
  }
  const limited = await rateLimited("draft");
  if (limited) return { ok: false, message: limited };
  try {
    const d = await getStore().createDraft(parsed.data);
    return { ok: true, draft: { id: d.id, token: d.editToken } };
  } catch (e) {
    return { ok: false, message: toUserError(e).message };
  }
}

/**
 * Generate (or regenerate) the greeting and save it to the draft.
 * Server-side source of truth: everything is re-validated here, and photo ids
 * the creator claims are checked against the photos this draft really owns.
 */
export async function generateGreeting(input: unknown, creds?: unknown): Promise<GenerateResult> {
  const parsed = CreatorInputSchema.safeParse(input);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      fieldErrors[key] ??= issue.message;
    }
    return { ok: false, message: "Some details need fixing.", fieldErrors };
  }

  const data = parsed.data;
  if (!getOccasion(data.occasion)) return fail("That occasion doesn't exist.");
  if (data.occasion === "custom" && !data.customOccasionLabel) {
    return { ok: false, message: "Some details need fixing.", fieldErrors: { customOccasionLabel: "Name your occasion." } };
  }

  // Quotas apply only when a real (paid) provider is configured. The offline template is free to run.
  if (env.AI_PROVIDER !== "mock") {
    const ip = await clientIp();
    const perUser = await hitLimit(`gen:${ip}`, env.AI_GENERATIONS_PER_HOUR, HOUR);
    if (!perUser.ok) {
      const minutes = Math.max(1, Math.ceil(perUser.retryAfterSec / 60));
      return fail(`You've reached the limit of ${env.AI_GENERATIONS_PER_HOUR} AI greetings per hour. Try again in ${minutes} minutes.`);
    }
    const global = await hitLimit("gen:all", env.AI_DAILY_GENERATION_CAP, DAY);
    if (!global.ok) return fail("ZORAVELLE has reached its free daily limit for AI greetings. Please try again tomorrow.");
  }

  const store = getStore();
  let draft: DraftCredentials;
  let ownedAssets = new Set<string>();

  try {
    if (creds !== undefined && creds !== null) {
      const supplied = parseCredentials(creds);
      if (!supplied) return fail("Your session expired. Please create the greeting again.", { draftExpired: true });
      const owned = await store.getOwned(supplied.id, supplied.token);
      if (owned.occasion !== data.occasion) return fail("This draft belongs to a different occasion.", { draftExpired: true });
      draft = supplied;
      ownedAssets = new Set(owned.assetIds);
    } else {
      const limited = await rateLimited("draft");
      if (limited) return fail(limited);
      const d = await store.createDraft({ occasion: data.occasion, recipientName: data.recipientName, senderName: data.senderName });
      draft = { id: d.id, token: d.editToken };
    }
  } catch (e) {
    const err = toUserError(e);
    return fail(err.message, { draftExpired: err.code === "forbidden" });
  }

  const assetIds = data.assetIds.filter((id) => ownedAssets.has(id));
  const started = Date.now();
  const result = await generateExperience({ ...data, assetIds }, env.AI_PROVIDER);
  const durationMs = Date.now() - started;

  if (!result.ok) {
    await store.recordGeneration(draft.id, { provider: env.AI_PROVIDER, status: "failed", durationMs });
    return fail("We couldn't create your greeting. Try again.");
  }

  try {
    await store.saveConfiguration(draft.id, draft.token, result.config, {
      message: messageOf(result.config),
      recipientName: data.recipientName,
      senderName: data.senderName,
    });
    await store.recordGeneration(draft.id, {
      provider: result.provider,
      status: result.usedFallback ? "fallback" : "success",
      durationMs,
    });
    const galleryIds = result.config.blocks.flatMap((b) => (b.type === "gallery" ? b.assetIds : []));
    const assetUrls = galleryIds.length > 0 ? await store.getAssetUrls(draft.id, galleryIds) : {};
    return { ok: true, config: result.config, provider: result.provider, usedFallback: result.usedFallback, draft, assetUrls };
  } catch (e) {
    return fail(toUserError(e).message);
  }
}

/** Save text edits made in the preview. The config is re-validated like any other untrusted input. */
export async function saveEdits(
  creds: unknown,
  config: unknown,
): Promise<{ ok: true; config: ExperienceConfig } | { ok: false; message: string; draftExpired?: boolean }> {
  const c = parseCredentials(creds);
  if (!c) return { ok: false, message: "Your session expired. Please create the greeting again.", draftExpired: true };
  const parsed = ExperienceConfigSchema.safeParse(config);
  if (!parsed.success) {
    return { ok: false, message: "Check the text: no field can be empty, and each has a maximum length." };
  }
  const pal = parsed.data.theme.palette;
  if (contrastRatio(pal.text, pal.background) < 4.5 || contrastRatio(pal.text, pal.surface) < 4.5) {
    return { ok: false, message: "Those colours are hard to read. Choose a different look." };
  }
  const limited = await rateLimited("edit");
  if (limited) return { ok: false, message: limited };
  try {
    await getStore().saveConfiguration(c.id, c.token, parsed.data, { message: messageOf(parsed.data) });
    return { ok: true, config: parsed.data };
  } catch (e) {
    const err = toUserError(e);
    return { ok: false, message: err.message, draftExpired: err.code === "forbidden" };
  }
}

export async function removePhoto(
  creds: unknown,
  assetId: unknown,
): Promise<{ ok: true } | { ok: false; message: string; draftExpired?: boolean }> {
  const c = parseCredentials(creds);
  if (!c || typeof assetId !== "string") return { ok: false, message: "Your session expired.", draftExpired: true };
  try {
    await getStore().removeAsset(c.id, c.token, assetId);
    return { ok: true };
  } catch (e) {
    const err = toUserError(e);
    return { ok: false, message: err.message, draftExpired: err.code === "forbidden" };
  }
}

export type PublishResult =
  | {
      ok: true; slug: string; url: string; manageUrl: string; persistent: boolean;
      /** UTC instant the greeting opens, or null when it is open now. */
      unlockAt: string | null; unlockTimezone: string | null;
    }
  | { ok: false; message: string; draftExpired?: boolean };

export async function publishGreeting(creds: unknown, scheduleInput?: unknown): Promise<PublishResult> {
  const c = parseCredentials(creds);
  if (!c) return { ok: false, message: "Your session expired. Please create the greeting again.", draftExpired: true };
  const schedule = parseSchedule(scheduleInput);
  if (schedule === "bad") return { ok: false, message: "That unlock time isn't valid. Pick it again." };
  const limited = await rateLimited("publish");
  if (limited) return { ok: false, message: limited };
  try {
    const store = getStore();
    const { slug, unlockAt, unlockTimezone } = await store.publish(c.id, c.token, schedule);
    const site = await getSiteUrl();
    return {
      ok: true,
      slug,
      unlockAt,
      unlockTimezone,
      url: `${site}/w/${slug}`,
      // The token rides in the URL fragment, which browsers never send to servers.
      manageUrl: `${site}/manage#${c.id}.${c.token}`,
      persistent: store.kind === "supabase",
    };
  } catch (e) {
    const err = toUserError(e);
    return { ok: false, message: err.message, draftExpired: err.code === "forbidden" };
  }
}
