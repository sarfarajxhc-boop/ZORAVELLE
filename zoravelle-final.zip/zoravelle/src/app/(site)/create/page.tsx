import type { Metadata } from "next";
import { Container } from "@/components/ui/Container";
import { OccasionGrid } from "@/components/occasions/OccasionGrid";

export const metadata: Metadata = { title: "Create your greeting" };

export default function CreatePage() {
  return (
    <main>
      <Container className="py-12 md:py-20">
        <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">What are you celebrating?</h1>
        <p className="mt-4 max-w-[44ch] text-lg text-ink-soft">
          Choose an occasion. You&apos;ll add names and a message next.
        </p>
        <div className="mt-10">
          <OccasionGrid />
        </div>
      </Container>
    </main>
  );
}
