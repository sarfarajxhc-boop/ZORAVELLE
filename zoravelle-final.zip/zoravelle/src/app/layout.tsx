import type { Metadata, Viewport } from "next";
import { Cormorant_Garamond, Dancing_Script, Inter } from "next/font/google";
import "./globals.css";
import { SiteMusic } from "@/components/site/SiteMusic";

const inter = Inter({ subsets: ["latin"], variable: "--font-inter", display: "swap" });
const cormorant = Cormorant_Garamond({ subsets: ["latin"], weight: ["500", "600", "700"], variable: "--font-cormorant", display: "swap" });
const dancing = Dancing_Script({ subsets: ["latin"], variable: "--font-dancing", display: "swap" });

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000";
const description = "Make every wish an experience. Create an animated, interactive greeting and share it with a link.";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: { default: "ZORAVELLE", template: "%s · ZORAVELLE" },
  description,
  openGraph: {
    type: "website",
    siteName: "ZORAVELLE",
    title: "ZORAVELLE",
    description,
    images: [{ url: "/og.png", width: 1200, height: 630, alt: "ZORAVELLE: make every wish an experience" }],
  },
  twitter: { card: "summary_large_image", title: "ZORAVELLE", description, images: ["/og.png"] },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#ffffff",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${inter.variable} ${cormorant.variable} ${dancing.variable}`}>
      <body className="min-h-dvh antialiased">{children}
        <SiteMusic />
      </body>
    </html>
  );
}
