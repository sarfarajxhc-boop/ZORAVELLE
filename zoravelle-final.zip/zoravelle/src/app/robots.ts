import type { MetadataRoute } from "next";

const site = (process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000").replace(/\/+$/, "");

// Greetings (/w/*) are kept out of search with noindex headers rather than a Disallow,
// because crawlers can only honour a noindex on pages they are allowed to fetch.
export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: "*", allow: "/", disallow: ["/admin", "/api/", "/manage", "/preview"] }],
    sitemap: `${site}/sitemap.xml`,
  };
}
