import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { ExperienceRenderer } from "@/components/experience/ExperienceRenderer";
import { mockProvider } from "@/lib/ai/provider";
import { ExperienceConfigSchema } from "@/lib/experience/schema";
import { getOccasion, OCCASIONS } from "@/lib/occasions/registry";

// QA route: renders every occasion with the built-in template. Not indexed.
// Development only: in production this route does not exist.
export const metadata: Metadata = { title: "Preview", robots: { index: false, follow: false } };
export const dynamicParams = false;

export function generateStaticParams() {
  return OCCASIONS.map((o) => ({ occasion: o.id }));
}

export default async function PreviewPage({ params }: { params: Promise<{ occasion: string }> }) {
  if (process.env.NODE_ENV === "production") notFound();
  const { occasion } = await params;
  if (!getOccasion(occasion)) notFound();

  const raw = await mockProvider.generate({
    occasion,
    recipientName: "Maya",
    senderName: "Arjun",
    assetIds: [],
  });
  const config = ExperienceConfigSchema.parse(raw);

  return (
    <main>
      <ExperienceRenderer config={config} mode="page" />
    </main>
  );
}
