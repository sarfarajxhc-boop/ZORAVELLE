import type { Metadata } from "next";
import { adminEnabled, isAdmin } from "@/lib/admin/session";
import { getStore } from "@/lib/store";
import { AdminLogin } from "@/components/admin/AdminLogin";
import { AdminPanel } from "@/components/admin/AdminPanel";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Admin", robots: { index: false, follow: false }, referrer: "no-referrer" };

export default async function AdminPage() {
  if (!adminEnabled()) {
    return (
      <main className="mx-auto max-w-xl p-6">
        <h1 className="text-2xl font-bold">Admin is off</h1>
        <p className="mt-2 text-sm">Set ADMIN_TOKEN to a random value of at least 24 characters to turn it on.</p>
      </main>
    );
  }
  if (!(await isAdmin())) return <AdminLogin />;

  const store = getStore();
  const [items, reports] = await Promise.all([store.listForAdmin({ limit: 200 }), store.listReports({ limit: 200 })]);
  return <AdminPanel items={items} reports={reports} persistent={store.kind === "supabase"} />;
}
