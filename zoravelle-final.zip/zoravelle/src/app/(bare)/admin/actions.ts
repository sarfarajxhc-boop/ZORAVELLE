"use server";

import { revalidatePath } from "next/cache";
import { ADMIN_COOKIE, SESSION_SECONDS, createSessionValue, isAdmin, passwordMatches } from "@/lib/admin/session";
import { limit } from "@/lib/limiter";
import { clientIp } from "@/lib/request";
import { getStore } from "@/lib/store";
import { isUuid } from "@/lib/store/shared";

export type ActionResult = { ok: true } | { ok: false; message: string };

const FIFTEEN_MIN = 15 * 60 * 1000;

export async function login(_prev: ActionResult | null, form: FormData): Promise<ActionResult> {
  // Counted before the comparison so guessing is throttled whether or not it's right.
  const r = await limit(`admin-login:${await clientIp()}`, 5, FIFTEEN_MIN);
  if (!r.ok) return { ok: false, message: "Too many attempts. Try again in a few minutes." };
  if (!passwordMatches(form.get("token"))) return { ok: false, message: "That isn't right." };

  const { cookies } = await import("next/headers");
  (await cookies()).set(ADMIN_COOKIE, createSessionValue(), {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/admin",
    maxAge: SESSION_SECONDS,
  });
  revalidatePath("/admin");
  return { ok: true };
}

export async function logout(): Promise<void> {
  const { cookies } = await import("next/headers");
  (await cookies()).delete({ name: ADMIN_COOKIE, path: "/admin" });
  revalidatePath("/admin");
}

/** Every moderation action re-checks the session itself: the page check alone isn't enough, actions are callable directly. */
async function guarded(fn: () => Promise<void>): Promise<ActionResult> {
  if (!(await isAdmin())) return { ok: false, message: "Sign in again." };
  try {
    await fn();
    revalidatePath("/admin");
    return { ok: true };
  } catch (e) {
    const code = (e as { code?: string }).code;
    return { ok: false, message: code === "not_found" ? "That greeting no longer exists." : "Something went wrong. Try again." };
  }
}

export async function hideGreeting(id: unknown, reason: unknown): Promise<ActionResult> {
  if (!isUuid(id)) return { ok: false, message: "Bad id." };
  const why = typeof reason === "string" ? reason.trim().slice(0, 200) : "";
  return guarded(async () => {
    await getStore().setHidden(id, true, why || "Hidden by admin");
    await getStore().resolveReports(id);
  });
}

export async function unhideGreeting(id: unknown): Promise<ActionResult> {
  if (!isUuid(id)) return { ok: false, message: "Bad id." };
  return guarded(() => getStore().setHidden(id, false));
}

export async function dismissReports(id: unknown): Promise<ActionResult> {
  if (!isUuid(id)) return { ok: false, message: "Bad id." };
  return guarded(() => getStore().resolveReports(id));
}

export async function deleteGreeting(id: unknown): Promise<ActionResult> {
  if (!isUuid(id)) return { ok: false, message: "Bad id." };
  return guarded(() => getStore().adminDelete(id));
}
