import Link from "next/link";

export const metadata = { title: "Greeting not found", robots: { index: false, follow: false } };

export default function GreetingNotFound() {
  return (
    <main className="grid min-h-dvh place-items-center bg-paper px-6 py-16 text-center text-ink">
      <div className="max-w-md">
        <h1 className="text-4xl font-bold tracking-tight">This greeting isn&apos;t available</h1>
        <p className="mt-4 text-lg text-ink-soft">
          The link may be mistyped, or the greeting was removed or has expired. Ask whoever sent it to share the link again.
        </p>
        <Link
          href="/create"
          className="mt-8 inline-flex min-h-12 items-center justify-center rounded-full bg-crimson px-6 font-semibold text-white hover:bg-crimson-dark"
        >
          Create your own greeting
        </Link>
      </div>
    </main>
  );
}
