"use client";

export default function GreetingError({ reset }: { error: Error; reset: () => void }) {
  return (
    <main className="grid min-h-dvh place-items-center bg-paper px-6 py-16 text-center text-ink">
      <div className="max-w-md">
        <h1 className="text-4xl font-bold tracking-tight">We couldn&apos;t load this greeting</h1>
        <p className="mt-4 text-lg text-ink-soft">That was our problem, not yours. Check your connection and try again.</p>
        <button
          type="button"
          onClick={reset}
          className="mt-8 inline-flex min-h-12 items-center justify-center rounded-full bg-crimson px-6 font-semibold text-white hover:bg-crimson-dark"
        >
          Try again
        </button>
      </div>
    </main>
  );
}
