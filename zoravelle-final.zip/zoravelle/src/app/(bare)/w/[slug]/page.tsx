import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ExperienceRenderer } from "@/components/experience/ExperienceRenderer";
import { loadViewerState } from "@/lib/greetings/load-viewer";
import { ReportButton } from "@/components/greeting/ReportButton";
import { LockedScreen } from "@/components/greeting/LockedScreen";
import { RevealOnOpen } from "@/components/greeting/RevealOnOpen";

// Always rendered per request: photo URLs are short-lived, expiry/takedown must apply immediately,
// and the lock is decided by the server clock on every request.
export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string }> };

/**
 * Metadata never contains greeting content. A locked greeting gets a generic title and, so the countdown
 * can be added to a home screen, a manifest and iOS home-screen tags. The manifest is generic too.
 */
export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const state = await loadViewerState(slug);
  const base: Metadata = {
    title: "A greeting for you",
    description: "Someone made you an interactive greeting. Open it to see.",
    robots: { index: false, follow: false },
    referrer: "no-referrer",
  };
  if (state.kind !== "locked") return base;
  return {
    ...base,
    title: "A greeting is waiting for you",
    manifest: `/w/${slug}/manifest.webmanifest`,
    icons: { apple: "/icons/apple-touch-icon.png" },
    appleWebApp: { capable: true, title: "Greeting", statusBarStyle: "black-translucent" },
    other: { "mobile-web-app-capable": "yes", "theme-color": "#070506" },
  };
}

export default async function GreetingPage({ params }: Params) {
  const { slug } = await params;
  const state = await loadViewerState(slug);
  if (state.kind === "missing") notFound();

  if (state.kind === "locked") {
    return (
      <main>
        <LockedScreen
          slug={slug}
          unlockAt={state.lock.unlockAt}
          serverNow={state.lock.serverNow}
          unlockTimezone={state.lock.unlockTimezone}
        />
      </main>
    );
  }

  const { config, assets } = state.data;
  const p = config.theme.palette;
  return (
    <main>
      <RevealOnOpen slug={slug} accent={p.accent} accentSoft={p.accentSoft} />
      <ExperienceRenderer
        config={config}
        assets={assets}
        mode="page"
        footer={
          <div className="pb-4 pt-10">
            <p className="text-center text-sm opacity-70">
              Made with{" "}
              <Link href="/" className="font-semibold underline underline-offset-4">
                ZORAVELLE
              </Link>
              . Create one for someone you care about.
            </p>
            <ReportButton slug={slug} />
          </div>
        }
      />
    </main>
  );
}
