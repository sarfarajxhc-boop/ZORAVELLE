import { getStore } from "@/lib/store";
import { isSlug } from "@/lib/store/shared";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Web app manifest for ONE greeting's countdown shortcut. It is generic on purpose: it names the
 * greeting only by its link, never by its occasion, names or text, so installing the shortcut (or a
 * crawler reading this file) learns nothing about a locked greeting.
 */
export async function GET(_req: Request, ctx: { params: Promise<{ slug: string }> }): Promise<Response> {
  const { slug } = await ctx.params;
  if (!isSlug(slug)) return new Response("Not found", { status: 404 });
  const view = await getStore().getViewState(slug);
  if (view.kind === "missing") return new Response("Not found", { status: 404 });

  const manifest = {
    id: `/w/${slug}`,
    name: "ZORAVELLE · A greeting is waiting",
    short_name: "Greeting",
    description: "Opens your ZORAVELLE greeting. It shows a countdown until it unlocks.",
    start_url: `/w/${slug}?source=homescreen`,
    scope: `/w/${slug}`,
    display: "standalone",
    orientation: "portrait",
    background_color: "#070506",
    theme_color: "#070506",
    lang: "en",
    icons: [
      { src: "/icons/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icons/icon-512.png", sizes: "512x512", type: "image/png", purpose: "any" },
      { src: "/icons/maskable-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
  return new Response(JSON.stringify(manifest), {
    headers: { "content-type": "application/manifest+json; charset=utf-8", "cache-control": "no-store" },
  });
}
