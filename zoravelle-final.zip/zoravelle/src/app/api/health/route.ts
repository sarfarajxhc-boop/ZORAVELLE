import { getStore } from "@/lib/store";
import { env } from "@/lib/env";
import { getAdminClient } from "@/lib/store/supabase-clients";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/**
 * Open /api/health after deploying to see what is connected.
 * Reports only yes/no and mode names, never keys or values.
 */
/** Does this table/column exist? A missing one means a migration has not been run yet. */
async function exists(table: string, column: string): Promise<boolean> {
  const db = getAdminClient();
  if (!db) return false;
  try {
    const { error } = await db.from(table).select(column).limit(1);
    return !error;
  } catch {
    return false;
  }
}

export async function GET(): Promise<Response> {
  const persistent = getStore().kind === "supabase";
  const migrations = persistent
    ? {
        "0001_init": await exists("experiences", "id"),
        "0002_reports_and_limits": await exists("reports", "id"),
        "0003_moment_delivery": await exists("experiences", "unlock_at"),
      }
    : undefined;
  const missing = migrations ? Object.entries(migrations).filter(([, ok]) => !ok).map(([k]) => k) : [];
  return Response.json(
    {
      ok: true,
      database: persistent ? "supabase" : "demo-memory",
      databaseReady: persistent && missing.length === 0,
      migrations,
      aiProvider: env.AI_PROVIDER,
      adminEnabled: (env.ADMIN_TOKEN?.length ?? 0) >= 24,
      cronEnabled: (env.CRON_SECRET?.length ?? 0) >= 16,
      hint: !persistent
        ? "No database: greetings and photos will not be reliable on Vercel. Connect Supabase."
        : missing.length > 0
          ? `Run these SQL files in the Supabase SQL editor, in order: ${missing.join(", ")}.`
          : undefined,
    },
    { headers: { "cache-control": "no-store" } },
  );
}
