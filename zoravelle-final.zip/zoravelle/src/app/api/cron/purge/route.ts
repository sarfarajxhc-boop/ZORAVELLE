import { createHmac, timingSafeEqual } from "node:crypto";
import { env } from "@/lib/env";
import { getStore } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const same = (a: string, b: string) =>
  timingSafeEqual(createHmac("sha256", "c").update(a).digest(), createHmac("sha256", "c").update(b).digest());

/**
 * Scheduled purge of expired greetings and drafts older than 7 days.
 * Vercel Cron sends `Authorization: Bearer $CRON_SECRET` when CRON_SECRET is set.
 * With no (or a too-short) secret the endpoint is disabled.
 */
export async function GET(req: Request): Promise<Response> {
  const secret = env.CRON_SECRET;
  if (!secret || secret.length < 16) return new Response("Not found", { status: 404 });
  if (!same(req.headers.get("authorization") ?? "", `Bearer ${secret}`)) return new Response("Unauthorized", { status: 401 });

  try {
    const removed = await getStore().purgeExpired();
    return Response.json({ removed });
  } catch {
    return Response.json({ error: "purge failed" }, { status: 500 });
  }
}
