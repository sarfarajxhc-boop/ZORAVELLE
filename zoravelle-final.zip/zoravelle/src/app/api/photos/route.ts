import { ImageError, MAX_UPLOAD_BYTES, processImage } from "@/lib/assets/process-image";
import { LIMITS } from "@/lib/limits";
import { limit as hitLimit } from "@/lib/limiter";
import { ipFromHeaders } from "@/lib/request";
import { parseCredentials } from "@/lib/greetings/credentials";
import { getStore, StoreError } from "@/lib/store";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 30;

// Multipart overhead allowance on top of the photo itself.
const MAX_BODY_BYTES = MAX_UPLOAD_BYTES + 512 * 1024;

const json = (body: unknown, status = 200, headers: Record<string, string> = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store", ...headers },
  });

/**
 * POST multipart: fields `id` and `file`, header `x-edit-token`.
 * The token is a header (not a cookie), so there is no ambient authority to
 * forge from another site, and no CORS headers are sent, so other origins
 * cannot call this from a browser.
 * Order matters: cheap checks first, token check before any image decoding, so
 * an unauthenticated caller can't spend CPU.
 */
export async function POST(req: Request): Promise<Response> {
  const { max, windowMs } = LIMITS.upload;
  const limit = await hitLimit(`upload:${ipFromHeaders(req.headers)}`, max, windowMs);
  if (!limit.ok) {
    return json({ error: "You're uploading a lot of photos. Try again later." }, 429, { "retry-after": String(limit.retryAfterSec) });
  }

  const length = Number(req.headers.get("content-length"));
  if (!Number.isFinite(length) || length <= 0) return json({ error: "Upload failed. Try again." }, 411);
  if (length > MAX_BODY_BYTES) return json({ error: "That photo is larger than 5 MB. Choose a smaller one." }, 413);

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return json({ error: "Upload failed. Try again." }, 400);
  }
  const id = form.get("id");
  const file = form.get("file");
  const creds = parseCredentials({ id, token: req.headers.get("x-edit-token") });
  if (!creds || !(file instanceof File)) return json({ error: "Upload failed. Try again." }, 400);
  if (file.size > MAX_UPLOAD_BYTES) return json({ error: "That photo is larger than 5 MB. Choose a smaller one." }, 413);

  const store = getStore();
  try {
    await store.getOwned(creds.id, creds.token); // authorize before decoding anything

    let image;
    try {
      image = await processImage(new Uint8Array(await file.arrayBuffer()));
    } catch (e) {
      if (e instanceof ImageError) return json({ error: e.message, code: e.code }, e.code === "too_large" ? 413 : 400);
      throw e;
    }

    const asset = await store.addAsset(creds.id, creds.token, { data: image.data });
    const urls = await store.getAssetUrls(creds.id, [asset.id]);
    return json({ assetId: asset.id, url: urls[asset.id] ?? null });
  } catch (e) {
    if (e instanceof StoreError) {
      const status = { forbidden: 403, limit: 409, invalid: 400, not_found: 404, unavailable: 503 }[e.code];
      // Without a database every server instance has its own memory, so a draft made by one instance is
      // unknown to the next one: say that plainly instead of blaming the person's session.
      if (e.code === "forbidden" && store.kind !== "supabase" && process.env.VERCEL) {
        return json({ error: "Photo storage isn't set up on this site yet. The site owner needs to connect Supabase.", code: "no_database" }, 503);
      }
      const message = e.code === "forbidden" ? "Your session expired. Reload the page and start again." : e.message;
      return json({ error: message, code: e.code }, status);
    }
    console.error(`[photos] unexpected ${e instanceof Error ? e.name : typeof e}`);
    return json({ error: "Something went wrong. Please try again." }, 500);
  }
}
