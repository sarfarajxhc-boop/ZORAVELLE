import { limit as hitLimit } from "@/lib/limiter";
import { ipFromHeaders } from "@/lib/request";
import { getStore, StoreError } from "@/lib/store";
import { isSlug } from "@/lib/store/shared";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

/** Public: anyone who can open a greeting can report it. Limited per IP; reports never hide anything by themselves. */
export async function POST(req: Request): Promise<Response> {
  const r = await hitLimit(`report:${ipFromHeaders(req.headers)}`, 5, 60 * 60 * 1000);
  if (!r.ok) return json({ error: "You've sent several reports already. Try again later." }, 429);

  const length = Number(req.headers.get("content-length") ?? "0");
  if (length > 4096) return json({ error: "That report is too long." }, 413);

  let body: unknown;
  try {
    body = JSON.parse(await req.text());
  } catch {
    return json({ error: "Report failed. Try again." }, 400);
  }
  const { slug, reason, details } = (typeof body === "object" && body !== null ? body : {}) as Record<string, unknown>;
  if (!isSlug(slug)) return json({ error: "That greeting isn't available." }, 404);

  try {
    await getStore().addReport(slug, reason as never, details as never);
    return json({ ok: true });
  } catch (e) {
    if (e instanceof StoreError) {
      const status = { invalid: 400, not_found: 404, unavailable: 503, forbidden: 403, limit: 409 }[e.code];
      return json({ error: e.message }, status);
    }
    return json({ error: "Something went wrong. Please try again." }, 500);
  }
}
