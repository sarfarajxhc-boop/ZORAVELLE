import { limit as hitLimit } from "@/lib/limiter";
import { ipFromHeaders } from "@/lib/request";
import { getStore } from "@/lib/store";
import { isSlug } from "@/lib/store/shared";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { "content-type": "application/json", "cache-control": "no-store, max-age=0" },
  });

/**
 * Public lock status for the countdown. It answers ONLY "locked / open / missing" plus the unlock
 * instant and the server clock. It never returns greeting content, names or photos, so it is safe to
 * call from anywhere. The browser re-asks it when the timer reaches zero, so the server, not the
 * device clock, decides when the greeting opens.
 */
export async function GET(req: Request, ctx: { params: Promise<{ slug: string }> }): Promise<Response> {
  const { slug } = await ctx.params;
  if (!isSlug(slug)) return json({ state: "missing", serverNow: new Date().toISOString() }, 404);

  const r = await hitLimit(`status:${ipFromHeaders(req.headers)}`, 180, 60 * 1000);
  if (!r.ok) return json({ error: "Too many checks. Wait a moment." }, 429);

  try {
    const view = await getStore().getViewState(slug);
    const serverNow = new Date().toISOString();
    if (view.kind === "locked") {
      return json({ state: "locked", unlockAt: view.unlockAt, unlockTimezone: view.unlockTimezone, serverNow });
    }
    if (view.kind === "open") return json({ state: "open", serverNow });
    return json({ state: "missing", serverNow }, 404);
  } catch {
    return json({ error: "Couldn't check right now." }, 503);
  }
}
