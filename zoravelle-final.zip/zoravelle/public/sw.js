/* ZORAVELLE countdown service worker.
 *
 * What it does, and nothing more:
 *  - lets the countdown screen of a LOCKED greeting open when the phone is offline;
 *  - makes the site installable ("Add to Home Screen") on browsers that require a service worker.
 *
 * What it never does: store an unlocked greeting. A greeting page is cached only while the page says it
 * is still locked (it carries no private content then), and the cached copy is deleted the moment the
 * server answers with an open greeting. The lock status API is never cached.
 */
const CACHE = "zv-countdown-v1";
const SHELL = ["/offline.html", "/icons/icon-192.png"];
const GREETING = /^\/w\/[0-9A-Za-z]{10}\/?$/;

self.addEventListener("install", (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

const keyFor = (url) => url.origin + url.pathname.replace(/\/$/, ""); // ignore ?source=homescreen etc.

self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Never touch the status API or any other API: the countdown must ask the real server.
  if (url.pathname.startsWith("/api/")) return;

  // Hashed build assets never change: keep them so a cached countdown page can still run offline.
  if (url.pathname.startsWith("/_next/static/")) {
    event.respondWith(
      caches.open(CACHE).then(async (cache) => {
        const hit = await cache.match(req);
        if (hit) return hit;
        const res = await fetch(req);
        if (res.ok) cache.put(req, res.clone());
        return res;
      }),
    );
    return;
  }

  // The greeting page itself: network first; remember it only while it is locked.
  if (req.mode === "navigate" && GREETING.test(url.pathname)) {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE);
      const key = keyFor(url);
      try {
        const res = await fetch(req);
        if (res.ok) {
          const html = await res.clone().text();
          if (html.includes('data-zv-state="locked"')) await cache.put(key, new Response(html, { headers: { "content-type": "text/html; charset=utf-8" } }));
          else await cache.delete(key); // opened (or gone): never keep it
        } else {
          await cache.delete(key);
        }
        return res;
      } catch {
        return (await cache.match(key)) || (await cache.match("/offline.html")) || Response.error();
      }
    })());
  }
});
