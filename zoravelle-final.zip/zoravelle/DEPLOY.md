# Deploying ZORAVELLE (GitHub → Vercel + Supabase)

You need three free accounts: GitHub, Vercel and Supabase. No terminal is required. Follow the steps in order.

> Nothing here has been run against a live Vercel or Supabase account yet. Treat the first deploy as the real test, use the smoke test in section 5, and open `/api/health` (section 4) any time something looks wrong.

## 1. Put the project on GitHub

1. Unzip the project on your computer. You should see `package.json`, `src`, `public`, `supabase` and others directly inside the folder (not inside another folder).
2. On github.com click **New repository**, name it `zoravelle`, keep it **Private**, and create it (leave "Add a README" off).
3. GitHub's web upload accepts at most **100 files at a time**, and this project has about 170 files, so upload in three batches. Turn on "show hidden files" on your computer first, because `.gitignore` and `.env.example` start with a dot and must be included. Never upload a `.env` or `.env.local` file (the project has none).
   - **Batch 1.** On the empty repository page click **uploading an existing file**. Drag in everything inside the unzipped folder **except the `src` folder** (so: `public`, `supabase`, `tests`, and the loose files such as `package.json`, `README.md`, `.gitignore`). About 53 files. Click **Commit changes**.
   - **Make the `src` folder.** In the repository click **Add file → Create new file**. In the name box type `src/.keep` (typing the slash creates the folder). Click **Commit changes**.
   - **Batch 2.** Click the new `src` folder, then **Add file → Upload files**. From your unzipped `src` folder drag in the `app` and `components` folders (about 73 files). Commit.
   - **Batch 3.** Open the `src` folder again, **Add file → Upload files**, and drag in the `lib` folder (about 41 files). Commit.
   - Check the result: the repository should show `public`, `src`, `supabase`, `tests`, `package.json` and the other loose files at the top, and `src` should contain `app`, `components` and `lib`. The harmless `.keep` file can stay.

## 2. Create the Supabase database

1. Go to supabase.com, click **Start your project**, sign in with GitHub.
2. **New project**. Name `zoravelle`, choose a database password (save it), pick the region closest to your users (India: Mumbai, `ap-south-1`), **Create new project**. Wait about 2 minutes.
3. Left menu **SQL Editor** → **New query**. Run these three files **in this order**, each one as its own query (open the file in this project, copy everything, paste, **Run**; each must say "Success"):
   1. `supabase/migrations/0001_init.sql`
   2. `supabase/migrations/0002_reports_and_limits.sql`
   3. `supabase/migrations/0003_moment_delivery.sql` (needed for "Lock greeting until a time")
4. Left menu gear icon **Project Settings** → **API Keys** (or **API**). Copy three things:
   - **Project URL** (looks like `https://abcd.supabase.co`)
   - the **anon / publishable** key
   - the **service_role / secret** key. Keep this one private: never paste it in chat, in code, in a screenshot or in GitHub.

## 3. Deploy on Vercel

1. Go to vercel.com, sign in with GitHub, **Add New… → Project**, import the `zoravelle` repository. Framework preset: **Next.js** (detected automatically). Do not change the build settings.
2. Before clicking Deploy, open **Environment Variables** and add (apply to Production):

| Name | Value |
| --- | --- |
| `NEXT_PUBLIC_SITE_URL` | Your final URL, no trailing slash. Use the `https://….vercel.app` address Vercel shows for the project, or your own domain. If you don't know it yet, add it after the first deploy and redeploy |
| `NEXT_PUBLIC_SUPABASE_URL` | Project URL from step 2.4 |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | anon key from step 2.4 |
| `SUPABASE_SERVICE_ROLE_KEY` | service_role key from step 2.4. Server only. Never give it a `NEXT_PUBLIC_` prefix |
| `ADMIN_TOKEN` | a long random password, 24+ characters (needed to use `/admin`) |
| `CRON_SECRET` | a random string, 16+ characters (needed for the daily clean-up job) |
| `AI_PROVIDER` | `mock` to start (built-in template writer, free, no key). Later: `gemini`, `anthropic` or `openai` |
| `GEMINI_API_KEY`, `GEMINI_MODEL` | only if `AI_PROVIDER=gemini`. Get a free key at aistudio.google.com and set a model your key can use (the built-in default `gemini-2.5-flash` is unverified) |
| `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL`, `OPENAI_API_KEY`, `OPENAI_MODEL` | only for those providers |
| `AI_GENERATIONS_PER_HOUR`, `AI_DAILY_GENERATION_CAP` | optional quotas for real AI (defaults 5 and 500) |

   To make random values you can use any password generator (a long string of letters and numbers is fine).
3. Click **Deploy**. When it finishes, open the site.
4. If you changed any variable after the first deploy: **Deployments** → the three dots on the latest one → **Redeploy**. Variables only apply after a redeploy.

`vercel.json` schedules the daily purge job (03:17 UTC). Cron jobs need a Vercel plan that allows them; the site works without it.

Free AI note: on Gemini's free tier, Google may use what is sent to improve its products. The app warns users not to type private details in the AI box and `/privacy` says so.

## 4. Check that everything is connected

Open `https://YOUR-SITE/api/health`. It shows only yes/no and mode names, never keys.

- `"database": "supabase"` and `"databaseReady": true` mean it is ready.
- `"database": "demo-memory"`: a Supabase variable is missing or misspelled. Photos and links will **not** be reliable until this is fixed (each Vercel server has its own memory, which is the usual cause of "session expired" errors when uploading photos).
- `"databaseReady": false` with a `migrations` list: run the SQL files marked `false` (section 2.3), then reload.
- `adminEnabled` / `cronEnabled` should be `true` once `ADMIN_TOKEN` and `CRON_SECRET` are long enough.

## 5. Smoke test (about 15 minutes, on a phone and a desktop)

- [ ] Home loads; fonts, animations and the music button (bottom left) look right; no errors in the browser console.
- [ ] Music: it starts after your first tap, the button mutes it, and after muting it stays quiet on the next visit.
- [ ] Create a greeting for 3 occasions, one with 2 photos (try a phone camera photo). Upload progress and the photo preview appear.
- [ ] Refresh in the middle of creating: "Continue where you left off?" appears and restores your details, photos and preview.
- [ ] Customise the look: change Look, falling effect and photo layout; the preview changes immediately.
- [ ] **Publish Immediately**: open the link in a private window and on another device; the photos show.
- [ ] **Lock until a time**: choose a time 2–3 minutes ahead. Open the link: countdown only (view the page source: no message or names). Wait: it unlocks by itself and plays the reveal. Open the same link on another device.
- [ ] On the locked countdown (Android Chrome): tap **Add the Timer to My Screen**, add it, close the browser, open the icon: the countdown continues and reveals the same greeting at zero. On iPhone Safari the button shows the Share → Add to Home Screen steps.
- [ ] Open the manage link, change the unlock time or open now; delete a greeting and confirm its link shows "not found".
- [ ] Write with AI: generate, regenerate, insert (your own text stays), copy.
- [ ] Report a greeting, sign in at `/admin`, find the report, hide the greeting, confirm its link stops opening.
- [ ] `/preview/birthday` is a 404. `/admin` without a token shows only the sign-in form.
- [ ] Share a link in WhatsApp and confirm the preview image appears.
- [ ] Optional: trigger the clean-up once with `curl -H "Authorization: Bearer YOUR_CRON_SECRET" https://YOUR-SITE/api/cron/purge`.

## 6. Before opening to the public

- Replace the background music with a track you hold the licence for, or confirm the licence of the one included (`public/audio/romantic-piano.mp3`).
- Add contact details to `/privacy` and `/about` and have the privacy text reviewed for the countries you serve.
- Decide a retention period (greetings never expire by default).
- Watch your AI provider spend; keep `AI_DAILY_GENERATION_CAP` low at first.
- Keep the Supabase project on a plan with backups if the greetings matter.
- Remember: never share the `service_role` key.

## Troubleshooting

| Problem | Likely cause and fix |
| --- | --- |
| Photo upload says the session expired, or links stop working | No database connected. Check `/api/health`, add the Supabase variables, redeploy |
| "Lock greeting" fails or `/api/health` lists `0003_moment_delivery` | Run `supabase/migrations/0003_moment_delivery.sql` |
| Share links show `localhost` | Set `NEXT_PUBLIC_SITE_URL` and redeploy |
| `/admin` says it is switched off | `ADMIN_TOKEN` is empty or shorter than 24 characters |
| Build fails on Vercel | Open the failed deployment's log and send me the first red error line |
| Music doesn't start | Browsers need a tap first; use the button at the bottom left. If the button is missing, the audio file failed to load |
