// Admin session, report endpoint, cron endpoint. In-memory store, no network.
//   npm run test:admin
process.env.ADMIN_TOKEN = "t".repeat(32);
process.env.CRON_SECRET = "c".repeat(24);

import { check, summary } from "./harness";

async function main() {
  const session = await import("../src/lib/admin/session");
  const { POST: report } = await import("../src/app/api/report/route");
  const { GET: purge } = await import("../src/app/api/cron/purge/route");
  const { getStore } = await import("../src/lib/store");
  const { mockProvider } = await import("../src/lib/ai/providers/mock");
  const { ExperienceConfigSchema } = await import("../src/lib/experience/schema");
  const { resetRateLimits } = await import("../src/lib/rate-limit");

  // ---- admin session
  const now = Date.UTC(2026, 0, 1);
  const good = session.createSessionValue(now);
  check("admin is enabled with a long token", session.adminEnabled());
  check("correct password accepted", session.passwordMatches("t".repeat(32)));
  check("wrong password rejected", !session.passwordMatches("t".repeat(31) + "x"));
  check("empty / non-string password rejected", !session.passwordMatches("") && !session.passwordMatches(undefined) && !session.passwordMatches(123));
  check("fresh session verifies", session.verifySessionValue(good, now + 1000));
  check("session expires after 8 hours", !session.verifySessionValue(good, now + (8 * 3600 + 1) * 1000));
  const [exp, sig] = good.split(".") as [string, string];
  check("tampered expiry is rejected", !session.verifySessionValue(`${Number(exp) + 99999}.${sig}`, now));
  check("tampered signature is rejected", !session.verifySessionValue(`${exp}.${sig.slice(0, -2)}AA`, now));
  check("garbage cookies are rejected", ["", "x", "1.2.3", "abc.def", `${exp}.`, `.${sig}`].every((v) => !session.verifySessionValue(v, now)));
  check("missing cookie is rejected", !session.verifySessionValue(undefined, now) && !session.verifySessionValue(null, now));

  // ---- report endpoint
  const store = getStore();
  const config = ExperienceConfigSchema.parse(await mockProvider.generate({ occasion: "birthday", recipientName: "Maya", senderName: "Arjun", assetIds: [] }));
  const d = await store.createDraft({ occasion: "birthday", recipientName: "Maya", senderName: "Arjun" });
  await store.saveConfiguration(d.id, d.editToken, config);
  await store.publish(d.id, d.editToken);

  const post = (body: unknown, ip = "203.0.113.5", raw?: string) => {
    const text = raw ?? JSON.stringify(body);
    return report(new Request("http://localhost/api/report", {
      method: "POST",
      headers: { "content-type": "application/json", "content-length": String(Buffer.byteLength(text)), "x-forwarded-for": ip },
      body: text,
    }));
  };

  resetRateLimits();
  check("report on a published greeting succeeds", (await post({ slug: d.slug, reason: "scam", details: "spam" })).status === 200);
  check("the report reaches the admin list", (await store.listReports()).some((r) => r.experienceId === d.id && r.reason === "scam"));
  check("report with a bad reason is 400", (await post({ slug: d.slug, reason: "bogus" })).status === 400);
  check("report with a malformed slug is 404", (await post({ slug: "../x", reason: "scam" })).status === 404);
  check("report for an unknown slug is 404", (await post({ slug: "Zzzzzzzzzz", reason: "scam" })).status === 404);
  check("report with invalid JSON is 400", (await post(null, "203.0.113.5", "{not json")).status === 400);
  check("report with an oversized body is 413", (await post({ slug: d.slug, reason: "other", details: "x".repeat(5000) }, "192.0.2.10")).status === 413);
  check("report with an array body is handled", (await post([1, 2], "192.0.2.11")).status === 404);

  resetRateLimits();
  let limited = false;
  for (let i = 0; i < 8 && !limited; i++) limited = (await post({ slug: d.slug, reason: "other" }, "198.51.100.77")).status === 429;
  check("reports are rate limited per IP", limited);

  // ---- cron endpoint
  const cron = (auth?: string) => purge(new Request("http://localhost/api/cron/purge", { headers: auth ? { authorization: auth } : {} }));
  check("purge without a secret header is 401", (await cron()).status === 401);
  check("purge with a wrong secret is 401", (await cron("Bearer wrong")).status === 401);
  check("purge with the secret header omitted 'Bearer' is 401", (await cron("c".repeat(24))).status === 401);
  const ok = await cron(`Bearer ${"c".repeat(24)}`);
  check("purge with the right secret is 200 and reports a count", ok.status === 200 && typeof (await ok.json()).removed === "number");
  check("purge leaves a published greeting alone", (await store.getPublishedBySlug(d.slug)) !== null);

  // ---- health endpoint
  const { GET: health } = await import("../src/app/api/health/route");
  const h = (await (await health()).json()) as Record<string, unknown>;
  check("health reports demo memory when no database is configured", h.database === "demo-memory" && h.databaseReady === false);
  check("health reports admin and cron as enabled", h.adminEnabled === true && h.cronEnabled === true);
  check("health never includes secrets", !JSON.stringify(h).includes("t".repeat(24)) && !JSON.stringify(h).includes("c".repeat(16)));

  summary("admin");
}

main().catch((e) => { console.error(e); process.exit(1); });
