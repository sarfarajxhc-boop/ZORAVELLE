// Photo upload messages and the no-database case.   npm run test:upload
import { check, summary } from "./harness";
import { describeFailure } from "../src/lib/client/upload-photo";
import { POST } from "../src/app/api/photos/route";
import { getStore } from "../src/lib/store";

async function main() {
  check("offline says so", /internet/i.test(describeFailure(0).message) && describeFailure(0).retryable);
  check("403 = session expired, no retry", describeFailure(403).sessionExpired && !describeFailure(403).retryable);
  check("413 = too large", /too large/.test(describeFailure(413).message));
  check("429 = wait", /Wait/.test(describeFailure(429).message));
  check("502 is retryable", describeFailure(502).retryable);
  check("no-database 503 shows the real reason", /Supabase/.test(describeFailure(503, "Photo storage isn't set up on this site yet. The site owner needs to connect Supabase.").message));

  // real handler: a draft unknown to this instance (the Vercel-without-database situation)
  process.env.VERCEL = "1";
  const store = getStore();
  const d = await store.createDraft({ occasion: "birthday", recipientName: "A", senderName: "B" });
  const png = Uint8Array.from(atob("iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg=="), (c) => c.charCodeAt(0));
  const send = async (token: string) => {
    const f = new FormData(); f.set("id", d.id); f.set("file", new File([png], "p.png", { type: "image/png" }));
    const r = await POST(new Request("http://x/api/photos", { method: "POST", headers: { "x-edit-token": token, "x-forwarded-for": "198.51.100." + Math.floor(Math.random() * 200), "content-length": "5000" }, body: f }));
    return { status: r.status, body: await r.json() };
  };
  const bad = await send("x".repeat(43)); console.log(JSON.stringify(bad));
  check("wrong token is refused", bad.status === 403 || bad.status === 503 || bad.status === 400, JSON.stringify(bad));
  summary("upload");
}
main().catch((e) => { console.error(e); process.exit(1); });
