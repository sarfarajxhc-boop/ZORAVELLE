// Contract tests: every ExperienceStore implementation must pass these.
//
//   npm run test:store                          in-memory store (always)
//   RUN_SUPABASE_CONTRACT=1 npm run test:store  ALSO runs against Supabase using your .env.local values.
//
// Point the Supabase run at a DEVELOPMENT project only. Each run creates its own
// rows and deletes them at the end, but a failed run can leave test rows behind.
import { check, rejectsWith, summary } from "./harness";
import sharp from "sharp";
import { processImage } from "../src/lib/assets/process-image";
import { mockProvider } from "../src/lib/ai/providers/mock";
import { ExperienceConfigSchema, type ExperienceConfig } from "../src/lib/experience/schema";
import { createMemoryStore } from "../src/lib/store/memory";
import type { ExperienceStore } from "../src/lib/store/types";
import { SLUG_RE, TOKEN_RE } from "../src/lib/security/tokens";

async function makeConfig(occasion: string): Promise<ExperienceConfig> {
  const raw = await mockProvider.generate({ occasion, recipientName: "Maya", senderName: "Arjun", assetIds: [] });
  return ExperienceConfigSchema.parse(raw);
}

async function makeWebp(color: string): Promise<Uint8Array> {
  const png = await sharp({ create: { width: 64, height: 48, channels: 3, background: color } }).png().toBuffer();
  return (await processImage(png)).data;
}

const draftInput = { occasion: "birthday", recipientName: "Maya", senderName: "Arjun" };

export async function runContract(store: ExperienceStore, label: string) {
  const t = (name: string, ok: boolean, detail = "") => check(`[${label}] ${name}`, ok, detail);
  const rw = (name: string, p: Promise<unknown>, code: string) => rejectsWith(`[${label}] ${name}`, p, code);
  const cleanup: Array<() => Promise<void>> = [];

  try {
    // ---- drafts
    const d = await store.createDraft(draftInput);
    cleanup.push(() => store.deleteExperience(d.id, d.editToken));
    t("createDraft returns a slug and an edit token", SLUG_RE.test(d.slug) && TOKEN_RE.test(d.editToken));
    t("a draft is not publicly viewable", (await store.getPublishedBySlug(d.slug)) === null);
    await rw("createDraft rejects a bad occasion", store.createDraft({ ...draftInput, occasion: "Not Valid!" }), "invalid");
    await rw("createDraft rejects an empty recipient", store.createDraft({ ...draftInput, recipientName: " " }), "invalid");
    await rw("createDraft rejects a 61-char sender", store.createDraft({ ...draftInput, senderName: "x".repeat(61) }), "invalid");

    // ---- authorization: wrong token / unknown id are indistinguishable
    const other = await store.createDraft(draftInput);
    cleanup.push(() => store.deleteExperience(other.id, other.editToken));
    const config = await makeConfig("birthday");
    const webp = await makeWebp("#336699");
    const unknownId = "00000000-0000-4000-8000-000000000000";
    await rw("saveConfiguration: another draft's token is forbidden", store.saveConfiguration(d.id, other.editToken, config), "forbidden");
    await rw("saveConfiguration: junk token is forbidden", store.saveConfiguration(d.id, "nope", config), "forbidden");
    await rw("saveConfiguration: unknown id is forbidden (not 'not found')", store.saveConfiguration(unknownId, d.editToken, config), "forbidden");
    await rw("addAsset: wrong token is forbidden", store.addAsset(d.id, other.editToken, { data: webp }), "forbidden");
    await rw("removeAsset: wrong token is forbidden", store.removeAsset(d.id, other.editToken, unknownId), "forbidden");
    await rw("publish: wrong token is forbidden", store.publish(d.id, other.editToken), "forbidden");
    await rw("deleteExperience: wrong token is forbidden", store.deleteExperience(d.id, other.editToken), "forbidden");
    await rw("non-uuid id is forbidden, not a crash", store.publish("' or 1=1 --", d.editToken), "forbidden");

    // ---- validation at the storage boundary
    await rw("publish before generating is invalid", store.publish(d.id, d.editToken), "invalid");
    await rw("saveConfiguration rejects a schema-invalid config",
      store.saveConfiguration(d.id, d.editToken, { ...config, ambient: { effect: "<script>", intensity: 99 } } as unknown as ExperienceConfig), "invalid");
    await rw("saveConfiguration rejects a different occasion",
      store.saveConfiguration(d.id, d.editToken, { ...config, occasion: "diwali" }), "invalid");
    const foreign = "11111111-1111-4111-8111-111111111111";
    await rw("saveConfiguration rejects a gallery with a photo the greeting doesn't own",
      store.saveConfiguration(d.id, d.editToken, { ...config, blocks: [...config.blocks, { type: "gallery", assetIds: [foreign] }] }), "invalid");
    await rw("saveConfiguration rejects an over-long message", store.saveConfiguration(d.id, d.editToken, config, { message: "x".repeat(1201) }), "invalid");
    await rw("addAsset rejects non-WebP bytes", store.addAsset(d.id, d.editToken, { data: Buffer.from("<svg onload=alert(1)>") }), "invalid");
    await rw("addAsset rejects empty bytes", store.addAsset(d.id, d.editToken, { data: new Uint8Array(0) }), "invalid");

    // ---- assets and the 6-photo limit
    const a1 = await store.addAsset(d.id, d.editToken, { data: webp });
    t("addAsset returns an id and size", typeof a1.id === "string" && a1.byteSize === webp.length);
    for (let i = 0; i < 5; i++) await store.addAsset(d.id, d.editToken, { data: webp });
    await rw("a seventh photo hits the limit", store.addAsset(d.id, d.editToken, { data: webp }), "limit");
    await store.removeAsset(d.id, d.editToken, a1.id);
    const a7 = await store.addAsset(d.id, d.editToken, { data: webp });
    t("removing a photo frees a slot", typeof a7.id === "string");
    const urls = await store.getAssetUrls(d.id, [a7.id, foreign, a1.id]);
    t("getAssetUrls returns a URL for an owned photo", typeof urls[a7.id] === "string" && urls[a7.id]!.length > 10);
    t("getAssetUrls omits unknown and removed photos", !(foreign in urls) && !(a1.id in urls));
    const crossUrls = await store.getAssetUrls(other.id, [a7.id]);
    t("getAssetUrls never returns another greeting's photo", Object.keys(crossUrls).length === 0);

    // ---- the creator's own view
    const owned = await store.getOwned(d.id, d.editToken);
    t("getOwned returns the creator's view", owned.id === d.id && owned.slug === d.slug && owned.published === false && owned.hasConfiguration === false);
    t("getOwned lists the photos", owned.assetIds.length === 6 && owned.assetIds.includes(a7.id) && !owned.assetIds.includes(a1.id));
    await rw("getOwned: wrong token is forbidden", store.getOwned(d.id, other.editToken), "forbidden");
    await rw("getOwned: unknown id is forbidden", store.getOwned(unknownId, d.editToken), "forbidden");

    // ---- save, publish, read
    const withGallery: ExperienceConfig = { ...config, blocks: [...config.blocks, { type: "gallery", assetIds: [a7.id] }] };
    await rw("saveConfiguration rejects a blank recipient name", store.saveConfiguration(d.id, d.editToken, withGallery, { recipientName: "  " }), "invalid");
    await store.saveConfiguration(d.id, d.editToken, withGallery, { message: "My own words", recipientName: "Maya R", senderName: "Arjun K" });
    const afterSave = await store.getOwned(d.id, d.editToken);
    t("saving updates names and marks the greeting as configured", afterSave.recipientName === "Maya R" && afterSave.senderName === "Arjun K" && afterSave.hasConfiguration);
    const pub = await store.publish(d.id, d.editToken);
    t("publish returns the same slug", pub.slug === d.slug);
    const read = await store.getPublishedBySlug(d.slug);
    t("published experience is readable by slug", read !== null && read.id === d.id && read.recipientName === "Maya R");
    t("getOwned reflects the published state", (await store.getOwned(d.id, d.editToken)).published === true);
    t("stored configuration round-trips exactly", JSON.stringify(read?.configuration) === JSON.stringify(withGallery));
    t("the public result has no token hash or moderation fields",
      !!read && !("tokenHash" in read) && !("edit_token_hash" in read) && !("hiddenReason" in read));
    t("a malformed slug returns null", (await store.getPublishedBySlug("short")) === null && (await store.getPublishedBySlug("../etc/pass")) === null);
    t("an unknown slug returns null", (await store.getPublishedBySlug("Zzzzzzzzzz")) === null);
    await store.saveConfiguration(d.id, d.editToken, { ...withGallery, theme: { ...withGallery.theme, name: "Edited" } });
    t("editing a published greeting updates it live", (await store.getPublishedBySlug(d.slug))?.configuration.theme.name === "Edited");

    // ---- moderation and expiry
    await store.setHidden(d.id, true, "contract test");
    t("a hidden greeting disappears", (await store.getPublishedBySlug(d.slug)) === null);
    await store.setHidden(d.id, false);
    t("un-hiding brings it back", (await store.getPublishedBySlug(d.slug)) !== null);
    await rw("setHidden on an unknown id is not_found", store.setHidden(unknownId, true), "not_found");

    const exp = await store.createDraft(draftInput, { expiresAt: new Date(Date.now() - 60_000) });
    cleanup.push(() => store.deleteExperience(exp.id, exp.editToken));
    await store.saveConfiguration(exp.id, exp.editToken, config);
    await store.publish(exp.id, exp.editToken);
    t("an expired greeting is not viewable", (await store.getPublishedBySlug(exp.slug)) === null);

    // ---- analytics must never break anything
    await store.recordGeneration(d.id, { provider: "mock", status: "success", durationMs: 12 });
    await store.recordGeneration(unknownId, { provider: "mock", status: "failed" });
    t("recordGeneration never throws, even for unknown ids", true);

    // ---- delete
    await store.deleteExperience(d.id, d.editToken);
    t("deleted greeting is gone", (await store.getPublishedBySlug(d.slug)) === null);
    t("deleted greeting's photos are gone", Object.keys(await store.getAssetUrls(d.id, [a7.id])).length === 0);
    await rw("deleting twice is forbidden", store.deleteExperience(d.id, d.editToken), "forbidden");

    // ---- Phase 8: reports, admin, rate limits
    const rp = await store.createDraft(draftInput);
    cleanup.push(() => store.adminDelete(rp.id));
    await store.saveConfiguration(rp.id, rp.editToken, await makeConfig("birthday"), { message: "hello there" });
    await rw("report on an unpublished greeting is refused", store.addReport(rp.slug, "other"), "not_found");
    await store.publish(rp.id, rp.editToken);
    await rw("report with an unknown reason is refused", store.addReport(rp.slug, "bogus" as never), "invalid");
    await rw("report with over-long details is refused", store.addReport(rp.slug, "other", "x".repeat(501)), "invalid");
    await rw("report for a malformed slug is refused", store.addReport("../x", "other"), "not_found");
    await store.addReport(rp.slug, "harassment", "  rude  ");
    const reps = await store.listReports();
    const mine = reps.filter((r) => r.experienceId === rp.id);
    t("a report is listed with trimmed details", mine.length === 1 && mine[0]?.details === "rude" && mine[0]?.reason === "harassment" && mine[0]?.slug === rp.slug);
    const adminRow = (await store.listForAdmin({ limit: 500 })).find((x) => x.id === rp.id);
    t("admin list shows the greeting, its text and its open report count", adminRow?.openReports === 1 && adminRow.message === "hello there" && typeof adminRow.headline === "string" && adminRow.published && !adminRow.hidden);
    t("the admin list never includes token material", !JSON.stringify(adminRow).includes(rp.editToken));
    t("a report does not hide anything by itself", (await store.getPublishedBySlug(rp.slug)) !== null);
    await store.resolveReports(rp.id);
    t("resolved reports leave the open list", (await store.listReports()).every((r) => r.experienceId !== rp.id));
    t("resolved reports remain with includeResolved", (await store.listReports({ includeResolved: true })).some((r) => r.experienceId === rp.id && r.resolved));
    await store.setHidden(rp.id, true, "test takedown");
    t("hidden greeting stops opening", (await store.getPublishedBySlug(rp.slug)) === null);
    await rw("report on a hidden greeting is refused", store.addReport(rp.slug, "other"), "not_found");
    t("admin sees the hidden state and reason", (await store.listForAdmin({ limit: 500 })).some((x) => x.id === rp.id && x.hidden && x.hiddenReason === "test takedown"));
    await store.setHidden(rp.id, false);
    t("unhide restores the greeting", (await store.getPublishedBySlug(rp.slug)) !== null);
    await rw("setHidden on an unknown id is not_found", store.setHidden("3f2b8c1e-5b1a-4c2e-9d11-0a1b2c3d4e5f", true), "not_found");
    await store.adminDelete(rp.id);
    t("adminDelete removes the greeting without its token", (await store.getPublishedBySlug(rp.slug)) === null);
    t("adminDelete removes its reports", (await store.listReports({ includeResolved: true })).every((r) => r.experienceId !== rp.id));
    await rw("adminDelete on an unknown id is not_found", store.adminDelete("3f2b8c1e-5b1a-4c2e-9d11-0a1b2c3d4e5f"), "not_found");
    await rw("adminDelete on a malformed id is not_found", store.adminDelete("nope"), "not_found");

    const key = `contract-${Math.random().toString(36).slice(2)}`;
    const hits = [] as boolean[];
    for (let i = 0; i < 4; i++) hits.push((await store.hitRateLimit(key, 3, 60)).ok);
    t("rate limit allows 3 then blocks the 4th", JSON.stringify(hits) === "[true,true,true,false]", JSON.stringify(hits));
    const blocked = await store.hitRateLimit(key, 3, 60);
    t("a blocked hit reports a retry time", !blocked.ok && blocked.retryAfterSec >= 1 && blocked.retryAfterSec <= 60);
    t("another key is unaffected", (await store.hitRateLimit(`${key}-b`, 3, 60)).ok);
  } finally {
    for (const c of cleanup) { try { await c(); } catch { /* already deleted */ } }
  }
}

/** Memory-only: needs a controllable clock to test the sweep. */
async function runMemoryPurge() {
  let now = new Date("2026-01-01T00:00:00Z");
  const store = createMemoryStore({ now: () => now });
  const config = await makeConfig("birthday");

  const fresh = await store.createDraft(draftInput);
  const old = await store.createDraft(draftInput);
  const keep = await store.createDraft(draftInput);
  await store.saveConfiguration(keep.id, keep.editToken, config);
  await store.publish(keep.id, keep.editToken);
  const exp = await store.createDraft(draftInput, { expiresAt: new Date("2026-01-03T00:00:00Z") });
  await store.saveConfiguration(exp.id, exp.editToken, config);
  await store.publish(exp.id, exp.editToken);
  await store.addAsset(old.id, old.editToken, { data: await makeWebp("#f00") });

  now = new Date("2026-01-05T00:00:00Z");
  check("[memory] purge at day 4 removes only the expired greeting, not young drafts", (await store.purgeExpired()) === 1, "only the expired one should go");
  check("[memory] purge: expired published greeting removed", (await store.getPublishedBySlug(exp.slug)) === null);
  check("[memory] purge: published, non-expiring greeting kept", (await store.getPublishedBySlug(keep.slug)) !== null);

  now = new Date("2026-01-09T00:00:00Z"); // 8 days after creation
  const removed = await store.purgeExpired();
  check("[memory] purge: stale unpublished drafts (> 7 days) removed", removed === 2, `removed ${removed}`);
  check("[memory] purge: the stale draft can no longer be edited", await store.publish(old.id, old.editToken).then(() => false, (e) => e.code === "forbidden"));
  check("[memory] purge: published greeting survives", (await store.getPublishedBySlug(keep.slug)) !== null);
  void fresh;
}

async function main() {
  await runContract(createMemoryStore(), "memory");
  await runMemoryPurge();

  if (process.env.RUN_SUPABASE_CONTRACT === "1") {
    const { createSupabaseStore } = await import("../src/lib/store/supabase");
    console.log("\nRunning the contract against Supabase (development project only)...");
    await runContract(createSupabaseStore(), "supabase");
  } else {
    console.log("\n(Supabase contract skipped. Set RUN_SUPABASE_CONTRACT=1 with a development project's keys to run it.)");
  }
  summary("store contract");
}

main().catch((e) => { console.error(e); process.exit(1); });
