// Run: npm run test:unit   (tokens and the image pipeline)
import sharp from "sharp";
import { check, summary } from "./harness";
import {
  HASH_RE, SLUG_RE, TOKEN_RE, generateEditToken, generateSlug, hashToken, tokenMatchesHash,
} from "../src/lib/security/tokens";
import { sniffImageType } from "../src/lib/assets/sniff";
import { ImageError, MAX_UPLOAD_BYTES, processImage } from "../src/lib/assets/process-image";

const contains = (buf: Uint8Array, text: string) => Buffer.from(buf).includes(Buffer.from(text));

async function rejects(name: string, input: Uint8Array, code: string) {
  try {
    await processImage(input);
    check(name, false, "was accepted");
  } catch (e) {
    check(name, e instanceof ImageError && e.code === code, `got ${e instanceof ImageError ? e.code : String(e)}`);
  }
}

async function main() {
  // ------------------------------------------------------------- slugs
  const N = 5000;
  const slugs = Array.from({ length: N }, generateSlug);
  check("slugs: all match ^[0-9A-Za-z]{10}$", slugs.every((s) => SLUG_RE.test(s)));
  check("slugs: no duplicates in 5000", new Set(slugs).size === N);
  const freq = new Map<string, number>();
  for (const s of slugs) for (const c of s) freq.set(c, (freq.get(c) ?? 0) + 1);
  const counts = [...freq.values()];
  check("slugs: all 62 characters occur", freq.size === 62, `got ${freq.size}`);
  // 50,000 draws over 62 symbols: mean 806, sigma ~28, so +/- 7 sigma is [610, 1002]
  check("slugs: character frequencies are even (no modulo bias)", Math.min(...counts) > 610 && Math.max(...counts) < 1002,
    `min ${Math.min(...counts)} max ${Math.max(...counts)}`);

  // ------------------------------------------------------------ tokens
  const t = generateEditToken();
  const h = hashToken(t);
  check("token: 43 url-safe chars", TOKEN_RE.test(t));
  check("token: hash is 64 hex and differs from token", HASH_RE.test(h) && h !== t);
  check("token: hashing is deterministic", hashToken(t) === h);
  check("token: 2000 tokens are unique", new Set(Array.from({ length: 2000 }, generateEditToken)).size === 2000);
  check("token: matches its own hash", tokenMatchesHash(t, h));
  check("token: another token does not match", !tokenMatchesHash(generateEditToken(), h));
  check("token: truncated token does not match", !tokenMatchesHash(t.slice(0, 42), h));
  check("token: trailing space does not match", !tokenMatchesHash(t + " ", h));
  check("token: junk types never match and never throw",
    [null, undefined, 42, {}, [], true].every((x) => !tokenMatchesHash(x, h) && !tokenMatchesHash(t, x)));
  check("token: malformed stored hash never matches", !tokenMatchesHash(t, "zz") && !tokenMatchesHash(t, h.toUpperCase()));
  check("token: presenting the hash itself does not authorize", !tokenMatchesHash(h, h));

  // ------------------------------------------------------------- sniff
  check("sniff: gif is not accepted", sniffImageType(Buffer.from("GIF89a....")) === null);
  check("sniff: svg is not accepted", sniffImageType(Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"/>')) === null);
  check("sniff: pdf is not accepted", sniffImageType(Buffer.from("%PDF-1.7")) === null);
  check("sniff: short buffers are safe", sniffImageType(new Uint8Array(0)) === null && sniffImageType(new Uint8Array([0xff])) === null);

  // ------------------------------------------------------- image pipeline
  const exif = {
    IFD0: { Copyright: "secret-owner-name" },
    IFD3: { GPSLatitudeRef: "N", GPSLatitude: "51/1 30/1 0/1", GPSLongitudeRef: "W", GPSLongitude: "0/1 7/1 0/1" },
  };
  const photo = await sharp({ create: { width: 3000, height: 2000, channels: 3, background: "#336699" } })
    .withMetadata({ orientation: 6, exif })
    .jpeg()
    .toBuffer();
  const inMeta = await sharp(photo).metadata();
  check("fixture: input JPEG really carries EXIF, GPS and orientation 6",
    !!inMeta.exif && contains(photo, "secret-owner-name") && inMeta.orientation === 6,
    `exif=${!!inMeta.exif} orientation=${inMeta.orientation}`);

  const out = await processImage(photo);
  const outMeta = await sharp(out.data).metadata();
  check("output: is WebP", sniffImageType(out.data) === "webp" && outMeta.format === "webp" && out.mime === "image/webp");
  check("output: EXIF is gone", !outMeta.exif && !contains(out.data, "secret-owner-name") && !contains(out.data, "Exif"));
  check("output: orientation applied then flag removed",
    out.height === 1600 && out.width < out.height && (outMeta.orientation ?? 1) === 1, `${out.width}x${out.height}`);
  check("output: reported size matches bytes", out.byteSize === out.data.length);
  check("output: is smaller than the 5 MB limit", out.byteSize < MAX_UPLOAD_BYTES);

  const small = await sharp({ create: { width: 100, height: 50, channels: 3, background: "#fff" } }).png().toBuffer();
  const smallOut = await processImage(small);
  check("small images are not upscaled", smallOut.width === 100 && smallOut.height === 50);

  const alphaPng = await sharp({ create: { width: 40, height: 40, channels: 4, background: { r: 255, g: 0, b: 0, alpha: 0.5 } } }).png().toBuffer();
  check("png with transparency is accepted", sniffImageType((await processImage(alphaPng)).data) === "webp");
  const webpIn = await sharp({ create: { width: 40, height: 40, channels: 3, background: "#0f0" } }).webp().toBuffer();
  check("webp input is accepted", sniffImageType((await processImage(webpIn)).data) === "webp");

  const polyglot = Buffer.concat([
    await sharp({ create: { width: 20, height: 20, channels: 3, background: "#123" } }).jpeg().toBuffer(),
    Buffer.from("<script>alert(document.cookie)</script><?php system($_GET['c']); ?>"),
  ]);
  const polyOut = await processImage(polyglot);
  check("polyglot: appended script/php payload does not survive re-encoding",
    !contains(polyOut.data, "<script>") && !contains(polyOut.data, "<?php") && !contains(polyOut.data, "alert("));

  await rejects("rejects empty file", new Uint8Array(0), "empty");
  await rejects("rejects GIF", Buffer.from("GIF89a" + "x".repeat(100)), "unsupported_type");
  await rejects("rejects SVG (script carrier)", Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>'), "unsupported_type");
  await rejects("rejects PDF", Buffer.from("%PDF-1.7 " + "x".repeat(100)), "unsupported_type");
  await rejects("rejects HTML renamed to .jpg", Buffer.from("<html><body onload=alert(1)></body></html>"), "unsupported_type");
  await rejects("rejects random bytes", Buffer.from(Array.from({ length: 500 }, (_, i) => (i * 37) & 0x7f)), "unsupported_type");
  await rejects("rejects 6 MB file (size checked before decoding)", Buffer.concat([Buffer.from([0xff, 0xd8, 0xff]), Buffer.alloc(6 * 1024 * 1024)]), "too_large");
  await rejects("rejects JPEG magic with garbage body", Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), Buffer.from("not really a jpeg ".repeat(40))]), "corrupt");
  const half = photo.subarray(0, Math.floor(photo.length / 2));
  try {
    const r = await processImage(half);
    check("truncated JPEG is rejected or safely re-encoded", sniffImageType(r.data) === "webp");
  } catch (e) {
    check("truncated JPEG is rejected or safely re-encoded", e instanceof ImageError && e.code === "corrupt");
  }
  const bomb = await sharp({ create: { width: 6500, height: 6500, channels: 3, background: "#000" } }).png({ compressionLevel: 9 }).toBuffer();
  check("fixture: pixel bomb is small on the wire", bomb.length < MAX_UPLOAD_BYTES, `${bomb.length} bytes`);
  await rejects("rejects pixel bomb (42M pixels, small file)", bomb, "too_large");

  summary("security");
}

main().catch((e) => { console.error(e); process.exit(1); });
