let failures = 0;
let passes = 0;

export function check(name: string, ok: boolean, detail = ""): void {
  if (ok) passes++;
  else failures++;
  console.log(ok ? "PASS" : "FAIL", name, ok ? "" : detail);
}

/** Expect the promise to reject with a StoreError-like { code }. */
export async function rejectsWith(name: string, p: Promise<unknown>, code: string): Promise<void> {
  try {
    await p;
    check(name, false, `expected "${code}" but it succeeded`);
  } catch (e) {
    const got = (e as { code?: string }).code;
    check(name, got === code, `expected "${code}", got "${got ?? String(e)}"`);
  }
}

export function summary(label: string): void {
  console.log(`\n${label}: ${passes} passed, ${failures} failed`);
  process.exit(failures ? 1 : 0);
}
