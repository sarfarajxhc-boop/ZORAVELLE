// End-to-end test of the greeting lifecycle through the real server actions and
// the real /api/photos handler, using the in-memory store (no network needed).
//   npm run test:flow
import sharp from "sharp";
import { check, summary } from "./harness";
import { resetRateLimits } from "../src/lib/rate-limit";
import {
  generateGreeting, publishGreeting, removePhoto, saveEdits, startDraft,
} from "../src/app/(site)/create/[occasion]/actions";
import { deleteOwned, loadOwned } from "../src/app/(site)/manage/actions";
import { POST as uploadPhoto } from "../src/app/api/photos/route";
import { loadViewerData } from "../src/lib/greetings/load-viewer";
import { SLUG_RE } from "../src/lib/security/tokens";
import type { ExperienceConfig } from "../src/lib/experience/schema";

const input = { occasion: "birthday", recipientName: "Maya", senderName: "Arjun", assetIds: [] as string[] };

async function png(color = "#cc3366"): Promise<Uint8Array> {
  return new Uint8Array(await sharp({ create: { width: 80, height: 60, channels: 3, background: color } }).png().toBuffer());
}

/** Build a request the way a browser would: multipart body with a real content-length. */
async function uploadRequest(opts: { id: string; token: string | null; file: Uint8Array | null; ip?: string }) {
  const fd = new FormData();
  fd.set("id", opts.id);
  if (opts.file) fd.set("file", new File([opts.file as BlobPart], "p.png", { type: "image/png" }));
  const probe = new Response(fd);
  const body = new Uint8Array(await probe.arrayBuffer());
  const headers: Record<string, string> = {
    "content-type": probe.headers.get("content-type") ?? "",
    "content-length": String(body.byteLength),
    "x-forwarded-for": opts.ip ?? "203.0.113.7",
  };
  if (opts.token) headers["x-edit-token"] = opts.token;
  return new Request("http://localhost/api/photos", { method: "POST", headers, body });
}

const upload = async (id: string, token: string | null, file: Uint8Array | null, ip?: string) => {
  const res = await uploadPhoto(await uploadRequest({ id, token, file, ip }));
  return { status: res.status, body: (await res.json()) as { assetId?: string; url?: string | null; error?: string } };
};

const galleryIds = (c: ExperienceConfig) => c.blocks.flatMap((b) => (b.type === "gallery" ? b.assetIds : []));

async function main() {
  // ---- draft, upload, generate
  resetRateLimits();
  const started = await startDraft({ occasion: "birthday", recipientName: "Maya", senderName: "Arjun" });
  check("startDraft succeeds", started.ok);
  if (!started.ok) return summary("flow");
  const draft = started.draft;

  check("startDraft rejects a missing name", !(await startDraft({ occasion: "birthday", recipientName: "", senderName: "A" })).ok);
  check("startDraft rejects an unknown occasion", !(await startDraft({ occasion: "nope", recipientName: "M", senderName: "A" })).ok);

  const up = await upload(draft.id, draft.token, await png());
  check("photo upload succeeds with the right token", up.status === 200 && typeof up.body.assetId === "string");
  const assetId = up.body.assetId ?? "";

  check("upload with a wrong token is 403", (await upload(draft.id, "A".repeat(43), await png())).status === 403);
  check("upload with no token is 400", (await upload(draft.id, null, await png())).status === 400);
  check("upload with no file is 400", (await upload(draft.id, draft.token, null)).status === 400);
  check("upload of a non-image is rejected", (await upload(draft.id, draft.token, new TextEncoder().encode("<script>alert(1)</script>"))).status === 400);
  check("upload for an unknown draft is 403", (await upload("3f2b8c1e-5b1a-4c2e-9d11-0a1b2c3d4e5f", draft.token, await png())).status === 403);

  const gen = await generateGreeting({ ...input, assetIds: [assetId, "3f2b8c1e-5b1a-4c2e-9d11-0a1b2c3d4e5f"] }, draft);
  check("generateGreeting succeeds with the draft", gen.ok);
  if (!gen.ok) return summary("flow");
  check("generation reuses the same draft", gen.draft.id === draft.id && gen.draft.token === draft.token);
  check("owned photo is used, a foreign id is dropped", JSON.stringify(galleryIds(gen.config)) === JSON.stringify([assetId]), JSON.stringify(galleryIds(gen.config)));
  check("preview gets a URL for the owned photo", typeof gen.assetUrls[assetId] === "string");

  const noDraft = await generateGreeting(input);
  check("generateGreeting without a draft creates one", noDraft.ok && noDraft.draft.id !== draft.id);
  check("generateGreeting with a bad token says the draft expired",
    await generateGreeting(input, { id: draft.id, token: "B".repeat(43) }).then((r) => !r.ok && r.draftExpired === true));
  check("generateGreeting with malformed credentials says the draft expired",
    await generateGreeting(input, { id: "x", token: "y" }).then((r) => !r.ok && r.draftExpired === true));
  check("a draft can't be reused for another occasion",
    await generateGreeting({ ...input, occasion: "diwali" }, draft).then((r) => !r.ok && r.draftExpired === true));

  // ---- editing
  const edited: ExperienceConfig = JSON.parse(JSON.stringify(gen.config));
  for (const b of edited.blocks) {
    if (b.type === "hero") b.headline = "Happy birthday, Maya!";
    if (b.type === "message") b.body = "My own words.";
  }
  const saved = await saveEdits(draft, edited);
  check("saveEdits accepts valid edits", saved.ok);
  check("saveEdits rejects an empty message",
    await saveEdits(draft, { ...edited, blocks: edited.blocks.map((b) => (b.type === "message" ? { ...b, body: "" } : b)) }).then((r) => !r.ok));
  check("saveEdits rejects unknown fields (no smuggled markup)",
    await saveEdits(draft, { ...edited, html: "<script>x</script>" }).then((r) => !r.ok));
  check("saveEdits with a wrong token says the draft expired",
    await saveEdits({ id: draft.id, token: "C".repeat(43) }, edited).then((r) => !r.ok && r.draftExpired === true));
  check("saveEdits rejects a photo the draft doesn't own",
    await saveEdits(draft, {
      ...edited,
      blocks: edited.blocks.map((b) => (b.type === "gallery" ? { ...b, assetIds: ["3f2b8c1e-5b1a-4c2e-9d11-0a1b2c3d4e5f"] } : b)),
    }).then((r) => !r.ok));

  // ---- publish
  const early = await startDraft({ occasion: "birthday", recipientName: "Zed", senderName: "Y" });
  check("publishing a draft with no greeting is refused", early.ok && (await publishGreeting(early.draft)).ok === false);
  check("publish with a wrong token is refused", !(await publishGreeting({ id: draft.id, token: "D".repeat(43) })).ok);
  check("a draft isn't viewable before publishing", (await loadViewerData("nonexistent01")) === null);

  const pub = await publishGreeting(draft);
  check("publishGreeting succeeds", pub.ok);
  if (!pub.ok) return summary("flow");
  check("slug has the expected shape", SLUG_RE.test(pub.slug));
  check("share URL ends with /w/<slug>", pub.url.endsWith(`/w/${pub.slug}`));
  check("manage URL keeps the token in the fragment", pub.manageUrl.includes(`/manage#${draft.id}.${draft.token}`));
  check("demo store is reported as not persistent", pub.persistent === false);

  const view = await loadViewerData(pub.slug);
  check("viewer data loads for the published slug", view !== null);
  const headline = view?.config.blocks.find((b) => b.type === "hero");
  check("viewer sees the edited text", headline?.type === "hero" && headline.headline === "Happy birthday, Maya!");
  check("viewer gets a photo URL", !!view && typeof view.assets[assetId] === "string");
  check("viewer data carries no token or moderation fields", !!view && !JSON.stringify(view).includes(draft.token) && !("editTokenHash" in view));
  check("a malformed slug is not viewable", (await loadViewerData("../etc/passwd")) === null);

  // ---- manage
  const owned = await loadOwned(draft);
  check("manage loads with the right token", owned.ok && owned.greeting.published && owned.greeting.url === pub.url);
  check("manage with a wrong token fails", !(await loadOwned({ id: draft.id, token: "E".repeat(43) })).ok);
  check("manage with malformed input fails", !(await loadOwned({ id: "nope" })).ok);
  check("an unknown id and a wrong token give the same message",
    await Promise.all([
      loadOwned({ id: draft.id, token: "F".repeat(43) }),
      loadOwned({ id: "3f2b8c1e-5b1a-4c2e-9d11-0a1b2c3d4e5f", token: draft.token }),
    ]).then(([a, b]) => !a.ok && !b.ok && a.message === b.message));

  check("removePhoto with a wrong token fails", !(await removePhoto({ id: draft.id, token: "G".repeat(43) }, assetId)).ok);
  check("removePhoto works with the right token", (await removePhoto(draft, assetId)).ok);

  check("delete with a wrong token fails and keeps the greeting",
    !(await deleteOwned({ id: draft.id, token: "H".repeat(43) })).ok && (await loadViewerData(pub.slug)) !== null);
  check("delete with the right token succeeds", (await deleteOwned(draft)).ok);
  check("a deleted greeting is no longer viewable", (await loadViewerData(pub.slug)) === null);
  check("a deleted greeting can't be managed again", !(await loadOwned(draft)).ok);
  check("a deleted greeting can't be deleted twice", !(await deleteOwned(draft)).ok);

  // ---- rate limits
  resetRateLimits();
  let blocked = false;
  for (let i = 0; i < 12 && !blocked; i++) {
    blocked = !(await startDraft({ occasion: "birthday", recipientName: "R", senderName: "S" })).ok;
  }
  check("draft creation is rate limited", blocked);

  resetRateLimits();
  const d2 = await startDraft({ occasion: "birthday", recipientName: "Maya", senderName: "Arjun" });
  let uploadBlocked = false;
  if (d2.ok) {
    const img = await png();
    for (let i = 0; i < 45 && !uploadBlocked; i++) {
      const r = await upload(d2.draft.id, "A".repeat(43), img, "198.51.100.9"); // wrong token: cheap, still counted
      uploadBlocked = r.status === 429;
    }
  }
  check("uploads are rate limited per IP (before any decoding)", uploadBlocked);

  summary("flow");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
