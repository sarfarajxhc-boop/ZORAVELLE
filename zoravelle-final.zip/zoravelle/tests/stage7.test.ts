// Stage 7: saved drafts, photo layouts, customisation.   npm run test:stage7
import { check, summary } from "./harness";
import { ExperienceConfigSchema } from "../src/lib/experience/schema";
import { parseDraft } from "../src/lib/client/draft-store";
import { resetRateLimits } from "../src/lib/rate-limit";
import { generateGreeting, resumeDraft, saveEdits, startDraft, publishGreeting } from "../src/app/(site)/create/[occasion]/actions";
import { getStore } from "../src/lib/store";
import { loadViewerState } from "../src/lib/greetings/load-viewer";
import { OCCASIONS } from "../src/lib/occasions/registry";
import { contrastRatio } from "../src/lib/experience/contrast";
import sharp from "sharp";

async function made(photos = 0) {
  resetRateLimits();
  const s = await startDraft({ occasion: "birthday", recipientName: "Zoya", senderName: "Arjun" });
  if (!s.ok) throw new Error("draft");
  const store = getStore();
  const ids: string[] = [];
  const png = new Uint8Array(await sharp({ create: { width: 8, height: 8, channels: 3, background: "#b00" } }).webp().toBuffer());
  for (let i = 0; i < photos; i++) ids.push((await store.addAsset(s.draft.id, s.draft.token, { data: png })).id);
  const g = await generateGreeting({ occasion: "birthday", recipientName: "Zoya", senderName: "Arjun", assetIds: ids }, s.draft);
  if (!g.ok) throw new Error("gen");
  return { draft: s.draft, cfg: JSON.parse(JSON.stringify(g.config)), ids };
}

async function main() {
  // ---- schema stays backward compatible
  const a = await made(2);
  check("existing configs (no layout, no look) still valid", ExperienceConfigSchema.safeParse(a.cfg).success);
  const gal = a.cfg.blocks.find((b: any) => b.type === "gallery");
  check("a generated gallery has photos", !!gal && gal.assetIds.length === 2);
  for (const layout of ["polaroid", "grid", "filmstrip", "spotlight"]) {
    const c = JSON.parse(JSON.stringify(a.cfg)); c.blocks.find((b: any) => b.type === "gallery").layout = layout;
    check(`layout ${layout} accepted`, ExperienceConfigSchema.safeParse(c).success);
  }
  { const c = JSON.parse(JSON.stringify(a.cfg)); c.blocks.find((b: any) => b.type === "gallery").layout = "<script>"; check("unknown layout rejected", !ExperienceConfigSchema.safeParse(c).success); }
  for (const look of ["calm", "cinematic", "expensive"]) check(`look ${look} accepted`, ExperienceConfigSchema.safeParse({ ...a.cfg, look }).success);
  check("unknown look rejected", !ExperienceConfigSchema.safeParse({ ...a.cfg, look: "neon" }).success);

  // ---- customisation saves and survives publishing (immediate and locked)
  const custom = JSON.parse(JSON.stringify(a.cfg));
  custom.look = "expensive"; custom.ambient = { effect: "sparkles", intensity: 4 };
  custom.blocks.find((b: any) => b.type === "gallery").layout = "filmstrip";
  const saved = await saveEdits(a.draft, custom);
  check("customised look/effect/layout saves", saved.ok);
  const pub = await publishGreeting(a.draft, { mode: "now" });
  check("publishes", pub.ok);
  if (pub.ok) {
    const v = await loadViewerState(pub.slug);
    check("recipient gets the creator's look, effect and layout", v.kind === "open" && v.data.config.look === "expensive" && v.data.config.ambient.effect === "sparkles" && v.data.config.ambient.intensity === 4 && JSON.stringify(v.data.config).includes('"layout":"filmstrip"'));
  }
  const b = await made(1); const bc = JSON.parse(JSON.stringify(b.cfg)); bc.look = "calm";
  await saveEdits(b.draft, bc);
  const pl = await publishGreeting(b.draft, { mode: "lock", unlockAt: new Date(Date.now() + 3600_000).toISOString(), timezone: "Asia/Kolkata" });
  check("locked greeting publishes with customisation", pl.ok);
  if (pl.ok) { const v = await loadViewerState(pl.slug); check("locked view carries no look/layout/photos", v.kind === "locked" && !JSON.stringify(v).includes("calm") && !JSON.stringify(v).includes("layout")); }

  // ---- saveEdits guards
  const bad = JSON.parse(JSON.stringify(a.cfg)); bad.theme.palette.text = bad.theme.palette.background;
  const unread = await saveEdits((await made()).draft, bad);
  check("saveEdits refuses text that matches its background", !unread.ok);
  check("wrong token cannot save a look", !(await saveEdits({ id: a.draft.id, token: "Z".repeat(43) }, custom)).ok);

  // ---- every occasion's own palette is readable (so a saved default can never be refused)
  const unreadable = OCCASIONS.filter((o) => contrastRatio(o.palette.text, o.palette.background) < 4.5 || contrastRatio(o.palette.text, o.palette.surface) < 4.5).map((o) => o.id);
  check("all occasion palettes pass the readability rule", unreadable.length === 0, unreadable.join(","));

  // ---- resume
  const r = await made(2);
  const ok = await resumeDraft(r.draft);
  check("resume returns the draft's photos with fresh URLs", ok.ok && !ok.published && ok.assetIds.length === 2 && ok.assetIds.every((id) => !!ok.assetUrls[id]));
  check("resume with a wrong token fails with no details", !(await resumeDraft({ id: r.draft.id, token: "Q".repeat(43) })).ok);
  check("resume with garbage fails", !(await resumeDraft({ nope: 1 })).ok);
  const rp = await publishGreeting(r.draft, { mode: "now" });
  const done = await resumeDraft(r.draft);
  check("a published draft is reported as published", rp.ok && done.ok && done.published && done.assetIds.length === 0);
  const leak = JSON.stringify(ok);
  check("resume response has no message text or token", !leak.includes("Dear") && !leak.includes(r.draft.token));

  // ---- browser-stored draft parsing
  const now = Date.now();
  const good = { v: 1, savedAt: now - 1000, step: 1, form: { recipientName: "Zoya", message: "hi" }, draft: { id: r.draft.id, token: r.draft.token }, config: a.cfg, meta: { provider: "mock", usedFallback: false } };
  const p = parseDraft(good, now);
  check("a saved draft parses back", !!p && p.form["recipientName"] === "Zoya" && p.step === 1 && !!p.config && p.draft?.id === r.draft.id);
  check("older than 7 days is dropped", parseDraft({ ...good, savedAt: now - 8 * 864e5 }, now) === null);
  check("wrong version is dropped", parseDraft({ ...good, v: 2 }, now) === null);
  check("garbage is dropped", parseDraft("x", now) === null && parseDraft(null, now) === null && parseDraft({ v: 1 }, now) === null);
  const tampered = parseDraft({ ...good, config: { ...a.cfg, look: "evil" } }, now);
  check("a tampered config is not restored (form still is)", !!tampered && tampered.config === null && tampered.form["recipientName"] === "Zoya");
  const weird = parseDraft({ ...good, step: 99, form: { recipientName: 5, x: "ok" }, draft: { id: 1 } }, now);
  check("bad step/fields are neutralised", !!weird && weird.step === 0 && weird.draft === null && weird.form["recipientName"] === undefined);

  summary("stage7");
}
main().catch((e) => { console.error(e); process.exit(1); });
