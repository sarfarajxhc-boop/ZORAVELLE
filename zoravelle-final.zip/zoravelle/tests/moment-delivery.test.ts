// The Moment Delivery System: publish now, or publish a link whose content stays locked until a
// server-side unlock instant. Uses the real server actions, route handlers and the in-memory store,
// with a fake server clock so "the moment it unlocks" can be tested exactly.
//   npm run test:delivery
import { check, summary } from "./harness";
import { resetRateLimits } from "../src/lib/rate-limit";
import {
  generateGreeting, publishGreeting, saveEdits, startDraft,
} from "../src/app/(site)/create/[occasion]/actions";
import { loadOwned, rescheduleOwned } from "../src/app/(site)/manage/actions";
import { GET as statusRoute } from "../src/app/api/greeting/[slug]/status/route";
import { POST as reportRoute } from "../src/app/api/report/route";
import { loadViewerData, loadViewerState } from "../src/lib/greetings/load-viewer";
import { getStore } from "../src/lib/store";
import { checkUnlock, formatInZone, splitRemaining, zonedWallToUtc } from "../src/lib/schedule/time";
import type { ExperienceConfig } from "../src/lib/experience/schema";

// ---- fake server clock (the store and routes read `new Date()`)
const RealDate = Date;
let offsetMs = 0;
class FakeDate extends RealDate {
  constructor(...a: unknown[]) {
    if (a.length === 0) super(RealDate.now() + offsetMs);
    else super(...(a as [number]));
  }
  static now() { return RealDate.now() + offsetMs; }
}
(globalThis as { Date: unknown }).Date = FakeDate;
const advance = (ms: number) => { offsetMs += ms; };
const nowMs = () => Date.now();
const iso = (ms: number) => new Date(ms).toISOString();

const SECRET_TEXT = "ZZ-private-message-body-ZZ";
const SECRET_NAME = "Qwertyuiop";

async function newPublishable() {
  resetRateLimits();
  const s = await startDraft({ occasion: "birthday", recipientName: SECRET_NAME, senderName: "Arjun" });
  if (!s.ok) throw new Error("draft");
  const g = await generateGreeting({ occasion: "birthday", recipientName: SECRET_NAME, senderName: "Arjun", assetIds: [] }, s.draft);
  if (!g.ok) throw new Error("gen");
  const cfg: ExperienceConfig = JSON.parse(JSON.stringify(g.config));
  for (const b of cfg.blocks) if (b.type === "message") b.body = SECRET_TEXT;
  const saved = await saveEdits(s.draft, cfg);
  if (!saved.ok) throw new Error("save");
  return { draft: s.draft, cfg };
}

const lockIn = (ms: number, timezone = "Asia/Kolkata") => ({ mode: "lock", unlockAt: iso(nowMs() + ms), timezone });

async function status(slug: string, headers: Record<string, string> = {}) {
  const res = await statusRoute(
    new Request(`http://localhost/api/greeting/${slug}/status`, { headers: { "x-forwarded-for": "203.0.113.50", ...headers } }),
    { params: Promise.resolve({ slug }) },
  );
  return { status: res.status, text: await res.text(), cache: res.headers.get("cache-control") ?? "" };
}

async function main() {
  // =============== time helpers
  const kol = zonedWallToUtc("2027-02-14", "19:00", "Asia/Kolkata");
  check("Kolkata 19:00 is 13:30 UTC", kol?.toISOString() === "2027-02-14T13:30:00.000Z", String(kol?.toISOString()));
  const ny = zonedWallToUtc("2027-07-04", "09:00", "America/New_York");
  check("New York 09:00 in July (daylight time) is 13:00 UTC", ny?.toISOString() === "2027-07-04T13:00:00.000Z", String(ny?.toISOString()));
  const nyw = zonedWallToUtc("2027-01-04", "09:00", "America/New_York");
  check("New York 09:00 in January (standard time) is 14:00 UTC", nyw?.toISOString() === "2027-01-04T14:00:00.000Z");
  check("a wall time that doesn't exist (spring-forward gap) is rejected", zonedWallToUtc("2027-03-14", "02:30", "America/New_York") === null);
  check("an impossible date is rejected", zonedWallToUtc("2027-02-30", "10:00", "Asia/Kolkata") === null);
  check("an unknown time zone is rejected", zonedWallToUtc("2027-02-14", "10:00", "Mars/Olympus") === null);
  check("the same instant reads differently per zone",
    formatInZone(kol!.getTime(), "Asia/Kolkata", { timeZoneName: undefined }).includes("7:00") &&
    formatInZone(kol!.getTime(), "Europe/London", { timeZoneName: undefined }).includes("1:30"));
  const sr = splitRemaining(2 * 86400_000 + 3 * 3600_000 + 4 * 60_000 + 5_000);
  check("remaining time splits into days/hours/minutes/seconds", sr.days === 2 && sr.hours === 3 && sr.minutes === 4 && sr.seconds === 5);
  check("remaining time never goes negative", splitRemaining(-5000).seconds === 0);
  const t0 = new Date();
  check("rule: past time refused", checkUnlock(new Date(t0.getTime() - 1000), t0) === "past");
  check("rule: under a minute refused", checkUnlock(new Date(t0.getTime() + 30_000), t0) === "tooSoon");
  check("rule: over a year refused", checkUnlock(new Date(t0.getTime() + 400 * 86400_000), t0) === "tooFar");
  check("rule: a day ahead accepted", checkUnlock(new Date(t0.getTime() + 86400_000), t0) === null);

  // =============== OPTION 1: publish immediately
  const a = await newPublishable();
  const pa = await publishGreeting(a.draft, { mode: "now" });
  check("publish now succeeds", pa.ok);
  if (!pa.ok) return summary("delivery");
  check("publish now reports no lock", pa.unlockAt === null);
  const va = await loadViewerState(pa.slug);
  check("publish now: content is open straight away, no countdown", va.kind === "open");
  check("publish now: the viewer sees the real message", va.kind === "open" && JSON.stringify(va.data.config).includes(SECRET_TEXT));
  check("old callers (no schedule argument) still publish immediately", (await publishGreeting((await (async () => { const x = await newPublishable(); return x.draft; })()))).ok);

  // =============== OPTION 2: validation (server-side, against the server clock)
  const b = await newPublishable();
  const bad = async (name: string, s: unknown) => check(name, !(await publishGreeting(b.draft, s)).ok);
  await bad("lock in the past is refused", lockIn(-60_000));
  await bad("lock under a minute ahead is refused", lockIn(20_000));
  await bad("lock more than a year ahead is refused", lockIn(400 * 86400_000));
  await bad("lock with an unknown time zone is refused", lockIn(3600_000, "Nowhere/Land"));
  await bad("lock with a malformed date is refused", { mode: "lock", unlockAt: "tomorrow-ish", timezone: "Asia/Kolkata" });
  await bad("lock with extra fields is refused", { ...lockIn(3600_000), html: "<script>" });
  await bad("an unknown mode is refused", { mode: "sometime" });
  check("none of the refused attempts published anything", (await getStore().getOwned(b.draft.id, b.draft.token)).published === false);

  // a lying browser clock cannot help: the server only looks at the instant the browser sends
  const liar = await publishGreeting(b.draft, { mode: "lock", unlockAt: iso(nowMs() - 5 * 86400_000), timezone: "Asia/Kolkata" });
  check("a browser that believes it is 5 days ago still can't schedule in the past", !liar.ok);

  // =============== OPTION 2: locked state
  const UNLOCK_IN = 3 * 3600_000;
  const c = await newPublishable();
  const when = nowMs() + UNLOCK_IN;
  const pc = await publishGreeting(c.draft, { mode: "lock", unlockAt: iso(when), timezone: "Asia/Kolkata" });
  check("lock publish succeeds and returns the link immediately", pc.ok && pc.url.endsWith(`/w/${pc.ok ? pc.slug : ""}`));
  if (!pc.ok) return summary("delivery");
  check("the result carries the unlock instant (UTC) and the zone", pc.unlockAt === iso(when) && pc.unlockTimezone === "Asia/Kolkata");

  const vc = await loadViewerState(pc.slug);
  check("before unlock the viewer state is locked", vc.kind === "locked");
  const lockedJson = JSON.stringify(vc);
  check("locked state contains no message text", !lockedJson.includes(SECRET_TEXT));
  check("locked state contains no recipient or sender name", !lockedJson.includes(SECRET_NAME) && !lockedJson.includes("Arjun"));
  check("locked state contains no configuration, blocks or assets", !/blocks|configuration|assetIds|headline|palette|"assets"/.test(lockedJson));
  check("locked state carries the unlock instant and server time",
    vc.kind === "locked" && vc.lock.unlockAt === iso(when) && !Number.isNaN(Date.parse(vc.lock.serverNow)));
  check("loadViewerData (content) is null while locked", (await loadViewerData(pc.slug)) === null);
  check("store.getPublishedBySlug (content) is null while locked", (await getStore().getPublishedBySlug(pc.slug)) === null);
  check("the link stays the same (unique slug unchanged)", vc.kind === "locked" && pc.slug.length === 10);

  // public status API
  const sc = await status(pc.slug);
  check("status API says locked", sc.status === 200 && JSON.parse(sc.text).state === "locked");
  check("status API response holds no private content", !sc.text.includes(SECRET_TEXT) && !sc.text.includes(SECRET_NAME) && !/blocks|configuration|assetIds/.test(sc.text));
  check("status API is never cached", sc.cache.includes("no-store"));
  const spoof = await status(pc.slug, { "x-client-time": iso(when + 99999), date: new RealDate(when + 99999).toUTCString(), "if-modified-since": new RealDate(when + 99999).toUTCString() });
  check("a spoofed client clock/headers cannot open the lock", JSON.parse(spoof.text).state === "locked");
  const queryAttempt = await statusRoute(new Request(`http://localhost/api/greeting/${pc.slug}/status?now=${when + 99999}&unlocked=1`, { headers: { "x-forwarded-for": "203.0.113.51" } }), { params: Promise.resolve({ slug: pc.slug }) });
  check("query-string tricks cannot open the lock", JSON.parse(await queryAttempt.text()).state === "locked");
  check("status for a malformed slug is 404", (await status("../etc/passwd")).status === 404);
  check("status for an unknown slug is 404", (await status("Zzzzzzzzzz")).status === 404);

  // a locked greeting cannot be reported (nothing visible to report) and leaks nothing doing so
  resetRateLimits();
  const rep = await reportRoute(new Request("http://localhost/api/report", { method: "POST", headers: { "content-type": "application/json", "x-forwarded-for": "203.0.113.60" }, body: JSON.stringify({ slug: pc.slug, reason: "other" }) }));
  check("a locked greeting can't be probed through the report endpoint", rep.status === 404 && !(await rep.text()).includes(SECRET_TEXT));

  // refresh / another device: the state is the same for every request, nothing is per-device
  const again = await loadViewerState(pc.slug);
  check("refreshing before unlock: still locked, same unlock instant", again.kind === "locked" && again.lock.unlockAt === iso(when));

  // the creator sees the schedule in manage
  const owned = await loadOwned(c.draft);
  check("manage shows the schedule", owned.ok && owned.greeting.unlockAt === iso(when) && owned.greeting.unlockTimezone === "Asia/Kolkata");

  // =============== creator edits a scheduled greeting before it unlocks
  const edited: ExperienceConfig = JSON.parse(JSON.stringify(c.cfg));
  for (const blk of edited.blocks) if (blk.type === "message") blk.body = "Edited while locked.";
  check("creator can edit a scheduled greeting", (await saveEdits(c.draft, edited)).ok);
  check("editing does not unlock it", (await loadViewerState(pc.slug)).kind === "locked");
  check("editing keeps the same unlock time", (await loadOwned(c.draft)).ok && ((await loadOwned(c.draft)) as { greeting: { unlockAt: string } }).greeting.unlockAt === iso(when));

  // reschedule while locked
  const later = nowMs() + 6 * 3600_000;
  const rs = await rescheduleOwned(c.draft, { mode: "lock", unlockAt: iso(later), timezone: "Europe/London" });
  check("creator can move the unlock time while locked", rs.ok && rs.unlockAt === iso(later) && rs.unlockTimezone === "Europe/London");
  check("rescheduling into the past is refused", !(await rescheduleOwned(c.draft, { mode: "lock", unlockAt: iso(nowMs() - 1000), timezone: "Asia/Kolkata" })).ok);
  check("a wrong token can't reschedule", !(await rescheduleOwned({ id: c.draft.id, token: "Q".repeat(43) }, { mode: "now" })).ok);
  check("an immediately-open greeting can't be locked afterwards",
    !(await rescheduleOwned(a.draft, lockIn(3600_000))).ok);

  // =============== time passes on the server
  advance(later - nowMs() - 1000);        // 1 s before the unlock (margin for real elapsed time)
  check("1 s before unlock: still locked", (await loadViewerState(pc.slug)).kind === "locked");
  check("1 s before unlock: status still says locked", JSON.parse((await status(pc.slug)).text).state === "locked");
  advance(1000);                           // at (just past) the unlock instant
  check("exactly at unlock: open", (await loadViewerState(pc.slug)).kind === "open");
  check("exactly at unlock: status says open", JSON.parse((await status(pc.slug)).text).state === "open");
  const opened = await loadViewerState(pc.slug);
  check("after unlock the edited message is what the recipient sees",
    opened.kind === "open" && JSON.stringify(opened.data.config).includes("Edited while locked.") && !JSON.stringify(opened.data.config).includes(SECRET_TEXT));
  advance(5 * 86400_000);
  check("opening the link long after the time: opens immediately", (await loadViewerState(pc.slug)).kind === "open");
  check("an opened greeting can't be re-locked", !(await rescheduleOwned(c.draft, lockIn(3600_000))).ok);
  check("direct content read works after unlock", (await loadViewerData(pc.slug)) !== null);

  // =============== unlock-now by the creator (a locked greeting only)
  const d = await newPublishable();
  const pd = await publishGreeting(d.draft, lockIn(2 * 3600_000));
  if (!pd.ok) return summary("delivery");
  check("locked greeting starts locked", (await loadViewerState(pd.slug)).kind === "locked");
  check("the creator can open it right now", (await rescheduleOwned(d.draft, { mode: "now" })).ok);
  check("after 'open now' the content is visible", (await loadViewerState(pd.slug)).kind === "open");

  // =============== creator offline: the link keeps working with no creator involvement
  const e = await newPublishable();
  const pe = await publishGreeting(e.draft, lockIn(90_000));
  if (!pe.ok) return summary("delivery");
  advance(91_000);
  check("unlock needs no creator action (no job, no token): it just opens", (await loadViewerState(pe.slug)).kind === "open");

  // =============== hidden / expired still win over an unlocked time
  const h = await newPublishable();
  const ph = await publishGreeting(h.draft, lockIn(120_000));
  if (!ph.ok) return summary("delivery");
  await getStore().setHidden(h.draft.id, true, "test");
  advance(200_000);
  check("a hidden greeting stays hidden after its unlock time", (await loadViewerState(ph.slug)).kind === "missing");
  check("a hidden greeting never reveals a countdown either", (await status(ph.slug)).status === 404);

  // =============== same greeting experience in both modes
  const same = await newPublishable();
  const pi = await publishGreeting(same.draft, { mode: "now" });
  const same2 = await newPublishable();
  const pl = await publishGreeting(same2.draft, lockIn(90_000));
  if (!pi.ok || !pl.ok) return summary("delivery");
  const imm = await loadViewerState(pi.slug);
  check("parity: locked greeting shows no content before unlock", (await loadViewerState(pl.slug)).kind === "locked");
  advance(95_000);
  const unl = await loadViewerState(pl.slug);
  check("parity: both modes end up open", imm.kind === "open" && unl.kind === "open");
  if (imm.kind === "open" && unl.kind === "open") {
    check("parity: identical config (design, blocks, message, theme) in both modes", JSON.stringify(imm.data.config) === JSON.stringify(unl.data.config));
    check("parity: same photo asset handling", JSON.stringify(Object.keys(imm.data.assets)) === JSON.stringify(Object.keys(unl.data.assets)));
  }

  summary("delivery");
}

main().catch((err) => { console.error(err); process.exit(1); });
