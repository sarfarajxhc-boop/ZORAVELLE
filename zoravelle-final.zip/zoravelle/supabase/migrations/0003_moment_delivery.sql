-- Moment Delivery System: a greeting can be published now but stay locked until a UTC instant.
--
-- The lock is enforced HERE, in the database, not just in application code: the public (anon) role
-- can read `configuration` and `message` through the API, so the read policy itself must refuse a
-- row until unlock_at has passed. unlock_at is stored in UTC; unlock_timezone only records how the
-- creator wanted the time displayed.

alter table public.experiences
  add column unlock_at       timestamptz,
  add column unlock_timezone text;

alter table public.experiences
  add constraint experiences_unlock_tz_len check (unlock_timezone is null or char_length(unlock_timezone) between 1 and 64),
  add constraint experiences_unlock_needs_tz check (unlock_at is null or unlock_timezone is not null),
  add constraint experiences_unlock_before_expiry check (unlock_at is null or expires_at is null or unlock_at < expires_at);

-- unlock_at / unlock_timezone are intentionally NOT granted to anon or authenticated.

drop policy experiences_public_read on public.experiences;
create policy experiences_public_read on public.experiences
  for select to anon, authenticated
  using (
    published
    and hidden_at is null
    and (expires_at is null or expires_at > now())
    and (unlock_at is null or unlock_at <= now())
  );
