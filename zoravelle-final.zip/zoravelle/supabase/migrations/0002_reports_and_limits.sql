-- Abuse reports and database-backed rate limits.
-- Both are server-only: RLS is on with no policies, so browser roles get nothing.

-- -------------------------------------------------------------------- reports
create table public.reports (
  id            uuid primary key default gen_random_uuid(),
  experience_id uuid not null references public.experiences (id) on delete cascade,
  reason        text not null check (reason in ('harassment', 'hate', 'sexual', 'scam', 'privacy', 'other')),
  details       text check (details is null or char_length(details) <= 500),
  created_at    timestamptz not null default now(),
  resolved_at   timestamptz
);
create index reports_open_idx on public.reports (created_at desc) where resolved_at is null;
create index reports_experience_idx on public.reports (experience_id);

alter table public.reports enable row level security;
revoke all on public.reports from anon, authenticated;
grant all on public.reports to service_role;

-- ---------------------------------------------------------------- rate limits
create table public.rate_limit_hits (
  key    text        not null check (char_length(key) between 1 and 120),
  hit_at timestamptz not null default now()
);
create index rate_limit_hits_key_idx on public.rate_limit_hits (key, hit_at);

alter table public.rate_limit_hits enable row level security;
revoke all on public.rate_limit_hits from anon, authenticated;
grant all on public.rate_limit_hits to service_role;

-- Sliding window. Serialised per key with an advisory lock so concurrent
-- requests on different server instances can't both slip under the limit.
create function public.rate_limit_hit(p_key text, p_limit integer, p_window_seconds integer)
returns table (ok boolean, retry_after_sec integer)
language plpgsql
security invoker
set search_path = public, pg_temp
as $$
declare
  v_count  integer;
  v_oldest timestamptz;
begin
  if p_limit < 1 or p_window_seconds < 1 then
    raise exception 'invalid rate limit arguments';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(p_key, 0));

  delete from public.rate_limit_hits
   where key = p_key and hit_at < now() - make_interval(secs => p_window_seconds);

  select count(*), min(hit_at) into v_count, v_oldest
    from public.rate_limit_hits where key = p_key;

  if v_count >= p_limit then
    return query select false,
      greatest(1, ceil(extract(epoch from (v_oldest + make_interval(secs => p_window_seconds) - now())))::integer);
    return;
  end if;

  insert into public.rate_limit_hits (key) values (p_key);
  return query select true, 0;
end;
$$;

-- Housekeeping for keys that are never seen again. Called by the scheduled purge.
create function public.purge_rate_limit_hits() returns integer
language sql
security invoker
set search_path = public, pg_temp
as $$
  with d as (delete from public.rate_limit_hits where hit_at < now() - interval '1 day' returning 1)
  select count(*)::integer from d;
$$;

revoke execute on function public.rate_limit_hit(text, integer, integer) from public, anon, authenticated;
revoke execute on function public.purge_rate_limit_hits()                from public, anon, authenticated;
grant  execute on function public.rate_limit_hit(text, integer, integer) to service_role;
grant  execute on function public.purge_rate_limit_hits()                to service_role;
