-- ZORAVELLE: initial schema.
--
-- Security model
--   * All writes happen on the server with the service-role key, after the app
--     has validated input and checked the creator's edit token. The service role
--     bypasses Row Level Security.
--   * The browser roles (anon, authenticated) can only read experiences that are
--     published, not hidden, and not expired, and only a safe subset of columns.
--     The edit-token hash is never readable by them.
--   * assets and generations have RLS enabled and no policies for browser roles,
--     which means no access at all. Photos live in a private bucket and are
--     served to viewers through short-lived signed URLs created on the server.

-- ---------------------------------------------------------------- experiences
create table public.experiences (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null,
  occasion        text not null,
  recipient_name  text not null,
  sender_name     text not null,
  message         text,
  theme           text,
  configuration   jsonb,
  published       boolean not null default false,
  published_at    timestamptz,
  edit_token_hash text not null,
  hidden_at       timestamptz,
  hidden_reason   text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  expires_at      timestamptz,

  constraint experiences_slug_format        check (slug ~ '^[0-9A-Za-z]{10}$'),
  constraint experiences_occasion_format    check (occasion ~ '^[a-z0-9-]{2,40}$'),
  constraint experiences_recipient_len      check (char_length(recipient_name) between 1 and 60),
  constraint experiences_sender_len         check (char_length(sender_name) between 1 and 60),
  constraint experiences_message_len        check (message is null or char_length(message) <= 1200),
  constraint experiences_theme_len          check (theme is null or char_length(theme) <= 40),
  constraint experiences_config_is_object   check (configuration is null or jsonb_typeof(configuration) = 'object'),
  constraint experiences_config_size        check (configuration is null or octet_length(configuration::text) <= 65536),
  constraint experiences_published_has_conf check (not published or configuration is not null),
  constraint experiences_token_hash_format  check (edit_token_hash ~ '^[0-9a-f]{64}$')
);

create unique index experiences_slug_key on public.experiences (slug);
-- Newest published greetings (admin lists, future gallery).
create index experiences_published_created_idx
  on public.experiences (created_at desc) where published and hidden_at is null;
-- Expiry sweeps.
create index experiences_expires_idx
  on public.experiences (expires_at) where expires_at is not null;
create index experiences_created_idx on public.experiences (created_at desc);

create function public.set_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin
  new.updated_at := clock_timestamp();
  return new;
end $$;

create trigger experiences_set_updated_at
  before update on public.experiences
  for each row execute function public.set_updated_at();

-- --------------------------------------------------------------------- assets
create table public.assets (
  id            uuid primary key default gen_random_uuid(),
  experience_id uuid not null references public.experiences (id) on delete cascade,
  file_path     text not null unique,
  asset_type    text not null default 'image' check (asset_type in ('image')),
  mime_type     text not null check (mime_type = 'image/webp'),
  byte_size     integer not null check (byte_size between 1 and 5242880),
  created_at    timestamptz not null default now(),

  -- "<experience uuid>/<asset uuid>.webp"
  constraint assets_path_format check (
    file_path ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\.webp$'
  )
);

create index assets_experience_idx on public.assets (experience_id);

-- At most 6 photos per experience. Locking the parent row makes concurrent
-- uploads queue up so they cannot both slip past the limit.
create function public.enforce_asset_limit() returns trigger
language plpgsql set search_path = '' as $$
begin
  perform 1 from public.experiences where id = new.experience_id for update;
  if (select count(*) from public.assets where experience_id = new.experience_id) >= 6 then
    raise exception 'asset limit reached' using errcode = 'check_violation';
  end if;
  return new;
end $$;

create trigger assets_enforce_limit
  before insert on public.assets
  for each row execute function public.enforce_asset_limit();

-- ---------------------------------------------------------------- generations
-- One row per generation attempt. Deliberately stores no prompt or user text.
create table public.generations (
  id            uuid primary key default gen_random_uuid(),
  experience_id uuid not null references public.experiences (id) on delete cascade,
  provider      text not null check (char_length(provider) between 1 and 40),
  status        text not null check (status in ('success', 'fallback', 'failed')),
  duration_ms   integer check (duration_ms is null or duration_ms >= 0),
  created_at    timestamptz not null default now()
);

create index generations_experience_idx on public.generations (experience_id, created_at desc);
create index generations_created_idx on public.generations (created_at desc);

-- ------------------------------------------------------- Row Level Security
alter table public.experiences enable row level security;
alter table public.assets      enable row level security;
alter table public.generations enable row level security;

-- Start from nothing for browser roles (Supabase grants broad defaults).
revoke all on public.experiences from anon, authenticated;
revoke all on public.assets      from anon, authenticated;
revoke all on public.generations from anon, authenticated;

-- Column-level grant: everything a viewer needs, and NOT edit_token_hash,
-- hidden_reason, hidden_at or updated_at. `select *` therefore fails for them.
grant select (id, slug, occasion, recipient_name, sender_name, message, theme,
              configuration, published_at, created_at, expires_at)
  on public.experiences to anon, authenticated;

create policy experiences_public_read on public.experiences
  for select to anon, authenticated
  using (published and hidden_at is null and (expires_at is null or expires_at > now()));

-- No policies on assets / generations: browser roles are denied by default.

-- Trigger functions are not meant to be called directly by anyone.
revoke execute on function public.set_updated_at()      from public, anon, authenticated;
revoke execute on function public.enforce_asset_limit() from public, anon, authenticated;

-- The server (service role) does all writes.
grant usage on schema public to service_role;
grant all on public.experiences, public.assets, public.generations to service_role;

-- -------------------------------------------------------------------- storage
-- Private bucket. Files are re-encoded to WebP by the server before upload.
-- No policies are added on storage.objects, so browser roles cannot read or
-- write; the server uses the service role and hands out signed URLs.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('experience-assets', 'experience-assets', false, 5242880, array['image/webp'])
on conflict (id) do update
  set public = false,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;
