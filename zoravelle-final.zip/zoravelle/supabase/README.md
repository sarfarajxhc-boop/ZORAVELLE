# Supabase setup

ZORAVELLE stores greetings in Postgres and photos in a private Storage bucket. This folder holds the schema (`migrations/`) and the SQL tests (`tests/`). The step-by-step click guide for a first-time deployer is in [../DEPLOY.md](../DEPLOY.md); this file explains what the database contains and how it is protected.

## 1. Create a project and apply the migrations

1. Create a project at supabase.com (for India: region Mumbai, `ap-south-1`).
2. Open **SQL Editor** and run these files **in this order**, each as its own query (or use the Supabase CLI: `supabase link` then `supabase db push`):

| Order | File | Adds |
| --- | --- | --- |
| 1 | `migrations/0001_init.sql` | tables `experiences`, `assets`, `generations`; row-level security; column grants; the **private** storage bucket `experience-assets` |
| 2 | `migrations/0002_reports_and_limits.sql` | abuse `reports` table; database-backed rate limits (`rate_limit_hits`, functions `rate_limit_hit` and `purge_rate_limit_hits`) |
| 3 | `migrations/0003_moment_delivery.sql` | `unlock_at` and `unlock_timezone` columns for locked greetings, their constraints, and the updated read policy that refuses a row before its unlock time |

Run them once. Running a migration twice fails with "already exists", which is harmless but means it was already applied.

3. Check in the dashboard: tables `experiences`, `assets`, `generations`, `reports`, `rate_limit_hits` with RLS enabled, and a **private** bucket named `experience-assets`. After the app is deployed, `https://YOUR-SITE/api/health` also reports whether each migration is present.

## 2. Environment variables (`.env.local`, and in Vercel)

| Variable | Where it comes from | Exposure |
| --- | --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Project settings → API | Public |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Project settings → API (anon / publishable) | Public, limited by RLS |
| `SUPABASE_SERVICE_ROLE_KEY` | Project settings → API (service_role / secret) | **Server only. Never prefix with `NEXT_PUBLIC_`. Never paste it in chat or commit it** |

With the URL and the service-role key set, the app uses Supabase. Otherwise it uses the in-memory demo store, which is lost on restart and is not shared between serverless instances (photo uploads and links are unreliable on Vercel in that mode).

## 3. Security model

- Browser roles (`anon`, `authenticated`) can only `select` the columns a viewer needs, and only rows that are **published, not hidden, not expired and past their unlock time**. They cannot read `edit_token_hash`, `unlock_at` or `unlock_timezone`, cannot use `select *`, and cannot insert, update or delete.
- **The lock is enforced in the database.** The read policy in migration 0003 refuses a locked row to the public role, so even a direct call to the Supabase API with the public anon key cannot return a locked greeting's message, configuration or photos. The app additionally decides lock state on the server (with the server clock, never the visitor's) and produces no photo URLs while locked.
- `assets`, `generations`, `reports` and `rate_limit_hits` have RLS on and no policies: browser roles get nothing.
- The storage bucket is private with no policies. The server uploads with the service role and serves photos through signed URLs that expire after an hour.
- Every write goes through the app's server code with the service-role key, after input validation and a check of the greeting's private edit token (only its SHA-256 hash is stored).
- Takedowns: set `hidden_at` (the store exposes `setHidden`, used by `/admin`). The greeting stops opening immediately.

## 4. Testing the schema

`tests/01_schema_and_rls.test.sql` (45 assertions), `tests/02_reports_and_limits.test.sql` (26) and `tests/03_moment_delivery.test.sql` (15) check the policies, column grants, constraints, triggers, cascades, rate limits and the unlock rule. They need a Postgres that has the Supabase roles; on a plain local Postgres 16:

```bash
createdb wc
psql -v ON_ERROR_STOP=1 -d wc -f supabase/tests/00_local_prelude.sql   # local only; never run this on Supabase
psql -v ON_ERROR_STOP=1 -d wc -f supabase/migrations/0001_init.sql
psql -v ON_ERROR_STOP=1 -d wc -f supabase/migrations/0002_reports_and_limits.sql
psql -v ON_ERROR_STOP=1 -d wc -f supabase/migrations/0003_moment_delivery.sql
psql -v ON_ERROR_STOP=1 -d wc -f supabase/tests/01_schema_and_rls.test.sql
psql -v ON_ERROR_STOP=1 -d wc -f supabase/tests/02_reports_and_limits.test.sql
psql -v ON_ERROR_STOP=1 -d wc -f supabase/tests/03_moment_delivery.test.sql
```

These all pass on Postgres 16. To test the app's Supabase code against a real project, use a **development** project (never production): put its values in `.env.local` and run `RUN_SUPABASE_CONTRACT=1 npm run test:store`. That code path has never been run against a live Supabase project, so expect to fix small things the first time.

## 5. Known limits

- Expired greetings and abandoned drafts (older than 7 days) are removed by the daily `/api/cron/purge` job (see `vercel.json`), 200 per run, and the job also trims old rate-limit rows.
- Greetings never expire by default. Pass `expiresAt` to `createDraft` if you want a retention period.
- Edit-token links are bearer secrets: anyone who has the link can edit that greeting. There is no recovery if it is lost.
- Photo uploads are limited to 6 per greeting and 5 MB each.
- Rate limits are counted in Postgres through `rate_limit_hit`; if that call fails, the request falls back to a per-instance in-memory counter.
