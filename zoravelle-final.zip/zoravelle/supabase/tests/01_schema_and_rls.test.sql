-- Run: psql -v ON_ERROR_STOP=1 -f supabase/tests/01_schema_and_rls.test.sql
-- Assumes 0001_init.sql has been applied. Everything is rolled back at the end.
-- Any failed assertion raises an exception, so psql exits non-zero.
begin;

create schema t;
grant usage on schema t to public;

create function t.expect_err(sql text, code text, label text, cname text default null) returns void
language plpgsql as $$
declare got text := null; cn text := null;
begin
  begin
    execute sql;
  exception when others then
    got := sqlstate;
    get stacked diagnostics cn = constraint_name;
  end;
  if got is null then
    raise exception 'FAIL: % (expected error %, got none)', label, code;
  elsif got <> code then
    raise exception 'FAIL: % (expected %, got %)', label, code, got;
  elsif cname is not null and cn is distinct from cname then
    raise exception 'FAIL: % (expected constraint %, got %)', label, cname, cn;
  end if;
  raise notice 'PASS: %', label;
end $$;

create function t.expect_rows(sql text, n bigint, label text) returns void
language plpgsql as $$
declare c bigint;
begin
  execute 'select count(*) from (' || sql || ') q' into c;
  if c <> n then
    raise exception 'FAIL: % (expected % rows, got %)', label, n, c;
  end if;
  raise notice 'PASS: %', label;
end $$;

create function t.expect_true(cond boolean, label text) returns void
language plpgsql as $$
begin
  if cond is not true then raise exception 'FAIL: %', label; end if;
  raise notice 'PASS: %', label;
end $$;

create function t.add_asset(exp uuid) returns void language plpgsql as $$
declare aid uuid := gen_random_uuid();
begin
  insert into public.assets (id, experience_id, file_path, mime_type, byte_size)
  values (aid, exp, exp::text || '/' || aid::text || '.webp', 'image/webp', 1000);
end $$;
grant execute on function t.add_asset(uuid) to public;

grant execute on all functions in schema t to public;

-- ------------------------------------------------------------ fixtures
set local role service_role;

insert into public.experiences (slug, occasion, recipient_name, sender_name, configuration, published, edit_token_hash)
values ('PublicOne1', 'birthday', 'Maya', 'Arjun', '{"version":1}', true, repeat('a', 64));

insert into public.experiences (slug, occasion, recipient_name, sender_name, configuration, published, expires_at, edit_token_hash)
values ('FutureOne1', 'eid', 'Sana', 'Dev', '{"version":1}', true, now() + interval '1 day', repeat('b', 64));

insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash)
values ('DraftOne01', 'diwali', 'Priya', 'Rohan', repeat('c', 64));

insert into public.experiences (slug, occasion, recipient_name, sender_name, configuration, published, expires_at, edit_token_hash)
values ('ExpiredOne', 'holi', 'A', 'B', '{"version":1}', true, now() - interval '1 second', repeat('d', 64));

insert into public.experiences (slug, occasion, recipient_name, sender_name, configuration, published, hidden_at, edit_token_hash)
values ('HiddenOne1', 'christmas', 'C', 'D', '{"version":1}', true, now(), repeat('e', 64));

select t.expect_rows('select 1 from public.experiences', 5, 'service role sees all 5 fixtures');

-- ---------------------------------------------------- anon (the public)
reset role;
set local role anon;

select t.expect_rows('select slug from public.experiences', 2,
  'anon sees only published + not hidden + not expired');
select t.expect_rows($$select slug from public.experiences where slug = 'DraftOne01'$$, 0,
  'anon cannot see an unpublished draft');
select t.expect_rows($$select slug from public.experiences where slug = 'ExpiredOne'$$, 0,
  'anon cannot see an expired experience');
select t.expect_rows($$select slug from public.experiences where slug = 'HiddenOne1'$$, 0,
  'anon cannot see a hidden (taken down) experience');
select t.expect_rows('select id, slug, occasion, recipient_name, sender_name, message, theme, configuration, published_at, created_at, expires_at from public.experiences', 2,
  'anon can read the viewer columns');
select t.expect_err('select edit_token_hash from public.experiences', '42501',
  'anon cannot read edit_token_hash');
select t.expect_err('select * from public.experiences', '42501',
  'anon cannot use select * (includes private columns)');
select t.expect_err('select hidden_reason from public.experiences', '42501',
  'anon cannot read hidden_reason');
select t.expect_err($$select slug from public.experiences where edit_token_hash like 'a%'$$, '42501',
  'anon cannot probe edit_token_hash through a WHERE clause');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash) values ('Hacker0001','x1','a','b',repeat('f',64))$$, '42501',
  'anon cannot insert experiences');
select t.expect_err($$update public.experiences set recipient_name = 'pwned'$$, '42501',
  'anon cannot update experiences');
select t.expect_err('delete from public.experiences', '42501',
  'anon cannot delete experiences');
select t.expect_err('select count(*) from public.assets', '42501', 'anon cannot read assets');
select t.expect_err('select count(*) from public.generations', '42501', 'anon cannot read generations');

-- -------------------------------------------------------- authenticated
reset role;
set local role authenticated;

select t.expect_rows('select slug from public.experiences', 2, 'authenticated sees only public experiences');
select t.expect_err('select edit_token_hash from public.experiences', '42501',
  'authenticated cannot read edit_token_hash');
select t.expect_err($$update public.experiences set recipient_name = 'pwned'$$, '42501',
  'authenticated cannot update experiences');
select t.expect_err('select count(*) from public.assets', '42501', 'authenticated cannot read assets');

-- ------------------------------------------------- storage: deny by default
reset role;
insert into storage.objects (bucket_id, name) values ('experience-assets', 'x/y.webp');
set local role anon;
select t.expect_rows('select 1 from storage.objects', 0,
  'anon sees no storage objects (RLS on, no policies)');
select t.expect_err($$insert into storage.objects (bucket_id, name) values ('experience-assets','evil.webp')$$, '42501',
  'anon cannot upload to storage');
reset role;
select t.expect_true((select public = false and file_size_limit = 5242880 and allowed_mime_types = array['image/webp']
                      from storage.buckets where id = 'experience-assets'),
  'bucket is private, 5 MB, webp only');

-- ------------------------------------------------ constraints (service role)
set local role service_role;

select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash) values ('short','birthday','a','b',repeat('a',64))$$, '23514', 'bad slug rejected', 'experiences_slug_format');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash) values ('has-dash-1','birthday','a','b',repeat('a',64))$$, '23514', 'slug with symbols rejected', 'experiences_slug_format');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, configuration, published, edit_token_hash) values ('PublicOne1','birthday','a','b','{}',false,repeat('a',64))$$, '23505', 'duplicate slug rejected', 'experiences_slug_key');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, published, edit_token_hash) values ('NoConfig01','birthday','a','b',true,repeat('a',64))$$, '23514', 'cannot publish without configuration', 'experiences_published_has_conf');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, configuration, edit_token_hash) values ('ArrayConf1','birthday','a','b','[1]',repeat('a',64))$$, '23514', 'configuration must be an object', 'experiences_config_is_object');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, configuration, edit_token_hash) values ('BigConf001','birthday','a','b',jsonb_build_object('x', repeat('a', 70000)),repeat('a',64))$$, '23514', 'oversized configuration rejected', 'experiences_config_size');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash) values ('BadHash001','birthday','a','b','not-a-hash')$$, '23514', 'malformed token hash rejected', 'experiences_token_hash_format');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash) values ('EmptyName1','birthday','','b',repeat('a',64))$$, '23514', 'empty recipient name rejected', 'experiences_recipient_len');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash) values ('LongName01','birthday',repeat('a',61),'b',repeat('a',64))$$, '23514', '61-char recipient name rejected', 'experiences_recipient_len');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, message, edit_token_hash) values ('LongMsg001','birthday','a','b',repeat('a',1201),repeat('a',64))$$, '23514', '1201-char message rejected', 'experiences_message_len');
select t.expect_err($$insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash) values ('BadOccas01','Birth Day','a','b',repeat('a',64))$$, '23514', 'malformed occasion rejected', 'experiences_occasion_format');

-- assets
create temp table ctx as select id from public.experiences where slug = 'DraftOne01';
grant select on ctx to service_role;

select t.add_asset((select id from ctx)) from generate_series(1, 6);
select t.expect_rows('select 1 from public.assets', 6, 'six assets accepted');
select t.expect_err($$select t.add_asset((select id from ctx))$$, '23514', 'seventh asset rejected');
select t.expect_err($$insert into public.assets (experience_id, file_path, mime_type, byte_size) select id, 'evil.php', 'image/webp', 10 from public.experiences where slug = 'PublicOne1'$$, '23514', 'asset path must match <uuid>/<uuid>.webp', 'assets_path_format');
select t.expect_err($$insert into public.assets (experience_id, file_path, mime_type, byte_size) select id, id::text || '/' || gen_random_uuid()::text || '.webp', 'image/svg+xml', 10 from public.experiences where slug = 'PublicOne1'$$, '23514', 'non-webp asset rejected', 'assets_mime_type_check');
select t.expect_err($$insert into public.assets (experience_id, file_path, mime_type, byte_size) select id, id::text || '/' || gen_random_uuid()::text || '.webp', 'image/webp', 6000000 from public.experiences where slug = 'PublicOne1'$$, '23514', 'oversized asset rejected', 'assets_byte_size_check');

-- generations
insert into public.generations (experience_id, provider, status, duration_ms)
select id, 'anthropic', 'success', 1200 from ctx;
select t.expect_err($$insert into public.generations (experience_id, provider, status) select id, 'x', 'weird' from ctx$$, '23514', 'unknown generation status rejected', 'generations_status_check');

-- updated_at trigger
select pg_sleep(0.02);
update public.experiences set theme = 'Updated' where slug = 'PublicOne1';
select t.expect_true((select updated_at > created_at from public.experiences where slug = 'PublicOne1'), 'updated_at advances on update');

-- cascade
delete from public.experiences where slug = 'DraftOne01';
select t.expect_rows('select 1 from public.assets', 0, 'deleting an experience cascades to its assets');
select t.expect_rows('select 1 from public.generations', 0, 'deleting an experience cascades to its generations');

-- anon sees an experience the moment it is published, and loses it when hidden
reset role;
set local role service_role;
insert into public.experiences (slug, occasion, recipient_name, sender_name, edit_token_hash)
values ('Lifecycle1', 'wedding', 'E', 'F', repeat('9', 64));
reset role; set local role anon;
select t.expect_rows($$select 1 from public.experiences where slug = 'Lifecycle1'$$, 0, 'lifecycle: draft invisible');
reset role; set local role service_role;
update public.experiences set published = true, configuration = '{"version":1}' where slug = 'Lifecycle1';
reset role; set local role anon;
select t.expect_rows($$select 1 from public.experiences where slug = 'Lifecycle1'$$, 1, 'lifecycle: visible once published');
reset role; set local role service_role;
update public.experiences set hidden_at = now(), hidden_reason = 'test' where slug = 'Lifecycle1';
reset role; set local role anon;
select t.expect_rows($$select 1 from public.experiences where slug = 'Lifecycle1'$$, 0, 'lifecycle: invisible once hidden');

reset role;
rollback;
