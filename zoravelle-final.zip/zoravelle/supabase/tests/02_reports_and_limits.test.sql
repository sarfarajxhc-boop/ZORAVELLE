-- Run after 0001 and 0002. Everything is rolled back at the end.
begin;

create schema t;
grant usage on schema t to public;

create function t.expect_err(sql text, code text, label text) returns void
language plpgsql as $$
declare got text := null;
begin
  begin execute sql; exception when others then got := sqlstate; end;
  if got is null then raise exception 'FAIL: % (expected error %, got none)', label, code;
  elsif got <> code then raise exception 'FAIL: % (expected %, got %)', label, code, got; end if;
  raise notice 'PASS: %', label;
end $$;

create function t.expect_true(cond boolean, label text) returns void
language plpgsql as $$
begin
  if cond is not true then raise exception 'FAIL: %', label; end if;
  raise notice 'PASS: %', label;
end $$;
grant execute on all functions in schema t to public;

set local role service_role;
insert into public.experiences (id, slug, occasion, recipient_name, sender_name, configuration, published, edit_token_hash)
values ('11111111-1111-1111-1111-111111111111', 'ReportMe01', 'birthday', 'Maya', 'Arjun', '{"version":1}', true, repeat('a', 64));

-- ---- reports
insert into public.reports (experience_id, reason, details)
values ('11111111-1111-1111-1111-111111111111', 'harassment', 'rude');
select t.expect_true((select count(*) from public.reports) = 1, 'service role can file a report');

select t.expect_err($$insert into public.reports (experience_id, reason) values ('11111111-1111-1111-1111-111111111111', 'bogus')$$, '23514', 'unknown report reason rejected');
select t.expect_err($$insert into public.reports (experience_id, reason, details) values ('11111111-1111-1111-1111-111111111111', 'other', repeat('x', 501))$$, '23514', 'details over 500 chars rejected');
select t.expect_err($$insert into public.reports (experience_id, reason) values (gen_random_uuid(), 'other')$$, '23503', 'report for an unknown experience rejected');

reset role; set local role anon;
select t.expect_err($$select * from public.reports$$, '42501', 'anon cannot read reports');
select t.expect_err($$insert into public.reports (experience_id, reason) values ('11111111-1111-1111-1111-111111111111', 'other')$$, '42501', 'anon cannot file reports directly');
reset role; set local role authenticated;
select t.expect_err($$select * from public.reports$$, '42501', 'authenticated cannot read reports');

reset role; set local role service_role;
delete from public.experiences where id = '11111111-1111-1111-1111-111111111111';
select t.expect_true((select count(*) from public.reports) = 0, 'deleting an experience removes its reports');

-- ---- rate limits
select t.expect_true((select ok from public.rate_limit_hit('k1', 3, 60)), 'hit 1 allowed');
select t.expect_true((select ok from public.rate_limit_hit('k1', 3, 60)), 'hit 2 allowed');
select t.expect_true((select ok from public.rate_limit_hit('k1', 3, 60)), 'hit 3 allowed');
select t.expect_true((select not ok from public.rate_limit_hit('k1', 3, 60)), 'hit 4 blocked');
select t.expect_true((select retry_after_sec between 1 and 60 from public.rate_limit_hit('k1', 3, 60)), 'blocked hit reports a sane retry time');
select t.expect_true((select ok from public.rate_limit_hit('k2', 3, 60)), 'a different key is independent');
select t.expect_true((select count(*) from public.rate_limit_hits where key = 'k1') = 3, 'blocked hits are not recorded');

-- Old hits fall out of the window.
insert into public.rate_limit_hits (key, hit_at) select 'old', now() - interval '2 hours' from generate_series(1, 5);
select t.expect_true((select ok from public.rate_limit_hit('old', 3, 3600)), 'hits older than the window do not count');
select t.expect_true((select count(*) from public.rate_limit_hits where key = 'old') = 1, 'expired hits are removed');

select t.expect_err($$select * from public.rate_limit_hit('x', 0, 60)$$, 'P0001', 'limit < 1 rejected');
select t.expect_err($$select * from public.rate_limit_hit('x', 3, 0)$$, 'P0001', 'window < 1 rejected');
select t.expect_err($$insert into public.rate_limit_hits (key) values (repeat('k', 121))$$, '23514', 'over-long key rejected');

insert into public.rate_limit_hits (key, hit_at) values ('stale', now() - interval '3 days');
select t.expect_true(public.purge_rate_limit_hits() >= 1, 'purge removes day-old hits');
select t.expect_true((select count(*) from public.rate_limit_hits where key = 'stale') = 0, 'stale key gone after purge');

-- ---- privileges
reset role; set local role anon;
select t.expect_err($$select * from public.rate_limit_hit('k', 3, 60)$$, '42501', 'anon cannot call rate_limit_hit');
select t.expect_err($$select * from public.rate_limit_hits$$, '42501', 'anon cannot read rate_limit_hits');
select t.expect_err($$select public.purge_rate_limit_hits()$$, '42501', 'anon cannot call purge');
reset role; set local role authenticated;
select t.expect_err($$select * from public.rate_limit_hit('k', 3, 60)$$, '42501', 'authenticated cannot call rate_limit_hit');

reset role;
rollback;
