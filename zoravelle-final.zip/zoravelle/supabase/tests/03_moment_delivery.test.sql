-- Run after 0001, 0002 and 0003. Everything is rolled back at the end.
-- Proves the lock holds in the DATABASE: the public (anon) role can't read a locked greeting even by
-- calling the API directly, and unlock_at itself is not readable by browser roles.
begin;

create schema t;
grant usage on schema t to public;
create function t.expect_err(sql text, code text, label text) returns void language plpgsql as $$
declare got text := null;
begin
  begin execute sql; exception when others then got := sqlstate; end;
  if got is null then raise exception 'FAIL: % (expected error %, got none)', label, code;
  elsif got <> code then raise exception 'FAIL: % (expected %, got %)', label, code, got; end if;
  raise notice 'PASS: %', label;
end $$;
create function t.expect_true(cond boolean, label text) returns void language plpgsql as $$
begin
  if cond is not true then raise exception 'FAIL: %', label; end if;
  raise notice 'PASS: %', label;
end $$;
grant execute on all functions in schema t to public;

set local role service_role;
insert into public.experiences (id, slug, occasion, recipient_name, sender_name, message, configuration, published, edit_token_hash, unlock_at, unlock_timezone) values
 ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa1', 'LockedFut1', 'birthday', 'Maya', 'Arjun', 'SECRET-LOCKED', '{"version":1,"secret":"SECRET-LOCKED"}', true, repeat('a', 64), now() + interval '2 hours', 'Asia/Kolkata'),
 ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa2', 'LockedPast', 'birthday', 'Maya', 'Arjun', 'now-open',      '{"version":1}', true, repeat('b', 64), now() - interval '1 second', 'Asia/Kolkata'),
 ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaa3', 'OpenNoLock', 'birthday', 'Maya', 'Arjun', 'open',          '{"version":1}', true, repeat('c', 64), null, null);

select t.expect_err($$update public.experiences set unlock_at = now() + interval '1 day', unlock_timezone = null where slug = 'OpenNoLock'$$, '23514', 'an unlock time needs a time zone');
select t.expect_err($$update public.experiences set unlock_timezone = repeat('x', 65) where slug = 'OpenNoLock'$$, '23514', 'an over-long time zone is rejected');
select t.expect_err($$update public.experiences set expires_at = now() + interval '1 hour' where slug = 'LockedFut1'$$, '23514', 'a greeting cannot expire before it unlocks');
select t.expect_true((select count(*) from public.experiences where unlock_at is not null) = 2, 'service role can read and write the lock');

reset role; set local role anon;
select t.expect_true((select count(*) from public.experiences where slug = 'LockedFut1') = 0, 'anon cannot read a locked greeting row');
select t.expect_true((select count(*) from public.experiences where slug = 'LockedFut1' and message like 'SECRET%') = 0, 'anon cannot read a locked greeting message');
select t.expect_true((select count(*) from public.experiences where configuration::text like '%SECRET-LOCKED%') = 0, 'anon cannot find locked content by searching it');
select t.expect_true((select count(*) from public.experiences) = 2, 'anon sees only the open greetings (past-unlock and never-locked)');
select t.expect_true((select count(*) from public.experiences where slug = 'LockedPast') = 1, 'a greeting whose unlock time has passed is readable');
select t.expect_err($$select unlock_at from public.experiences$$, '42501', 'anon cannot read unlock_at');
select t.expect_err($$select unlock_timezone from public.experiences$$, '42501', 'anon cannot read unlock_timezone');
select t.expect_err($$update public.experiences set unlock_at = null$$, '42501', 'anon cannot remove a lock');

reset role; set local role authenticated;
select t.expect_true((select count(*) from public.experiences where slug = 'LockedFut1') = 0, 'authenticated cannot read a locked greeting either');

-- time passing inside the database opens it, with no job and no creator involved
reset role; set local role service_role;
update public.experiences set unlock_at = now() - interval '1 millisecond' where slug = 'LockedFut1';
reset role; set local role anon;
select t.expect_true((select count(*) from public.experiences where slug = 'LockedFut1') = 1, 'once the instant has passed the row opens by itself');

reset role; set local role service_role;
update public.experiences set hidden_at = now() where slug = 'LockedFut1';
reset role; set local role anon;
select t.expect_true((select count(*) from public.experiences where slug = 'LockedFut1') = 0, 'a hidden greeting stays hidden after it unlocks');

rollback;
